<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends CI_Controller {



	 function __construct() {

        parent::__construct();   
        date_default_timezone_set('Asia/Jakarta');     

        $this->load->database();
		$this->load->model('md_siperpus_sysuser');
		$this->load->model('md_siperpus_sysgroup');
		$this->load->model('md_siperpus_sysgrant');
		$this->load->model('md_vwsiswa');
		$this->load->model('md_vwdosen');
		$this->load->model('md_vwanggota');
		$this->load->model('md_siperpus_anggota_luar');

		$this->load->model('md_siperpus_klasifikasi');
		
		$this->load->model('md_siperpus_setting');
		$this->load->model('md_siperpus_config_transaksi');
		$this->load->model('md_siperpus_kategori');
        $this->load->model('md_siperpus_kategori_buku');
		$this->load->model('md_siperpus_bahasa');
		$this->load->model('md_siperpus_asal_buku');
		$this->load->model('md_siperpus_penerbit');
		$this->load->model('md_siperpus_keperluan_sbppl');
		$this->load->model('md_vwprodi');
		$this->load->model('md_siperpus_matakuliah');
		$this->load->model('md_siperpus_data_buku');

		$this->load->model('md_siperpus_sysmodul');

		//from http://www.zedwood.com/article/php-calculate-duration-of-mp3

		//include APPPATH.'controllers/mp3file.php'; //load mp3file class for calculate duration

		/* cash control */

        $this->output->set_header('Last-Modified: ' . gmdate("D, d M Y H:i:s") . ' GMT');

        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');

        $this->output->set_header('Pragma: no-cache');

        $this->output->set_header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");

    }

	

	public function index()

	{

		if ($this->session->userdata('login') != 'A')

			{

			$this->session->sess_destroy();

            redirect(base_url() . 'home', 'refresh');

			}

        if ($this->session->userdata('login') == 'A')

            redirect(base_url() . 'admin/dashboard', 'refresh');

	}


	function dashboard() {

        if ($this->session->userdata('login') != 'A')
			$this->logout();

        $page_data['page_access'] = "admin";

        $page_data['page_name'] = 'dashboard';

        $page_data['page_now'] = 'dashboard';

        $page_data['page_title'] = 'Manage Dashboard';

		$this->load->view('index', $page_data);

    }
	/** *Data Mahasiswa* **/

    function data_mahasiswa($param1 = '', $param2 = '', $param3 = '') {

        if ($this->session->userdata('login') != 'A')

            $this->logout();

		$date = new DateTime();

		$id=$this->session->userdata('user_id');
		$page_data['page_action'] = 'list';
        if($param1 =='edit'){
		
		$page_data['page_action'] = $param1;
        }
        $page_data['page_access'] = "admin";
        $page_data['page_name'] = 'data_mahasiswa';
        $page_data['page_now'] = 'Data Induk';
        $page_data['page_title'] = 'Data Mahasiswa';
		$page_data['data']=$this->md_vwsiswa->getSiswaAll();
        $this->load->view('index', $page_data);

    }
	/** *Data Dosen* **/

    function data_dosen($param1 = '', $param2 = '', $param3 = '') {

        if ($this->session->userdata('login') != 'A')

            $this->logout();

		$date = new DateTime();

		$id=$this->session->userdata('user_id');
        $page_data['page_action'] = $param1;
        $page_data['page_access'] = "admin";
        $page_data['page_name'] = 'data_dosen';
        $page_data['page_now'] = 'Data Induk';
        $page_data['page_title'] = 'Data Dosen';
		$page_data['data']=$this->md_vwdosen->getDosenAll();
        $this->load->view('index', $page_data);

    }
	/** *Data Anggota* **/

    function data_anggota($param1 = '', $param2 = '', $param3 = '') {

        if ($this->session->userdata('login') != 'A')

            $this->logout();

		$date = new DateTime();

		$id=$this->session->userdata('user_id');

        $page_data['page_action'] = $param1;
        $page_data['page_access'] = "admin";
        $page_data['page_name'] = 'data_anggota';
        $page_data['page_now'] = 'Data Induk';
        $page_data['page_title'] = 'Data Anggota';
		$page_data['data']=$this->md_vwanggota->getAnggotaAll();
        $this->load->view('index', $page_data);

    }
	/** *Data Anggota* **/

    function data_anggota_luar($param1 = '', $param2 = '', $param3 = '') {

        if ($this->session->userdata('login') != 'A')

            $this->logout();

		$date = new DateTime();

		$id=$this->session->userdata('user_id');

        $page_data['page_action'] = $param1;
        $page_data['page_access'] = "admin";
        $page_data['page_name'] = 'data_anggota_luar';
        $page_data['page_now'] = 'Data Induk';
        $page_data['page_title'] = 'Data Anggota Luar';
		$page_data['data']=$this->md_siperpus_anggota_luar->getAnggotaAll();
        $this->load->view('index', $page_data);

    }
	/** *Data Klasifikasi* **/

    function klasifikasi_buku($param1 = '', $param2 = '', $param3 = '') {

        if ($this->session->userdata('login') != 'A')

            $this->logout();

		$date = new DateTime();

		$id=$this->session->userdata('user_id');

        $page_data['page_action'] = 'list';
         $page_data['page_title'] = 'Data Klasifikasi Buku';
		$page_data['page_access'] = "admin";
		$page_data['page_name'] = 'klasifikasi_buku';
		$page_data['page_now'] = 'Data Referensi';
		if ($param1 == 'submit') {

			$data['id'] = $this->input->post('id');
			
			$data['nama'] = $this->input->post('nama');
			if($data['id']=='' || $data['nama']==''){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-danger');

				$this->session->set_flashdata('flash_message', 'Empty Field');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
				//redirect(base_url() . 'admin/klasifikasi_buku/tambah', 'refresh');
			}else{
				$buku=$this->md_siperpus_klasifikasi->getKlasifikasiById($this->input->post('id'));
				
				if($buku){
					//Id duplicate
					$this->session->set_flashdata('alert', 'alert-danger');

					$this->session->set_flashdata('flash_message', 'ID telah dipakai, klasifikasi buku gagal dibuat');
					echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "ID telah dipakai, Klasifikasi buku gagal dibuat"));
					//redirect(base_url() . 'admin/klasifikasi_buku/tambah', 'refresh');

				}else{
					$this->md_siperpus_klasifikasi->addKlasifikasi($data);
					
					$this->session->set_flashdata('alert', 'alert-focus');

					$this->session->set_flashdata('flash_message', 'Klasifikasi Buku Sukses dibuat');
					echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Klasifikasi Buku Sukses dibuat"));
					//redirect(base_url() . 'admin/klasifikasi_buku', 'refresh');
				}
			}
        }else if ($param1 == 'update') {

			$data['id'] = $this->input->post('id');
			
			$data['nama'] = $this->input->post('nama');
			
			if($data['id']=='' || $data['nama']==''){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-danger');

				$this->session->set_flashdata('flash_message', 'Empty Field');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
				//redirect(base_url() . 'admin/klasifikasi_buku/edit', 'refresh');
			}else{
				$this->md_siperpus_klasifikasi->updateKlasifikasi($data['id'], $data);

				$this->session->set_flashdata('alert', 'alert-focus');

				$this->session->set_flashdata('flash_message', 'Klasifikasi Buku Sukses diedit');
				//redirect(base_url() . 'admin/klasifikasi_buku', 'refresh');
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Klasifikasi Buku Sukses diedit"));
			}
			
        }else if ($param1=='hapus' && $param2 !='') {
				$this->md_siperpus_klasifikasi->hapusKlasifikasi($param2);
				$this->session->set_flashdata('alert', 'alert-focus');
				$this->session->set_flashdata('flash_message', 'Klasifikasi Buku Sukses Dihapus');
				//redirect(base_url() . 'admin/klasifikasi_buku', 'refresh');
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Klasifikasi Buku Sukses Dihapus"));
		}else if($param1 =='edit' && $param2 !=''){
			/*
			$page_data['data']=$this->md_siperpus_klasifikasi->getKlasifikasiById($param2);
			$page_data['page_action'] = $param1;
			$page_data['page_title'] = 'Edit Klasifikasi Buku';
			*/
			$data = $this->md_siperpus_klasifikasi->getKlasifikasiById($param2);
			echo json_encode($data);

		}else if($param1 =='fetch'){
			if($this->input->post('datatable[query][generalSearch]'))$total=$this->md_siperpus_klasifikasi->countFiltered();
			else $total=$this->md_siperpus_klasifikasi->countAll();
			$page=$this->input->post('datatable[pagination][page]');
			if($page<1)$page=1;
			$perpage=10;
			$pages=$total/$perpage;
			$field=$this->input->post('datatable[sort][field]');
			if($field=='')$field=$this->input->post('datatable[pagination][field]');
			$sort=$this->input->post('datatable[sort][sort]');
			if($sort=='')$sort=$this->input->post('datatable[pagination][sort]');
			$data = array();
			$no = 0;
			$list=$this->md_siperpus_klasifikasi->getDatatables();
			foreach ($list as $row) {
				$no++;
				$arr = array();
				$arr['number'] = ($perpage*($page-1))+$no;
				$arr['id'] = $row->id;
				$arr['nama'] = $row->nama;
				$data[] = $arr;
			}
			$meta=array();
			$meta['page']=$page;
			$meta['pages']=$pages;
			$meta['perpage']=$perpage;
			$meta['total']=$total;
			$meta['sort']=$sort;
			$meta['field']=$field;
			$output = array(
							"meta" => $meta,
							"data" => $data
					);
			//output to json format
			echo json_encode($output);

		}else{
			$this->load->view('index', $page_data);
		}
    }
	/** Konfigurasi **/
    function konfigurasi($param1 = '', $param2 = '', $param3 = '') {

        if ($this->session->userdata('login') != 'A')

            $this->logout();

		$date = new DateTime();

		$id=$this->session->userdata('user_id');

        $page_data['page_action'] = 'list';
        $page_data['data']=$this->md_siperpus_setting->getSettingAll();
		$page_data['data_kategori']=$this->md_siperpus_kategori->getKategoriAll();
        $page_data['page_title'] = 'Pengaturan Program';
		if ($param1 == 'update') {

			$setting1= $this->input->post('setting1');
			$setting2= $this->input->post('setting2');
			$setting3= $this->input->post('setting3');
			$setting4= $this->input->post('setting4');
			$setting5= $this->input->post('setting5');
			$setting6= $this->input->post('setting6');
			$setting7= $this->input->post('setting7');
			$setting8= $this->input->post('setting8');
			$setting9= $this->input->post('setting9');
			$setting10= $this->input->post('setting10');
			$setting1kode= $this->input->post('setting1kode');
			$setting2kode= $this->input->post('setting2kode');
			$setting3kode= $this->input->post('setting3kode');
			$setting4kode= $this->input->post('setting4kode');
			$setting5kode= $this->input->post('setting5kode');
			$setting6kode= $this->input->post('setting6kode');
			$setting7kode= $this->input->post('setting7kode');
			$setting8kode= $this->input->post('setting8kode');
			$setting9kode= $this->input->post('setting9kode');
			$setting10kode= $this->input->post('setting10kode');
			
			if($setting1 !=''&& $setting1kode !=''){
				$data['valsetting']=$setting1;
				$this->md_siperpus_setting->updateSetting($setting1kode,$data);
			}
			if($setting2 !=''&& $setting2kode !=''){
				$data['valsetting']=$setting2;
				$this->md_siperpus_setting->updateSetting($setting2kode,$data);
			}
			if($setting3 !=''&& $setting3kode !=''){
				$data['valsetting']=$setting3;
				$this->md_siperpus_setting->updateSetting($setting3kode,$data);
			}
			if($setting4 !=''&& $setting4kode !=''){
				$data['valsetting']=$setting4;
				$this->md_siperpus_setting->updateSetting($setting4kode,$data);
			}
			if($setting5 !=''&& $setting5kode !=''){
				$data['valsetting']=$setting5;
				$this->md_siperpus_setting->updateSetting($setting5kode,$data);
			}
			if($setting6 !=''&& $setting6kode !=''){
				$data['valsetting']=$setting6;
				$this->md_siperpus_setting->updateSetting($setting6kode,$data);
			}
			if($setting7 !=''&& $setting7kode !=''){
				$data['valsetting']=$setting7;
				$this->md_siperpus_setting->updateSetting($setting7kode,$data);
			}
			if($setting8 !=''&& $setting8kode !=''){
				$data['valsetting']=$setting8;
				$this->md_siperpus_setting->updateSetting($setting8kode,$data);
			}
			if($setting9 !=''&& $setting9kode !=''){
				$data['valsetting']=$setting9;
				$this->md_siperpus_setting->updateSetting($setting9kode,$data);
			}
			if($setting10 !=''&& $setting10kode !=''){
				$data['valsetting']=$setting10;
				$this->md_siperpus_setting->updateSetting($setting10kode,$data);
			}
			
			
				$this->session->set_flashdata('alert', 'alert-warning');

				$this->session->set_flashdata('flash_message', 'Update Setting Sukses');

				redirect(base_url() . 'admin/konfigurasi/', 'refresh');
			
			
        }
        $page_data['page_access'] = "admin";
        $page_data['page_name'] = 'konfigurasi';
        $page_data['page_now'] = 'Konfigurasi Transaksi';
        $this->load->view('index', $page_data);

    }
	public function logout(){

	$date = new DateTime();

		$id=$this->session->userdata('user_id');
		
		if(!empty($id)){
				/*
			$user=$this->md_user->getuserById($id);
			$log['user_id']=$id;
			$log['tgl']=$date->format("Y-m-d H:i:s");
			$log['jenis_log']='admin';
			$log['jenis_akses']='LogOut';
			$log['status']=1;
			$log['keterangan']=$user[0]->username.' Melakukan LogOut';
			$log['IP']=$_SERVER['REMOTE_ADDR'];
			$this->md_log->addLogBaru($log);
			*/
		}
		$this->session->sess_destroy();

	    redirect(base_url() . 'home', 'refresh');

	}

	public function kategori_buku($param1='',$param2='')
		{
			if ($this->session->userdata('login') != 'A')
					$this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');

			  $page_data['page_action'] = 'list';
			  $page_data['data']=$this->md_siperpus_kategori_buku->getKategoriBukuAll();
			  $page_data['page_title'] = 'Data Kategori Buku';

					if ($param1 == 'submit') {
						$data['idkategori'] = $this->input->post('idkategori');
						$data['nmkategori'] = $this->input->post('nmkategori');
						if($data['nmkategori']==''){
						//Empty Field
						$this->session->set_flashdata('alert', 'alert-warning');
						$this->session->set_flashdata('flash_message', 'Empty Field'.$data['nmkategori']);
						redirect(base_url() . 'admin/kategori_buku/tambah', 'refresh');
						}else{
							$buku=$this->md_siperpus_kategori_buku->getKategoriById($this->input->post('idkategori'));
							if($buku){
								//Id duplicate
								$this->session->set_flashdata('alert', 'alert-warning');
								$this->session->set_flashdata('flash_message', 'Kategori telah ada, kategori buku gagal dibuat');
								redirect(base_url() . 'admin/kategori_buku', 'refresh');
							}else {
								$this->md_siperpus_kategori_buku->addKategoriBuku($data);
								$this->session->set_flashdata('alert', 'alert-success');
								$this->session->set_flashdata('flash_message', 'Kategori Buku Sukses dibuat');
								redirect(base_url() . 'admin/kategori_buku', 'refresh');
							}
						}
				 }
					 else if ($param1 == 'update' && $param2 != '') {
						//$data['idkategori'] = $this->db->getKategoriById();
						$data['nmkategori'] = $this->input->post('nmkategori');
						if($data['nmkategori']==''){
							//Empty Field
							$this->session->set_flashdata('alert', 'alert-warning');
							$this->session->set_flashdata('flash_message', 'Empty Field');
							redirect(base_url() . 'admin/kategori_buku/edit', 'refresh');
						}else{
							$this->md_siperpus_kategori_buku->updateKategoriBuku($param2, $data);
							$this->session->set_flashdata('alert', 'alert-success');
							$this->session->set_flashdata('flash_message', 'Kategori Buku Sukses diedit');
							redirect(base_url() . 'admin/kategori_buku', 'refresh');
						}
					}elseif ($param1=='hapus') {
						$this->md_siperpus_kategori_buku->hapusKategoriBuku($param2);
						$this->session->set_flashdata('alert', 'alert-success');
						$this->session->set_flashdata('flash_message', 'Kategori Buku Sukses Dihapus');
						redirect(base_url() . 'admin/kategori_buku', 'refresh');
					}
					 else if($param1 =='edit' && $param2 !=''){
						$page_data['data']=$this->md_siperpus_kategori_buku->getKategoriById($param2);
						$page_data['page_action'] = $param1;
						$page_data['page_title'] = 'Edit Kategori Buku';
					 }else if($param1 =='tambah'){
						$page_data['page_action'] = $param1;
						$page_data['page_title'] = 'Tambah Kategori Buku';
					 }

					$page_data['page_access'] = "admin";
			  $page_data['page_name'] = 'kategori_buku';
			  $page_data['page_now'] = 'Data Referensi';
			  $this->load->view('index', $page_data);
		}
		/** *Bahasa* **/

		function bahasa($param1='',$param2='')
		{
			if ($this->session->userdata('login') != 'A')
					$this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');

			  $page_data['page_action'] = 'list';
			  $page_data['data']=$this->md_siperpus_bahasa->getBahasaAll();
			  $page_data['page_title'] = 'Data Bahasa';

					if ($param1 == 'submit') {
						$data['id'] = $this->input->post('id');
						$data['nama'] = $this->input->post('nama');
						$data['no_urut'] = $this->input->post('no_urut');
						if($data['id']=='' || $data['nama']==''||$data['no_urut']==''){
						//Empty Field
						$this->session->set_flashdata('alert', 'alert-warning');
						$this->session->set_flashdata('flash_message', 'Empty Field');
						redirect(base_url() . 'admin/kategori_buku/tambah', 'refresh');
						}else{
							$buku=$this->md_siperpus_bahasa->getBahasaById($this->input->post('id'));
							if ($buku) {
								$this->session->set_flashdata('alert', 'alert-warning');
						  $this->session->set_flashdata('flash_message', 'ID telah dipakai, bahasa gagal dibuat');
						  redirect(base_url() . 'admin/bahasa/tambah', 'refresh');
							}else {
								$this->md_siperpus_bahasa->addBahasa($data);
								$this->session->set_flashdata('alert', 'alert-success');
								$this->session->set_flashdata('flash_message', 'Bahasa Sukses dibuat');
								redirect(base_url() . 'admin/bahasa', 'refresh');
							}
						}
				 }
					 else if ($param1 == 'update' && $param2 != '') {
						$data['id'] = $this->input->post('id');
						$data['nama'] = $this->input->post('nama');
						if($data['id']==''||$data['nama']==''){
							//Empty Field
							$this->session->set_flashdata('alert', 'alert-warning');
							$this->session->set_flashdata('flash_message', 'Empty Field');
							redirect(base_url() . 'admin/bahasa/edit', 'refresh');
						}else{
							$this->md_siperpus_bahasa->updateBahasa($param2, $data);
							$this->session->set_flashdata('alert', 'alert-success');
							$this->session->set_flashdata('flash_message', 'Bahasa Sukses diedit');
							redirect(base_url() . 'admin/bahasa', 'refresh');
						}
					}elseif ($param1=='hapus') {
						$this->md_siperpus_bahasa->hapusBahasa($param2);
						$this->session->set_flashdata('alert', 'alert-success');
						$this->session->set_flashdata('flash_message', 'Kategori Buku Sukses Dihapus');
						redirect(base_url() . 'admin/bahasa', 'refresh');
					}
					 else if($param1 =='edit' && $param2 !=''){
						$page_data['data']=$this->md_siperpus_bahasa->getBahasaById($param2);
						$page_data['page_action'] = $param1;
						$page_data['page_title'] = 'Edit Bahasa';
					 }else if($param1 =='tambah'){
						$page_data['page_action'] = $param1;
						$page_data['page_title'] = 'Tambah Bahasa';
					 }
					$page_data['page_access'] = "admin";
			  $page_data['page_name'] = 'bahasa';
			  $page_data['page_now'] = 'Data Referensi';
			  $this->load->view('index', $page_data);
		}
		/** *Asal Buku* **/

		function asal_buku($param1='',$param2='')
		{
			if ($this->session->userdata('login') != 'A')
					$this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');

			  $page_data['page_action'] = 'list';
			  $page_data['data']=$this->md_siperpus_asal_buku->getAsalBukuAll();
			  $page_data['page_title'] = 'Data Asal Buku';

					if ($param1 == 'submit') {
						$data['id'] = $this->input->post('id');
						$data['nama'] = $this->input->post('nama');
						if($data['id']=='' || $data['nama']==''){
						//Empty Field
						$this->session->set_flashdata('alert', 'alert-warning');
						$this->session->set_flashdata('flash_message', 'Empty Field');
						redirect(base_url() . 'admin/asal_buku/tambah', 'refresh');
						}else{
							$buku=$this->md_siperpus_asal_buku->getAsalBukuById($this->input->post('id'));
						  if ($buku) {
							$this->session->set_flashdata('alert', 'alert-warning');
							$this->session->set_flashdata('flash_message', 'ID telah dipakai, Asal Buku gagal dibuat');
							redirect(base_url() . 'admin/asal_buku/tambah', 'refresh');
						  }else {
								$this->md_siperpus_asal_buku->addAsalBuku($data);
								$this->session->set_flashdata('alert', 'alert-success');
								$this->session->set_flashdata('flash_message', 'Asal Buku Sukses dibuat');
								redirect(base_url() . 'admin/asal_buku', 'refresh');
						  }
						}
				 }
					 else if ($param1 == 'update' && $param2 != '') {
						$data['id'] = $this->input->post('id');
						$data['nama'] = $this->input->post('nama');
						if($data['id']==''||$data['nama']==''){
							//Empty Field
							$this->session->set_flashdata('alert', 'alert-warning');
							$this->session->set_flashdata('flash_message', 'Empty Field');
							redirect(base_url() . 'admin/asal_buku/edit', 'refresh');
						}else{
							$this->md_siperpus_asal_buku->updateAsalBuku($param2, $data);
							$this->session->set_flashdata('alert', 'alert-success');
							$this->session->set_flashdata('flash_message', 'AsalBuku Sukses diedit');
							redirect(base_url() . 'admin/asal_buku', 'refresh');
						}
					}elseif ($param1=='hapus') {
						$this->md_siperpus_asal_buku->hapusAsalBuku($param2);
						$this->session->set_flashdata('alert', 'alert-success');
						$this->session->set_flashdata('flash_message', 'Kategori Buku Sukses Dihapus');
						redirect(base_url() . 'admin/asal_buku', 'refresh');
					}
					 else if($param1 =='edit' && $param2 !=''){
						$page_data['data']=$this->md_siperpus_asal_buku->getAsalBukuById($param2);
						$page_data['page_action'] = $param1;
						$page_data['page_title'] = 'Edit Bahasa';
					 }else if($param1 =='tambah'){
						$page_data['page_action'] = $param1;
						$page_data['page_title'] = 'Tambah Bahasa';
					 }
					$page_data['page_access'] = "admin";
			  $page_data['page_name'] = 'asal_buku';
			  $page_data['page_now'] = 'Data Referensi';
			  $this->load->view('index', $page_data);
		}
		/** *Penerbit* **/

		function penerbit($param1='',$param2='')
		{
			if ($this->session->userdata('login') != 'A')
					$this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');

			  $page_data['page_action'] = 'list';
			  $page_data['data']=$this->md_siperpus_penerbit->getPenerbitAll();
			  $page_data['page_title'] = 'Data Penerbit';

					if ($param1 == 'submit') {
						$data['kd_penerbit'] = $this->input->post('kd_penerbit');
						$data['nama_penerbit'] = $this->input->post('nama_penerbit');
						$data['kota'] = $this->input->post('kota');
						if($data['kd_penerbit']=='' || $data['nama_penerbit']==''||$data['kota']==''){
						//Empty Field
						$this->session->set_flashdata('alert', 'alert-warning');
						$this->session->set_flashdata('flash_message', 'Empty Field');
						redirect(base_url() . 'admin/penerbit/tambah', 'refresh');
						}else{
							  $this->md_siperpus_penerbit->addPenerbit($data);
								$this->session->set_flashdata('alert', 'alert-success');
								$this->session->set_flashdata('flash_message', 'Penerbit Sukses dibuat');
								redirect(base_url() . 'admin/penerbit', 'refresh');
						}
				 }
					 else if ($param1 == 'update' && $param2 != '') {
						$data['kd_penerbit'] = $this->input->post('kd_penerbit');
						$data['nama_penerbit'] = $this->input->post('nama_penerbit');
						$data['kota'] = $this->input->post('kota');
						if($data['kd_penerbit']==''||$data['nama_penerbit']==''||$data['kota']==''){
							//Empty Field
							$this->session->set_flashdata('alert', 'alert-warning');
							$this->session->set_flashdata('flash_message', 'Empty Field');
							redirect(base_url() . 'admin/penerbit/edit', 'refresh');
						}else{
							$this->md_siperpus_penerbit->updatePenerbit($param2, $data);
							$this->session->set_flashdata('alert', 'alert-success');
							$this->session->set_flashdata('flash_message', 'Penerbit Sukses diedit');
							redirect(base_url() . 'admin/penerbit', 'refresh');
						}
					}elseif ($param1=='hapus') {
						$this->md_siperpus_penerbit->hapusPenerbit($param2);
						$this->session->set_flashdata('alert', 'alert-success');
						$this->session->set_flashdata('flash_message', 'Penerbit Sukses Dihapus');
						redirect(base_url() . 'admin/penerbit', 'refresh');
					}
					 else if($param1 =='edit' && $param2 !=''){
						$page_data['data']=$this->md_siperpus_penerbit->getPenerbitById($param2);
						$page_data['page_action'] = $param1;
						$page_data['page_title'] = 'Edit Penerbit';
					 }else if($param1 =='tambah'){
						$page_data['page_action'] = $param1;
						$page_data['page_title'] = 'Tambah Penerbit';
					 }
					$page_data['page_access'] = "admin";
			  $page_data['page_name'] = 'penerbit';
			  $page_data['page_now'] = 'Data Referensi';
			  $this->load->view('index', $page_data);
		}
		/** *Keperluan SPPBL* **/

		function Keperluan_sbppl($param1='',$param2='')
		{
			if ($this->session->userdata('login') != 'A')
					$this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');

		  $page_data['page_action'] = 'list';
		  $page_data['data']=$this->md_siperpus_keperluan_sbppl->getSbpplAll();
		  $page_data['page_title'] = 'Data Keperluan Sbppl';

				if ($param1 == 'submit') {
					$data['nama'] = $this->input->post('nama');
					$data['no_urut'] = $this->input->post('no_urut');
					if($data['nama']==''||$data['no_urut']==''){
					//Empty Field
					$this->session->set_flashdata('alert', 'alert-warning');
					$this->session->set_flashdata('flash_message', 'Empty Field');
					redirect(base_url() . 'admin/keperluan_sbppl/tambah', 'refresh');
					}else{
						  $this->md_siperpus_keperluan_sbppl->addSbppl($data);
							$this->session->set_flashdata('alert', 'alert-success');
							$this->session->set_flashdata('flash_message', 'Keperluan Sbppl Sukses dibuat');
							redirect(base_url() . 'admin/keperluan_sbppl', 'refresh');
					}
			 }
				 else if ($param1 == 'update' && $param2 != '') {
					//$data['id'] = $this->input->post('id');
					$data['nama'] = $this->input->post('nama');
					$data['no_urut'] = $this->input->post('no_urut');
					if($data['nama']==''||$data['no_urut']==''){
						//Empty Field
						$this->session->set_flashdata('alert', 'alert-warning');
						$this->session->set_flashdata('flash_message', 'Empty Field');
						redirect(base_url() . 'admin/keperluan_sbppl/edit', 'refresh');
					}else{
						$this->md_siperpus_keperluan_sbppl->updateSbppl($param2, $data);
						$this->session->set_flashdata('alert', 'alert-success');
						$this->session->set_flashdata('flash_message', 'Keperluan Sbppl Sukses diedit');
						redirect(base_url() . 'admin/keperluan_sbppl', 'refresh');
					}
				}elseif ($param1=='hapus') {
					$this->md_siperpus_keperluan_sbppl->hapusSbppl($param2);
					$this->session->set_flashdata('alert', 'alert-success');
					$this->session->set_flashdata('flash_message', 'Keperluan Sbppl Sukses Dihapus');
					redirect(base_url() . 'admin/keperluan_sbppl', 'refresh');
				}
				 else if($param1 =='edit' && $param2 !=''){
					$page_data['data']=$this->md_siperpus_keperluan_sbppl->getSbpplById($param2);
					$page_data['page_action'] = $param1;
					$page_data['page_title'] = 'Edit Keperluan Sbppl';
				 }else if($param1 =='tambah'){
					$page_data['page_action'] = $param1;
					$page_data['page_title'] = 'Tambah Keperluan Sbppl';
				 }
				$page_data['page_access'] = "admin";
		  $page_data['page_name'] = 'keperluan_sbppl';
		  $page_data['page_now'] = 'Data Referensi';
		  $this->load->view('index', $page_data);
		}
		/** *Proram Studi* **/

		function program_studi($param1='',$param2='')
		{
			if ($this->session->userdata('login') != 'A')
					$this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');

		  $page_data['page_action'] = 'list';
		  $page_data['data']=$this->md_vwprodi->getProdiAll();
		  $page_data['page_title'] = 'Data Program Studi';

				// if ($param1 == 'submit') {
				// 	$data['nama'] = $this->input->post('nama');
				// 	$data['no_urut'] = $this->input->post('no_urut');
				// 	if($data['nama']==''||$data['no_urut']==''){
				// 	//Empty Field
				// 	$this->session->set_flashdata('alert', 'alert-warning');
				// 	$this->session->set_flashdata('flash_message', 'Empty Field');
				// 	redirect(base_url() . 'admin/program_studi/tambah', 'refresh');
				// 	}else{
				// 		  $this->md_siperpus_program_studi->addSbppl($data);
				// 			$this->session->set_flashdata('alert', 'alert-success');
				// 			$this->session->set_flashdata('flash_message', 'Keperluan Sbppl Sukses dibuat');
				// 			redirect(base_url() . 'admin/program_studi', 'refresh');
				// 	}
			//  }else if($param1 =='tambah'){
				// 	$page_data['page_action'] = $param1;
				// 	$page_data['page_title'] = 'Tambah Program Studi';
				//  }

				$page_data['page_access'] = "admin";
		  $page_data['page_name'] = 'program_studi';
		  $page_data['page_now'] = 'Data Referensi';
		  $this->load->view('index', $page_data);
		}
		/** *Proram Studi* **/

		function matakuliah($param1='',$param2='')
		{
			if ($this->session->userdata('login') != 'A')
					$this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');

      $page_data['page_action'] = 'list';
      $page_data['data']=$this->md_siperpus_matakuliah->getMatakuliahAll();
      $page_data['page_title'] = 'Data Mata Kuliah';

			$page_data['page_access'] = "admin";
      $page_data['page_name'] = 'matakuliah';
      $page_data['page_now'] = 'Data Referensi';
      $this->load->view('index', $page_data);
		}

		function data_buku($param1='',$param2='')
		{
			if ($this->session->userdata('login') != 'A')
					$this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');

		  $page_data['page_action'] = 'list';
		  $page_data['data']=$this->md_siperpus_data_buku->getDataBukuAll();
		  $page_data['page_title'] = 'Data Buku';

			if ($param1 == 'submit') {
				$data = array('no_klas' => $this->input->post('no_klas'),
											'isbn' => $this->input->post('isbn'),
											//'buku' => $this->input->post('buku'),
											'judul' => $this->input->post('judul'),
											'cetakkatalog_judulpenggal' => $this->input->post('cetakkatalog_judulpenggal'),
											'judulasli' => $this->input->post('judulasli'),
											//'komentar_publik' => $this->input->post('komentar_publik'),
											//'des_buku' => $this->input->post('des_buku'),
											'penulis' => $this->input->post('penulis'),
											'penyadur' => $this->input->post('penyadur'),
											'penerjemah' => $this->input->post('penerjemah'),
											'penyusun' => $this->input->post('penyusun'),
											'penyunting' => $this->input->post('penyunting'),
											'illustrator' => $this->input->post('illustrator'),
											'editor' => $this->input->post('editor'),
											'edisi' => $this->input->post('edisi'),
											'cetakan' => $this->input->post('cetakan'),
											//'penerbit' => $this->input->post('penerbit'),
											'thn_terbit' => $this->input->post('thn_terbit'),
											'jilid' => $this->input->post('jilid'),
											'hlm_romawi' => $this->input->post('hlm_romawi'),
											'jml_hal' => $this->input->post('jml_hal'),
											'ilustrasi' => $this->input->post('ilustrasi'),
											'tabel' => $this->input->post('tabel'),
											'ukuran_fisik' => $this->input->post('ukuran_fisik'),
											'bibliografi' => $this->input->post('bibliografi'),
											//'index' => $this->input->post('index'),
											'bahasa' => $this->input->post('bahasa'),
											'no_rak' => $this->input->post('no_rak'),
											'seri' => $this->input->post('seri')
											//'tajuk_utama' => $this->input->post('tajuk_utama'),
											//'tajuk_subyek' => $this->input->post('tajuk_subyek'),
											//'matkul' => $this->input->post('matkul')
			 );
				if($data['no_klas']==''||$data['judul']==''|| $data['penulis']==''){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-warning');
				$this->session->set_flashdata('flash_message', 'Empty Field'.$data['no_klas'].'a'.$data['judul'].'a'.$data['penulis'].'a'.$data['penerbit']);
				redirect(base_url() . 'admin/data_buku/tambah', 'refresh');
				}else{
					  $this->md_siperpus_data_buku->addDataBuku($data);
						$this->session->set_flashdata('alert', 'alert-success');
						$this->session->set_flashdata('flash_message', 'Data Buku Sukses dibuat');
						redirect(base_url() . 'admin/data_buku', 'refresh');
				}
	     }elseif($param1 =='tambah'){
				 $page_data['data']['kel_buku']=$this->md_siperpus_kategori_buku->getKategoriBukuAll();
				 $page_data['data']['penerbit']=$this->md_siperpus_penerbit->getPenerbitAll();
				 $page_data['data']['bahasa']=$this->md_siperpus_bahasa->getBahasaAll();
				 $page_data['page_action'] = $param1;
				 $page_data['page_title'] = 'Tambah Data Buku';
			 }

			$page_data['page_access'] = "admin";
      $page_data['page_name'] = 'data_buku';
      $page_data['page_now'] = 'Buku & Inventarisasi';
      $this->load->view('index', $page_data);
		}
		
	/** Konfigurasi **/
    function konfigurasi_transaksi($param1 = '', $param2 = '', $param3 = '') {

        if ($this->session->userdata('login') != 'A')

            $this->logout();

		$date = new DateTime();

		$id=$this->session->userdata('user_id');

        $page_data['page_action'] = 'list';
        $page_data['data']=$this->md_siperpus_config_transaksi->getConfigAll('m');
        $page_data['page_title'] = 'Pengaturan Transaksi';
		if ($param1 == 'update') {

			$setting1= $this->input->post('setting1');
			$setting2= $this->input->post('setting2');
			$setting3= $this->input->post('setting3');
			$setting4= $this->input->post('setting4');
			$setting5= $this->input->post('setting5');
			
			if($setting1 !=''){
				$data['jml_buku']=$setting1;
			}
			if($setting2 !=''){
				$data['lama']=$setting2;
			}
			if($setting3 !=''){
				$data['denda']=$setting3;
			}
			if($setting4 !=''){
				$data['perpanjang']=$setting4;
			}
			if($setting5 !=''){
				$data['masa_berlaku']=$setting5;
			}
				$this->md_siperpus_config_transaksi->updateConfig('m',$data);
			
			
				$this->session->set_flashdata('alert', 'alert-warning');

				$this->session->set_flashdata('flash_message', 'Update Konfigurasi Transaksi Sukses');

				redirect(base_url() . 'admin/konfigurasi_transaksi/', 'refresh');
			
        }if ($param1 == 'forceupdate') {

			$tgl= $this->input->post('tgl');
			
			if($tgl ==''){
				$this->session->set_flashdata('alert', 'alert-warning');

				$this->session->set_flashdata('flash_message', 'Empty Field');

				redirect(base_url() . 'admin/konfigurasi_transaksi/', 'refresh');
			}else{
				$this->md_siperpus_config_transaksi->updateConfig('m',$data);
				$this->session->set_flashdata('alert', 'alert-warning');
				$this->session->set_flashdata('flash_message', 'Update Konfigurasi Transaksi Sukses');
				redirect(base_url() . 'admin/konfigurasi_transaksi/', 'refresh');
			}
			
        }
        $page_data['page_access'] = "admin";
        $page_data['page_name'] = 'konfigurasi_transaksi';
        $page_data['page_now'] = 'Konfigurasi Transaksi';
        $this->load->view('index', $page_data);

    }
	/** *Group User* **/

    function group_user($param1 = '', $param2 = '', $param3 = '') {

        if ($this->session->userdata('login') != 'A')

            $this->logout();

		$date = new DateTime();

		$id=$this->session->userdata('user_id');

        $page_data['page_action'] = 'list';
         $page_data['page_title'] = 'Daftar Group User';
		$page_data['page_access'] = "admin";
		$page_data['page_name'] = 'group_user';
		$page_data['page_now'] = 'Administrator';
		$page_data['modul']=$this->md_siperpus_sysmodul->getModulAll();
        if ($param1 == 'submit') {

			$data['idsysgroup'] = $this->input->post('id');
			$data['name'] = $this->input->post('nama');
			$data['def_modul'] = $this->input->post('default');
			
			if( $data['def_modul']=='' || $data['idsysgroup']=='' || $data['name']==''){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-danger');

				$this->session->set_flashdata('flash_message', 'Empty Field');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
			}else{
				$Group=$this->md_siperpus_sysgroup->getGroupById($this->input->post('id'));
				
				if($Group){
					$this->session->set_flashdata('alert', 'alert-danger');

					$this->session->set_flashdata('flash_message', 'ID telah dipakai,Group User gagal dibuat');
					echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "ID telah dipakai, User Gagal Dibuat"));

				}else{
					$this->md_siperpus_sysgroup->addGroup($data);
					
					$this->session->set_flashdata('alert', 'alert-focus');

					$this->session->set_flashdata('flash_message', 'Group User Sukses dibuat');
					echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Group User Sukses dibuat"));
					//redirect(base_url() . 'admin/klasifikasi_buku', 'refresh');
				}
			}
        }else if ($param1 == 'update') {

			$id1 = $this->input->post('id1');
			$data['idsysgroup'] = $this->input->post('id');
			$data['name'] = $this->input->post('nama');
			$data['def_modul'] = $this->input->post('default');
			
			if($id1=='' || $data['def_modul']=='' || $data['idsysgroup']=='' || $data['name']==''){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-danger');

				$this->session->set_flashdata('flash_message', 'Empty Field');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
			}else{
				$this->md_siperpus_sysgroup->updateGroup($id1, $data);
				$this->session->set_flashdata('alert', 'alert-focus');
				$this->session->set_flashdata('flash_message', 'Group User Sukses diedit');
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Group User Sukses diedit"));
			}
			
        }else if($param1 =='edit' && $param2 !=''){
			$data = $this->md_siperpus_sysgroup->getGroupById($param2);
			echo json_encode($data);

		}else if($param1 =='fetch'){
			if($this->input->post('datatable[query][generalSearch]'))$total=$this->md_siperpus_sysgroup->countFiltered();
			else $total=$this->md_siperpus_sysgroup->countAll();
			$page=$this->input->post('datatable[pagination][page]');
			if($page<1)$page=1;
			$perpage=10;
			$pages=$total/$perpage;
			$field=$this->input->post('datatable[sort][field]');
			if($field=='')$field=$this->input->post('datatable[pagination][field]');
			$sort=$this->input->post('datatable[sort][sort]');
			if($sort=='')$sort=$this->input->post('datatable[pagination][sort]');
			$data = array();
			$no = 0;
			$list=$this->md_siperpus_sysgroup->getDatatables();
			foreach ($list as $row) {
				$no++;
				$arr = array();
				$arr['number'] = ($perpage*($page-1))+$no;
				$arr['id'] = $row->idsysgroup;
				$arr['nama'] = $row->name;
				$modul=$this->md_siperpus_sysmodul->getModulById($row->def_modul);
				if($modul)$arr['def'] = $modul[0]->name;
				else $arr['def']='';
				
				$data[] = $arr;
			}
			$meta=array();
			$meta['page']=$page;
			$meta['pages']=$pages;
			$meta['perpage']=$perpage;
			$meta['total']=$total;
			$meta['sort']=$sort;
			$meta['field']=$field;
			$output = array(
							"meta" => $meta,
							"data" => $data
					);
			//output to json format
			echo json_encode($output);

		}else{
			$this->load->view('index', $page_data);
		}
    }
	/** *Daftar User* **/
	
    function daftar_user($param1 = '', $param2 = '', $param3 = '') {

        if ($this->session->userdata('login') != 'A')

            $this->logout();

		$date = new DateTime();

		$id=$this->session->userdata('user_id');

        $page_data['page_action'] = 'list';
         $page_data['page_title'] = 'Daftar User Program';
		$page_data['page_access'] = "admin";
		$page_data['page_name'] = 'daftar_user';
		$page_data['page_now'] = 'Administrator';
		$page_data['sysgroup']=$this->md_siperpus_sysgroup->getGroupAll();
        if ($param1 == 'submit') {

			$data['idsysuser'] = $this->input->post('id');
			$data['name'] = $this->input->post('nama');
			$data['pass'] = $this->input->post('password');
			$confirm = $this->input->post('password2');
			$data['idsysgroup'] = $this->input->post('group');
			$data['active'] = $this->input->post('status');
			if($data['pass']!=$confirm){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-danger');

				$this->session->set_flashdata('flash_message', 'Password Tidak Sama');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Password Tidak Sama"));
			}else if($data['idsysuser']=='' || $data['pass']=='' || $data['name']=='' || $data['idsysgroup']=='' || $data['active']==''){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-danger');

				$this->session->set_flashdata('flash_message', 'Empty Field');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
			}else{
				$user=$this->md_siperpus_sysuser->getUserById($this->input->post('id'));
				
				if($user){
					$this->session->set_flashdata('alert', 'alert-danger');

					$this->session->set_flashdata('flash_message', 'ID telah dipakai, User gagal dibuat');
					echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "ID telah dipakai, User Gagal Dibuat"));

				}else{
					$this->md_siperpus_sysuser->addUser($data);
					
					$this->session->set_flashdata('alert', 'alert-focus');

					$this->session->set_flashdata('flash_message', 'User Sukses dibuat');
					echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "User Sukses dibuat"));
					//redirect(base_url() . 'admin/klasifikasi_buku', 'refresh');
				}
			}
        }else if ($param1 == 'update') {

			$id1 = $this->input->post('id1');
			$data['idsysuser'] = $this->input->post('id');
			$data['name'] = $this->input->post('nama');
			$pass = $this->input->post('password');
			$confirm = $this->input->post('password2');
			$data['idsysgroup'] = $this->input->post('group');
			$data['active'] = $this->input->post('status');
			
			if( $pass != $confirm && $confirm != '' ){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-danger');

				$this->session->set_flashdata('flash_message', 'Password Tidak Sama');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Password Tidak Sama"));
			}else if($id1=='' || $data['idsysuser']=='' || $pass=='' || $data['name']=='' || $data['idsysgroup']=='' || $data['active']==''){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-danger');

				$this->session->set_flashdata('flash_message', 'Empty Field');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
			}else{
				
				//$data['pass'] = $pass;
			
				$this->md_siperpus_sysuser->updateUser($id1, $data);

				$this->session->set_flashdata('alert', 'alert-focus');

				$this->session->set_flashdata('flash_message', 'User Sukses diedit');
				//redirect(base_url() . 'admin/klasifikasi_buku', 'refresh');
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "User Sukses diedit"));
			}
			
        }else if ($param1=='hapus' && $param2 !='') {
				$this->md_siperpus_sysuser->hapusUser($param2);
				$this->session->set_flashdata('alert', 'alert-focus');
				$this->session->set_flashdata('flash_message', 'User Sukses Dihapus');
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "User Sukses Dihapus"));
		}else if($param1 =='pass' && $param2 !=''){
			$data = $this->md_siperpus_sysuser->getUserById($param2);
			echo json_encode(array("status" => TRUE,"pass" => $data[0]->pass));

		}else if($param1 =='edit' && $param2 !=''){
			$data = $this->md_siperpus_sysuser->getUserById($param2);
			echo json_encode($data);

		}else if($param1 =='fetch'){
			if($this->input->post('datatable[query][generalSearch]') || $this->input->post('datatable[query][group]')||$this->input->post('datatable[query][status]')||$this->input->post('datatable[query][status]')=='0')$total=$this->md_siperpus_sysuser->countFiltered();
			else $total=$this->md_siperpus_sysuser->countAll();
			$page=$this->input->post('datatable[pagination][page]');
			if($page<1)$page=1;
			$perpage=10;
			$pages=$total/$perpage;
			$field=$this->input->post('datatable[sort][field]');
			if($field=='')$field=$this->input->post('datatable[pagination][field]');
			$sort=$this->input->post('datatable[sort][sort]');
			if($sort=='')$sort=$this->input->post('datatable[pagination][sort]');
			$data = array();
			$no = 0;
			$list=$this->md_siperpus_sysuser->getDatatables();
			foreach ($list as $row) {
				$no++;
				$arr = array();
				$arr['number'] = ($perpage*($page-1))+$no;
				$arr['id'] = $row->idsysuser;
				$arr['nama'] = $row->name;
				$arr['pass'] = "******";
				$arr['group'] = $row->idsysgroup;
				if($row->active ==1)$arr['active'] = "Aktif";
				else $arr['active'] = "Non-Aktif";
				
				$data[] = $arr;
			}
			$meta=array();
			$meta['page']=$page;
			$meta['pages']=$pages;
			$meta['perpage']=$perpage;
			$meta['total']=$total;
			$meta['sort']=$sort;
			$meta['field']=$field;
			$output = array(
							"meta" => $meta,
							"data" => $data
					);
			//output to json format
			echo json_encode($output);

		}else{
			$this->load->view('index', $page_data);
		}
    }
	/** *User Grant* **/
	
    function user_grant($param1 = '', $param2 = '', $param3 = '') {

        if ($this->session->userdata('login') != 'A')

            $this->logout();

		$date = new DateTime();

		$id=$this->session->userdata('user_id');

        $page_data['page_action'] = 'list';
         $page_data['page_title'] = 'Daftar Hak Akses User';
		$page_data['page_access'] = "admin";
		$page_data['page_name'] = 'user_grant';
		$page_data['page_now'] = 'Administrator';
		$page_data['group']=$this->md_siperpus_sysgroup->getGroupAll();
        $page_data['modul']=$this->md_siperpus_sysmodul->getModulAll();
        if ($param1 == 'submit') {

			$id=$this->md_siperpus_sysgrant->getLastId();
			$data['idsysgrant'] = $id+1;
			$data['idsysmodul'] = $this->input->post('modul');
			$data['idsysgroup'] = $this->input->post('group');
			if($this->input->post('add') && $this->input->post('add')==1)$data['allow_add'] = 1;
			else $data['allow_add'] = 0;
			if($this->input->post('edit') && $this->input->post('edit')==1)$data['allow_edit'] = 1;
			else $data['allow_edit'] = 0;
			if($this->input->post('delete') && $this->input->post('delete')==1)$data['allow_delete'] = 1;
			else $data['allow_delete'] = 0;
			if($this->input->post('view') && $this->input->post('view')==1)$data['allow_view'] = 1;
			else $data['allow_view'] = 0;
			if($this->input->post('print') && $this->input->post('print')==1)$data['allow_print'] = 1;
			else $data['allow_print'] = 0;
			if($data['idsysmodul']=='' || $data['idsysgroup']==''){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-danger');

				$this->session->set_flashdata('flash_message', 'Empty Field');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
			}else{
				$user=$this->md_siperpus_sysgrant->getGrantByModul($data['idsysmodul'],$data['idsysgroup']);
				
				if($user){
					$this->session->set_flashdata('alert', 'alert-danger');

					$this->session->set_flashdata('flash_message', 'ID telah dipakai,Grant User gagal dibuat');
					echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Akses Modul Telah Di tambahakan Sebelumnya"));

				}else{
					$this->md_siperpus_sysgrant->addGrant($data);
					
					$this->session->set_flashdata('alert', 'alert-focus');

					$this->session->set_flashdata('flash_message', 'Grant User Sukses dibuat');
					echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Grant User Sukses dibuat"));
					//redirect(base_url() . 'admin/klasifikasi_buku', 'refresh');
				}
			}
        }else if ($param1 == 'update') {

			$id1 = $this->input->post('id1');
			$data['idsysmodul'] = $this->input->post('modul');
			$data['idsysgroup'] = $this->input->post('group');
			if($this->input->post('add')==1)$data['allow_add'] = 1;
			else $data['allow_add'] = 0;
			if($this->input->post('edit')==1)$data['allow_edit'] = 1;
			else $data['allow_edit'] = 0;
			if($this->input->post('delete')==1)$data['allow_delete'] = 1;
			else $data['allow_delete'] = 0;
			if($this->input->post('view')==1)$data['allow_view'] = 1;
			else $data['allow_view'] = 0;
			if($this->input->post('print')==1)$data['allow_print'] = 1;
			else $data['allow_print'] = 0;
			if($id1=='' || $data['idsysmodul']=='' || $data['idsysgroup']==''){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-danger');

				$this->session->set_flashdata('flash_message', 'Password Tidak Sama');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Password Tidak Sama"));
			}else{
				
				//$data['pass'] = $pass;
			
				$this->md_siperpus_sysgrant->updateGrant($id1, $data);

				$this->session->set_flashdata('alert', 'alert-focus');

				$this->session->set_flashdata('flash_message', 'Hak Akses Sukses diedit');
				//redirect(base_url() . 'admin/klasifikasi_buku', 'refresh');
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Hak Akses Sukses diedit"));
			}
			
        }else if ($param1=='hapus' && $param2 !='') {
				$this->md_siperpus_sysgrant->hapusGrant($param2);
				$this->session->set_flashdata('alert', 'alert-focus');
				$this->session->set_flashdata('flash_message', 'Hak Akses Sukses Dihapus');
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Hak Akses Sukses Dihapus"));
		}else if($param1 =='edit' && $param2 !=''){
			$data = $this->md_siperpus_sysgrant->getGrantById($param2);
			echo json_encode($data);

		}else if($param1 =='fetch'){
			$total=$this->md_siperpus_sysgrant->countFiltered();
			$page=$this->input->post('datatable[pagination][page]');
			if($page<1)$page=1;
			$perpage=10;
			$pages=$total/$perpage;
			$field=$this->input->post('datatable[sort][field]');
			if($field=='')$field=$this->input->post('datatable[pagination][field]');
			$sort=$this->input->post('datatable[sort][sort]');
			if($sort=='')$sort=$this->input->post('datatable[pagination][sort]');
			$data = array();
			$no = 0;
			$list=$this->md_siperpus_sysgrant->getDatatables();
			foreach ($list as $row) {
				$no++;
				$arr = array();
				$arr['number'] = ($perpage*($page-1))+$no;
				$arr['id'] = $row->idsysgrant;
				$modul=$this->md_siperpus_sysmodul->getModulById($row->idsysmodul);
				if($modul)$arr['nama'] = $modul[0]->name;
				$arr['add'] = $row->allow_add;
				$arr['edit'] = $row->allow_edit;
				$arr['delete'] = $row->allow_delete;
				$arr['view'] = $row->allow_view;
				$arr['print'] = $row->allow_print;
				
				$data[] = $arr;
			}
			$meta=array();
			$meta['page']=$page;
			$meta['pages']=$pages;
			$meta['perpage']=$perpage;
			$meta['total']=$total;
			$meta['sort']=$sort;
			$meta['field']=$field;
			$output = array(
							"meta" => $meta,
							"data" => $data
					);
			//output to json format
			echo json_encode($output);

		}else{
			$this->load->view('index', $page_data);
		}
    }
}