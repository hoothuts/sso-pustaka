<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Md_siperpus_buku extends CI_Model {

   function getBuku() {
		 $hasil = $this->db->query("SELECT * FROM siperpus_buku order by judul asc limit 20");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
    }
}