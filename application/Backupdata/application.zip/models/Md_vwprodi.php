<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Md_vwprodi extends CI_Model {

   function getProdiAll() {
		 $hasil = $this->db->query("SELECT * FROM vwprodi order by nmmspst asc");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                $data[] = $row;
            }
            //$data['baris']=$this->db->query("SELECT MAX(idkategori) FROM siperpus_kategori")
            return $data;
        }
    }
}
