<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Md_vwsiswa extends CI_Model {

   function getSiswaAll() {
		 $hasil = $this->db->query("SELECT * FROM vwsiswa order by nis asc");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
    }
	function getSiswaById($id) {
        $hasil = $this->db->get_where('vwsiswa', array('nis	' => $id))->result();
        $data = $hasil;
        return $data;
    }
}