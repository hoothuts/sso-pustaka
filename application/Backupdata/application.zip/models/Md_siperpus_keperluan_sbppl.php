<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Md_siperpus_keperluan_sbppl extends CI_Model {

   function getSbpplAll() {
		 $hasil = $this->db->query("SELECT * FROM siperpus_sbppl_keperluan order by no_urut asc");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                $data[] = $row;
            }
            //$data['baris']=$this->db->query("SELECT MAX(idkategori) FROM siperpus_kategori")
            return $data;
        }
    }
	 function addSbppl($data){
         $this->db->insert('siperpus_sbppl_keperluan', $data);
    }
   function hapusSbppl($data)
    {
      $this->db->where('id',$data);
      $this->db->delete('siperpus_sbppl_keperluan');
    }
   function updateSbppl($param,$data){
        $this->db->where('id', $param);
        $this->db->update('siperpus_sbppl_keperluan', $data);
    }
	 function getSbpplById($id) {
        $hasil = $this->db->get_where('siperpus_sbppl_keperluan', array('id' => $id))->result();
        $data = $hasil;
        return $data;
    }

}
