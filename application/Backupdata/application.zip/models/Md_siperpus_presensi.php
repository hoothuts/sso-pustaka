<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Md_siperpus_presensi extends CI_Model {

   function getPresensi7Hari() {
		 $hasil = $this->db->query("SELECT distinct(tanggal) FROM siperpus_presensi group by DATE_FORMAT(tanggal, '%c %d %Y') order by tanggal desc limit 7 ");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
    }
	function getJumlah($date) {
         $hasil = $this->db->query("SELECT count(*) as jumlah FROM siperpus_presensi where cast(tanggal as date) = '$date'");
        
		if ($hasil->num_rows() > 0) {
             foreach ($hasil->result() as $row) {
                $data[] = $row;
            }
            return $data[0]->jumlah;
        }else{
			return 0;
		}
    }
}