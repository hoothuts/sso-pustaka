<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Md_siperpus_kategori_buku extends CI_Model {

   function getKategoriBukuAll() {
		 $hasil = $this->db->query("SELECT * FROM siperpus_kategori order by nmkategori asc");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                $data[] = $row;
            }
            //$data['baris']=$this->db->query("SELECT MAX(idkategori) FROM siperpus_kategori")
            return $data;
        }
    }
	 function addKategoriBuku($data){
         $this->db->insert('siperpus_kategori', $data);
    }
   function hapusKategoriBuku($data)
    {
      $this->db->where('idkategori',$data);
      $this->db->delete('siperpus_kategori');
    }
   function updateKategoriBuku($param,$data){
        $this->db->where('idkategori', $param);
        $this->db->update('siperpus_kategori', $data);
    }
	 function getKategoriById($id) {
        $hasil = $this->db->get_where('siperpus_kategori', array('idkategori' => $id))->result();
        $data = $hasil;
        return $data;
    }

}
