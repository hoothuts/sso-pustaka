<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Md_siperpus_asal_buku extends CI_Model {

   function getAsalBukuAll() {
		 $hasil = $this->db->query("SELECT * FROM siperpus_asal_buku order by nama asc");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                $data[] = $row;
            }
            //$data['baris']=$this->db->query("SELECT MAX(idkategori) FROM siperpus_kategori")
            return $data;
        }
    }
	 function addAsalBuku($data){
         $this->db->insert('siperpus_asal_buku', $data);
    }
   function hapusAsalBuku($data)
    {
      $this->db->where('id',$data);
      $this->db->delete('siperpus_asal_buku');
    }
   function updateAsalBuku($param,$data){
        $this->db->where('id', $param);
        $this->db->update('siperpus_asal_buku', $data);
    }
	 function getAsalBukuById($id) {
        $hasil = $this->db->get_where('siperpus_asal_buku', array('id' => $id))->result();
        $data = $hasil;
        return $data;
    }

}
