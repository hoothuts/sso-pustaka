<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Md_siperpus_data_buku extends CI_Model {

   function getDataBukuAll() {
		 $hasil = $this->db->query("SELECT * FROM siperpus_buku WHERE kd_penerbit='1565' order by judul asc");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                $data[] = $row;
            }
            //$data['baris']=$this->db->query("SELECT MAX(idkategori) FROM siperpus_kategori")
            return $data;
        }
    }
	 function addDataBuku($data){
         $this->db->insert('siperpus_buku', $data);
    }
   function hapusDataBuku($data)
    {
      $this->db->where('id',$data);
      $this->db->delete('siperpus_buku');
    }
   function updateDataBuku($param,$data){
        $this->db->where('id', $param);
        $this->db->update('siperpus_buku', $data);
    }
	 function getDataBukuById($id) {
        $hasil = $this->db->get_where('siperpus_buku', array('id' => $id))->result();
        $data = $hasil;
        return $data;
    }

}
