<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Md_siperpus_bahasa extends CI_Model {

   function getBahasaAll() {
		 $hasil = $this->db->query("SELECT * FROM siperpus_bahasa order by no_urut asc");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                $data[] = $row;
            }
            //$data['baris']=$this->db->query("SELECT MAX(idkategori) FROM siperpus_kategori")
            return $data;
        }
    }
	 function addBahasa($data){
         $this->db->insert('siperpus_bahasa', $data);
    }
   function hapusBahasa($data)
    {
      $this->db->where('id',$data);
      $this->db->delete('siperpus_bahasa');
    }
   function updateBahasa($param,$data){
        $this->db->where('id', $param);
        $this->db->update('siperpus_bahasa', $data);
    }
	 function getBahasaById($id) {
        $hasil = $this->db->get_where('siperpus_bahasa', array('id' => $id))->result();
        $data = $hasil;
        return $data;
    }

}
