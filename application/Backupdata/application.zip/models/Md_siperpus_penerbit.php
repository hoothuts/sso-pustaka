<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Md_siperpus_penerbit extends CI_Model {

   function getPenerbitAll() {
		 $hasil = $this->db->query("SELECT * FROM siperpus_penerbit order by nama_penerbit asc");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                $data[] = $row;
            }
            //$data['baris']=$this->db->query("SELECT MAX(idkategori) FROM siperpus_kategori")
            return $data;
        }
    }
	 function addPenerbit($data){
         $this->db->insert('siperpus_penerbit', $data);
    }
   function hapusPenerbit($data)
    {
      $this->db->where('kd_penerbit',$data);
      $this->db->delete('siperpus_penerbit');
    }
   function updatePenerbit($param,$data){
        $this->db->where('kd_penerbit', $param);
        $this->db->update('siperpus_penerbit', $data);
    }
	 function getPenerbitById($id) {
        $hasil = $this->db->get_where('siperpus_penerbit', array('kd_penerbit' => $id))->result();
        $data = $hasil;
        return $data;
    }

}
