<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Md_siperpus_matakuliah extends CI_Model {

   function getMatakuliahAll() {
		 $hasil = $this->db->query("SELECT * FROM vwmk order by nmtbkmk asc");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                $data[] = $row;
            }
            //$data['baris']=$this->db->query("SELECT MAX(idkategori) FROM siperpus_kategori")
            return $data;
        }
    }
	 function addMatakuliah($data){
         $this->db->insert('vwmk', $data);
    }
   function hapusMatakuliah($data)
    {
      $this->db->where('id',$data);
      $this->db->delete('vwmk');
    }
   function updateMatakuliah($param,$data){
        $this->db->where('id', $param);
        $this->db->update('vwmk', $data);
    }
	 function getMatakuliahById($id) {
        $hasil = $this->db->get_where('vwmk', array('id' => $id))->result();
        $data = $hasil;
        return $data;
    }

}
