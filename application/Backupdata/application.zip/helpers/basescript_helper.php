<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!--begin::Base Scripts -->
		<script src="<?php echo base_url();?>assets/vendors/base/vendors.bundle.js" type="text/javascript"></script>
		<script src="<?php echo base_url();?>assets/demo/default/base/scripts.bundle.js" type="text/javascript"></script>
		<!-- end::Base Scripts -->
		<!--begin::Page Vendors -->
		<script src="<?php echo base_url();?>assets/vendors/custom/fullcalendar/fullcalendar.bundle.js" type="text/javascript"></script>
		<!-- begin::Page Snippets -->
		<script src="<?php echo base_url();?>assets/app/js/dashboard.js" type="text/javascript"></script>
