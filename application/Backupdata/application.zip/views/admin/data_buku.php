<!-- begin::Body -->
<div class="m-grid__item m-grid__item--fluid m-grid m-grid--hor-desktop m-grid--desktop m-body">
					<div class="m-grid__item m-grid__item--fluid  m-grid m-grid--ver	m-container m-container--responsive m-container--xxl m-page__container">
				<div class="m-grid__item m-grid__item--fluid m-wrapper">
					<div class="m-content">
						<?php if ($this->session->flashdata('flash_message') != ""):?>
						<div class="m-alert m-alert--icon m-alert--air m-alert--square alert alert-dismissible m--margin-bottom-30" role="alert">
							<div class="m-alert__icon">
								<i class="flaticon-exclamation m--font-brand"></i>
							</div>
							<div class="m-alert__text">
								<?php echo $this->session->flashdata('flash_message'); ?>
							</div>
						</div>
					<?php endif; ?>

						<?php if($page_action =='list'){?>
						<div class="m-portlet m-portlet--mobile">
							<div class="m-portlet__head">
								<div class="m-portlet__head-caption">
									<div class="m-portlet__head-title">
										<h3 class="m-portlet__head-text">
											<?php echo $page_title;?>
												<a href="<?php echo base_url();?><?php echo $page_access;?>/<?php echo $page_name;?>/tambah/">
															<button type="button" class="m-btn btn btn-info">
																Tambah <i class="flaticon-add"></i>
															</button>
												</a>
										</h3>
									</div>
								</div>
							</div>
							<div class="m-portlet__body">
								<!--begin: Search Form -->
								<!--begin: Datatable -->
								<?php
								if($data){
								?>
								    <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_6">
	                    <thead>
												<tr>
														<th style="width:3%"> No </th>
														<th style="width:5%"> No. Klas</th>
														<th> Judul Buku </th>
														<th style="width:10%"> Penulis </th>
														<th> Penerbit </th>
														<th style="width:3%"> Jumlah Buku </th>
														<th style="width:3%"> Dipinjam </th>
														<th style="width:3%"> MK </th>
														<th style="width:3%"> Prodi </th>
														<th> Aksi </th>
												</tr>

	                    </thead>
	                    <tbody>
										<?php
										$count=0;
										foreach($data as $row){
										$count++;
										?>
                      <tr class="odd gradeX">
												<td> <?php echo $count;?> </td>
												<td> <?php echo $row->no_klas;?></td>
												<td> <?php echo $row->judul;?> </td>
												<td> <?php echo $row->penulis;?> </td>
												<td> <?php echo $row->kd_penerbit;?> </td>
												<td> <?php echo $row->jml_buku;?> </td>
												<td> <?php //echo $row->judul;?> </td>
												<td> <?php //echo $row->judul;?> </td>
												<td> <?php //echo $row->judul;?> </td>
													<td>
													<div class="btn-group" role="group" aria-label="Menu">
														<a href="<?php echo base_url();?><?php echo $page_access;?>/<?php echo $page_name;?>/edit/<?php echo $row->no_klas;?>">
															<button type="button" class="m-btn btn btn-warning">
																Edit <i class="la la-files-o"></i>
															</button>
														</a>
														<a href="<?php echo base_url();?><?php echo $page_access;?>/<?php echo $page_name;?>/hapus/<?php echo $row->no_klas;?>">
															<button onclick="return confirm('Are you sure you want to delete this data?')" type="button" class="m-btn btn btn-warning">
																Hapus <i class="la la-files-o"></i>
															</button>
														</a>
													</div>
													</td>
                      </tr>
										<?php }?>
                    </tbody>
                  </table>
                <?php
								}
								?>
								<!--end: Datatable -->
							</div>
						</div>
						<?php } ?>

					<?php if($page_action =='tambah'){?>
							<div class="m-portlet">
									<div class="m-portlet__head">
										<div class="m-portlet__head-caption">
											<div class="m-portlet__head-title">
												<span class="m-portlet__head-icon m--hide">
													<i class="la la-gear"></i>
												</span>
												<h3 class="m-portlet__head-text">
													<?php echo $page_title;?>
												</h3>
											</div>
										</div>
									</div>
									<!--begin::Form-->
									<form method="post" action="<?php echo base_url();?><?php echo $page_access;?>/<?php echo $page_name;?>/submit/" class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed">
										<div class="m-portlet__body">
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													Nomor Klasifikasi:
												</label>
												<div class="col-lg-3">
													<input type="text" name="no_klas" class="form-control m-input" placeholder="Nomor Klasifikasi">
													<span class="m-form__help">
														Masukkan Nomor Klasifikasi
													</span>
												</div>
												<label class="col-lg-2 col-form-label">
													ISBN/ISSN :
												</label>
												<div class="col-lg-3">
													<input type="text" name="isbn" class="form-control m-input" placeholder="ISBN/ISSN">
													<button type="button" class="btn ">Check It ? <i class="la la-files-o"></i></button>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													Kelompok Buku:
												</label>
												<div class="col-lg-3">
													<select class="form-control" name="buku">
														<?php
														$x=0;
														foreach($data['kel_buku'] as $i){
														$x++;?>
														<option value="<?php echo $i->nmkategori?>"><?php echo $i->nmkategori?></option>
													<?php } ?>
													</select>
													<span class="m-form__help">
														Masukkan Kelompok Buku
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													Judul Buku:
												</label>
												<div class="col-lg-9">
													<input type="text" name="judul" class="form-control m-input" placeholder="Masukkan Judul Buku">
													<span class="m-form__help">
														Masukkan Judul Buku
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													Penggalan Judul Katalog:
												</label>
												<div class="col-lg-9">
													<input type="text" name="cetakkatalog_judulpenggal" class="form-control m-input" placeholder="Masukkan Penggalan Judul Katalog">
													<span class="m-form__help">
														Pengalan Judul Katalog
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													Judul Asli:
												</label>
												<div class="col-lg-9">
													<input type="text" name="judulasli" class="form-control m-input" placeholder="Masukkan Judul Asli">
													<span class="m-form__help">
														Masukkan Judul Asli
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													Deskripsi Buku:
												</label>
												<div class="col-lg-6">
													<label class="m-checkbox m-checkbox--solid">
														<input type="checkbox" name="komentar_publik">Perbolehkan Komentar Publik
														<span></span>
													</label>
													<textarea name="des_buku" class="form-control" rows="6" placeholder="Masukkan Deskripsi Buku"></textarea>
													<span class="m-form__help">
														Deskripsi Buku Boleh Dikosongkan
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													Penulis:
												</label>
												<div class="col-lg-3">
													<input type="text" name="penulis" class="form-control m-input" placeholder="Penulis">
													<span class="m-form__help">
														Masukkan Penulis
													</span>
												</div>
												<label class="col-lg-2 col-form-label">
													Penyadur :
												</label>
												<div class="col-lg-3">
													<input type="text" name="penyadur" class="form-control m-input" placeholder="Masukkan Penyadur">
													<span class="m-form__help">
														Masukkan Penyadur
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													Penerjemah:
												</label>
												<div class="col-lg-3">
													<input type="text" name="penerjemah" class="form-control m-input" placeholder="Masukkan Penerjemah">
													<span class="m-form__help">
														Masukkan Penerjemah
													</span>
												</div>
												<label class="col-lg-2 col-form-label">
													Penyusun:
												</label>
												<div class="col-lg-3">
													<input type="text" name="penyusun" class="form-control m-input" placeholder="Masukkan Penyusun">
													<span class="m-form__help">
														Masukkan Penyusun
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													Penyunting:
												</label>
												<div class="col-lg-3">
													<input type="text" name="penyunting" class="form-control m-input" placeholder="Masukkan Penyunting">
													<span class="m-form__help">
														Masukkan Penyunting
													</span>
												</div>
												<label class="col-lg-2 col-form-label">
													Illustrator:
												</label>
												<div class="col-lg-3">
													<input type="text" name="illustrator" class="form-control m-input" placeholder="Illustrator">
													<span class="m-form__help">
														Masukkan Illustrator
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													Editor:
												</label>
												<div class="col-lg-3">
													<input type="text" name="editor" class="form-control m-input" placeholder="Editor">
													<span class="m-form__help">
														Masukkan Editor
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													Edisi :
												</label>
												<div class="col-lg-2">
													<input type="text" name="edisi" class="form-control m-input" placeholder="Edisi">
													<span class="m-form__help">
														Masukkan Edisi
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													Cetakan :
												</label>
												<div class="col-lg-2">
													<input type="text" name="cetakan" class="form-control m-input" placeholder="Cetakan">
													<span class="m-form__help">
														Masukkan Cetakan
													</span>
												</div>
											</div>

											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													Penerbit :
												</label>
												<div class="col-lg-3">
													<select class="form-control m-input--fixed" name="penerbit">
														<?php
														$x=0;
														foreach($data['penerbit'] as $i){
														$x++;?>
														<option value="<?php echo $i->nama_penerbit?>"><?php echo $i->nama_penerbit?></option>
													<?php } ?>
													</select>
													<button type="button" class="btn ">Tambah Penerbit <i class="la la-files-o"></i></button>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													Tahun Terbit :
												</label>
												<div class="col-lg-2">
													<input type="text" name="thn_terbit" class="form-control m-input" placeholder="Tahun Terbit">
													<span class="m-form__help">
														Masukkan Tahun Terbit
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													Jilid :
												</label>
												<div class="col-lg-2">
													<input type="text" name="jilid" class="form-control m-input" placeholder="Jilid">
													<span class="m-form__help">
														Masukkan Jilid
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													No. Hal. Romawi :
												</label>
												<div class="col-lg-2">
													<input type="text" name="hlm_romawi" class="form-control m-input">
													<span class="m-form__help">
														Masukkan Nomor Halaman Romawi
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													Jumlah Halaman :
												</label>
												<div class="col-lg-2">
													<input type="text" name="jml_hal" class="form-control m-input">
													<span class="m-form__help">
														Masukkan Jumlah Halaman
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													Ilustrasi :
												</label>
												<div class="col-lg-2">
													<label class="m-checkbox m-checkbox--solid">
														<input name="ilustrasi" type="checkbox">Tandai jika ada ilustrasi
														<span></span>
													</label>
												</div>
												<label class="col-lg-2 col-form-label">
													Tabel :
												</label>
												<div class="col-lg-2">
													<label class="m-checkbox m-checkbox--solid">
														<input name="tabel" type="checkbox">Tandai jika ada tabel
														<span></span>
													</label>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													Ukuran Fisik :
												</label>
												<div class="col-lg-2">
													<input type="text" name="ukuran_fisik" class="form-control m-input">
													<span class="m-form__help">
														Masukkan Ukuran Fisik (cm)
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													Bibliografi :
												</label>
												<div class="col-lg-3">
													<input type="text" name="bibliografi" class="form-control m-input" placeholder="Bibliografi">
													<span class="m-form__help">
														Masukkan Bibliografi
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													Index :
												</label>
												<div class="col-lg-3">
													<input type="text" name="index" class="form-control m-input" placeholder="Index">
													<span class="m-form__help">
														Masukkan Index
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													Bahasa :
												</label>
												<div class="col-lg-3">
													<select class="form-control m-input--fixed" name="bahasa">
														<?php
														$x=0;
														foreach($data['bahasa'] as $i){
														$x++;?>
														<option value="<?php echo $i->nama?>"><?php echo $i->nama?></option>
													<?php } ?>
													</select>

												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													No. Rak :
												</label>
												<div class="col-lg-2">
													<input type="text" name="no_rak" class="form-control m-input">
													<span class="m-form__help">
														Masukkan No. Rak
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													Seri :
												</label>
												<div class="col-lg-5">
													<input type="text" name="seri" class="form-control m-input" placeholder="Seri">
													<span class="m-form__help">
														Masukkan Seri
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													Tajuk Utama :
												</label>
												<div class="col-lg-5">
													<input type="text" name="tajuk_utama" class="form-control m-input" placeholder="Tajuk Utama ">
													<span class="m-form__help">
														Masukkan Tajuk Utama
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													Tajuk Subyek :
												</label>
												<div class="col-lg-5">
													<input type="text" name="tajuk_subyek" class="form-control m-input" placeholder="Tajuk Subyek">
													<span class="m-form__help">
														Masukkan Tajuk Subyek
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													Mata Kuliah Terkait :
												</label>
												<div class="col-lg-5">
													<textarea name="matkul" class="form-control" rows="6" placeholder="Masukkan Deskripsi Buku"></textarea>
													<span class="m-form__help">
														Masukkan Mata Kuliah Terkait
													</span>
												</div>
											</div>
										</div>
										<div class="m-portlet__foot m-portlet__no-border m-portlet__foot--fit">
											<div class="m-form__actions m-form__actions--solid">
												<div class="row">
													<div class="col-lg-2"></div>
													<div class="col-lg-10">
														<button type="submit" class="btn btn-success">
															Submit
														</button>
														<button type="reset" class="btn btn-secondary">
															Cancel
														</button>
													</div>
												</div>
											</div>
										</div>
									</form>
									<!--end::Form-->
								</div>

						<?php } ?>
						<?php if($page_action =='edit'){?>
							<?php if($data){?>
							<div class="m-portlet">
									<div class="m-portlet__head">
										<div class="m-portlet__head-caption">
											<div class="m-portlet__head-title">
												<span class="m-portlet__head-icon m--hide">
													<i class="la la-gear"></i>
												</span>
												<h3 class="m-portlet__head-text">
													<?php echo $page_title;?>
												</h3>
											</div>
										</div>
									</div>
									<!--begin::Form-->
									<form method="post" action="<?php echo base_url();?><?php echo $page_access;?>/<?php echo $page_name;?>/update/<?php echo $data[0]->idkategori;?>" class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed">
										<div class="m-portlet__body">
											<div class="form-group m-form__group row">
												

											</div>
										</div>
										<div class="m-portlet__foot m-portlet__no-border m-portlet__foot--fit">
											<div class="m-form__actions m-form__actions--solid">
												<div class="row">
													<div class="col-lg-2"></div>
													<div class="col-lg-10">
														<button type="submit" class="btn btn-success">
															Submit
														</button>
														<button type="reset" class="btn btn-secondary">
															Cancel
														</button>
													</div>
												</div>
											</div>
										</div>
									</form>
									<!--end::Form-->
								</div>
							<?php } ?>
						<?php } ?>
					</div>
				</div>
			</div>
</div>
			<!-- end:: Body -->
