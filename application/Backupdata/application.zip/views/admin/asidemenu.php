<div id="m_aside_left" class="m-grid__item	m-aside-left  m-aside-left--skin-dark ">
<div 
		id="m_ver_menu" 
		class="m-aside-menu  m-aside-menu--skin-dark m-aside-menu--submenu-skin-dark " 
		data-menu-vertical="true"
		 data-menu-scrollable="false" data-menu-dropdown-timeout="500"  
		>
						<ul class="m-menu__nav  m-menu__nav--dropdown-submenu-arrow ">
							<li class="m-menu__item   <?php if($page_now=='dashboard') echo ' m-menu__item--active ';?>" aria-haspopup="true" >
								<a  href="<?php echo base_url();?>admin/dashboard" class="m-menu__link ">
									<i class="m-menu__link-icon flaticon-line-graph"></i>
									<span class="m-menu__link-title">
										<span class="m-menu__link-wrap">
											<span class="m-menu__link-text">
												Dashboard
											</span>
											<span class="m-menu__link-badge">
												<span class="m-badge m-badge--danger">
													2
												</span>
											</span>
										</span>
									</span>
								</a>
							</li>
							<li class="m-menu__section">
								<h4 class="m-menu__section-text">
									Master
								</h4>
								<i class="m-menu__section-icon flaticon-more-v3"></i>
							</li>
							<li class="m-menu__item  <?php if($page_now=='Data Induk') echo ' m-menu__item--active ';?>m-menu__item--submenu m-menu__item--rel"  data-menu-submenu-toggle="click" aria-haspopup="true">
											<a  href="#" class="m-menu__link m-menu__toggle">
												<i class="m-menu__link-icon flaticon-users"></i>
												<span class="m-menu__link-text">
													Data Induk
												</span>
												<i class="m-menu__ver-arrow la la-angle-right"></i>
											</a>
											<div class="m-menu__submenu m-menu__submenu--classic m-menu__submenu--left">
												<span class="m-menu__arrow m-menu__arrow--adjust"></span>
												<ul class="m-menu__subnav">
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/data_mahasiswa" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Data mahasiswa
																	</span>
																</span>
															</span>
														</a>
													</li>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/data_dosen" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Data Dosen
																	</span>
																</span>
															</span>
														</a>
													</li>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/data_anggota_luar" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Data Anggota Luar
																	</span>
																</span>
															</span>
														</a>
													</li>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/data_anggota" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Data Anggota
																	</span>
																	<!--
																	new data bubble
																	<span class="m-menu__link-badge">
																		<span class="m-badge m-badge--success">
																			2
																		</span>
																	</span>
																	-->
																</span>
															</span>
														</a>
													</li>
													
												</ul>
											</div>
										</li>
										<li class="m-menu__item  <?php if($page_now=='Data Referensi') echo ' m-menu__item--active ';?>m-menu__item--submenu m-menu__item--rel"  data-menu-submenu-toggle="click" aria-haspopup="true">
											<a  href="#" class="m-menu__link m-menu__toggle">
												<i class="m-menu__link-icon flaticon-book"></i>
												<span class="m-menu__link-text">
													Data Referensi
												</span>
												<i class="m-menu__ver-arrow la la-angle-right"></i>
											</a>
											<div class="m-menu__submenu m-menu__submenu--classic m-menu__submenu--left">
												<span class="m-menu__arrow m-menu__arrow--adjust"></span>
												<ul class="m-menu__subnav">
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/klasifikasi_buku" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Klasifikasi Buku
																	</span>
																</span>
															</span>
														</a>
													</li>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/kategori_buku" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Kategori Buku
																	</span>
																</span>
															</span>
														</a>
													</li>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/bahasa" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Bahasa
																	</span>
																</span>
															</span>
														</a>
													</li>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/asal_buku" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Asal Buku
																	</span>
																</span>
															</span>
														</a>
													</li>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/penerbit" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Penerbit
																	</span>
																</span>
															</span>
														</a>
													</li>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/keperluan_sbppl" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Keperluan SBPPL
																	</span>
																</span>
															</span>
														</a>
													</li>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/program_studi" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Program Studi
																	</span>
																</span>
															</span>
														</a>
													</li>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/matakuliah" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Matakuliah
																	</span>
																</span>
															</span>
														</a>
													</li>
													
												</ul>
											</div>
										</li>
										<li class="m-menu__item <?php if($page_now=='Buku Inventaris') echo ' m-menu__item--active ';?>  m-menu__item--submenu m-menu__item--rel"  data-menu-submenu-toggle="click" aria-haspopup="true">
											<a  href="#" class="m-menu__link m-menu__toggle">
												<i class="m-menu__link-icon flaticon-cogwheel-2"></i>
												<span class="m-menu__link-text">
													Buku & Inventarisasi
												</span>
												<i class="m-menu__ver-arrow la la-angle-right"></i>
											</a>
											<div class="m-menu__submenu m-menu__submenu--classic m-menu__submenu--left">
												<span class="m-menu__arrow m-menu__arrow--adjust"></span>
												<ul class="m-menu__subnav">
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/data_buku" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Data Buku
																	</span>
																</span>
															</span>
														</a>
													</li>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="#" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Inventaris
																	</span>
																</span>
															</span>
														</a>
													</li>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="#" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Buku Jurusan
																	</span>
																</span>
															</span>
														</a>
													</li>
												</ul>
											</div>
										</li>
										<li class="m-menu__item  m-menu__item--submenu m-menu__item--rel"  data-menu-submenu-toggle="click" aria-haspopup="true">
											<a  href="#" class="m-menu__link m-menu__toggle">
												<i class="m-menu__link-icon flaticon-users"></i>
												<span class="m-menu__link-text">
													Transaksi
												</span>
												<i class="m-menu__ver-arrow la la-angle-right"></i>
											</a>
										</li>
										<li class="m-menu__item  m-menu__item--submenu m-menu__item--rel"  data-menu-submenu-toggle="click" aria-haspopup="true">
											<a  href="#" class="m-menu__link m-menu__toggle">
												<i class="m-menu__link-icon flaticon-users"></i>
												<span class="m-menu__link-text">
													Laporan
												</span>
												<i class="m-menu__ver-arrow la la-angle-right"></i>
											</a>
										</li>
										<li class="m-menu__item  <?php if($page_now=='Konfigurasi Transaksi') echo ' m-menu__item--active ';?>m-menu__item--submenu m-menu__item--rel"  data-menu-submenu-toggle="click" aria-haspopup="true">
											<a  href="#" class="m-menu__link m-menu__toggle">
												<i class="m-menu__link-icon flaticon-cogwheel"></i>
												<span class="m-menu__link-text">
													Konfigurasi Transaksi
												</span>
												<i class="m-menu__ver-arrow la la-angle-right"></i>
											</a>
											<div class="m-menu__submenu m-menu__submenu--classic m-menu__submenu--left">
												<span class="m-menu__arrow m-menu__arrow--adjust"></span>
												<ul class="m-menu__subnav">
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/konfigurasi" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Konfigurasi
																	</span>
																</span>
															</span>
														</a>
													</li>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/konfigurasi_transaksi" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Konfigurasi Transaksi
																	</span>
																</span>
															</span>
														</a>
													</li>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="#" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Hari Libur
																	</span>
																</span>
															</span>
														</a>
													</li>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="#" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Konfigurasi Dashboard
																	</span>
																</span>
															</span>
														</a>
													</li>
												</ul>
											</div>
										</li>
										<li class="m-menu__item <?php if($page_now=='Administrator') echo ' m-menu__item--active ';?> m-menu__item--submenu m-menu__item--rel"  data-menu-submenu-toggle="click" aria-haspopup="true">
											<a  href="#" class="m-menu__link m-menu__toggle">
												<i class="m-menu__link-icon flaticon-users"></i>
												<span class="m-menu__link-text">
													Administrator
												</span>
												<i class="m-menu__ver-arrow la la-angle-right"></i>
											</a>
											<div class="m-menu__submenu m-menu__submenu--classic m-menu__submenu--left">
												<span class="m-menu__arrow m-menu__arrow--adjust"></span>
												<ul class="m-menu__subnav">
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/daftar_user" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Daftar User
																	</span>
																</span>
															</span>
														</a>
													</li>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/group_user" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Group User
																	</span>
																</span>
															</span>
														</a>
													</li>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/user_grant" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Grant User
																	</span>
																</span>
															</span>
														</a>
													</li>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/import_data" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Import Data
																	</span>
																</span>
															</span>
														</a>
													</li>
												</ul>
											</div>
										</li>
						</ul>
					</div>
					</div>
				