<!-- begin::Body -->
<div class="m-grid__item m-grid__item--fluid m-grid m-grid--hor-desktop m-grid--desktop m-body">
					<div class="m-grid__item m-grid__item--fluid  m-grid m-grid--ver	m-container m-container--responsive m-container--xxl m-page__container">
				<div class="m-grid__item m-grid__item--fluid m-wrapper">
					<div class="m-content">
						<div class="m-alert m-alert--icon m-alert--air m-alert--square alert alert-dismissible m--margin-bottom-30" role="alert">
							<div class="m-alert__icon">
								<i class="flaticon-exclamation m--font-brand"></i>
							</div>
							<div class="m-alert__text">
								<!-- alert -->
							</div>
						</div>
						<?php if($page_action =='list'){?>
						<div class="m-portlet m-portlet--mobile">
							<div class="m-portlet__head">
								<div class="m-portlet__head-caption">
									<div class="m-portlet__head-title">
										<h3 class="m-portlet__head-text">
											<?php echo $page_title;?>
											<small>
												
											</small>
										</h3>
									</div>
								</div>
							</div>
							<div class="m-portlet__body">
								
								<!--begin: Search Form -->
								<div class="m-form m-form--label-align-right m--margin-top-20 m--margin-bottom-30">
									<div class="row align-items-center">
										<div class="col-xl-8 order-2 order-xl-1">
											<div class="form-group m-form__group row align-items-center">
												<div class="col-md-4">
													<div class="m-input-icon m-input-icon--left">
														<input type="text" class="form-control m-input m-input--solid" placeholder="Search..." id="m_form_search">
														<span class="m-input-icon__icon m-input-icon__icon--left">
															<span>
																<i class="la la-search"></i>
															</span>
														</span>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<!--end: Search Form -->
								<!--begin: Datatable -->
								<?php 
								if($data){
								?>
								    <table class="m-datatable" id="html_table">
                                        <thead>
                                            <tr>
                                                <th> No </th>
                                                <th> Nim</th>
                                                <th> Nama </th>
                                                <th> Program Studi </th>
                                                <th> Alamat </th>
                                                <th> Telp </th>
                                                <th> Status Perpustakaan </th>
                                                <th> Status Studi </th>
                                                <th> Menu </th>
                                            </tr>
                                        </thead>
                                        <tbody>
										<?php 
										$count=0;
										foreach($data as $row){
										$count++;
										?>
                                            <tr class="odd gradeX">
                                                <td> <?php echo $count;?> </td>
                                                <td> <?php echo $row->nis;?> </td>
                                                <td><?php echo $row->nama;?></td>
                                                <td><?php echo $row->kelas;?></td>
                                                <td><?php echo $row->alamat;?></td>
                                                <td><?php echo $row->telepon;?></td>
                                                <td>-</td>
                                                <td>
												<?php if( $row->status_siswa=='A')echo 'Aktif';?>
												</td>
												<td></td>
                                            </tr>
										<?php }?>
                                        </tbody>
                                    </table>
                                <?php 
								}
								?>
								<!--end: Datatable -->
							</div>
						</div>
						<?php } ?>
					</div>
				</div>
			</div>
</div>
			<!-- end:: Body -->