<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>

	

    <!-- Section: tabel | Kumpulan Tabel -->
	<?php if($page_content=='bukutamu'){?>
	<!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-8" data-bg-img="http://placehold.it/1920x1280">
      <div class="container pt-60 pb-60">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12 text-center">
              <h2 class="title text-white">Buku Tamu</h2>
              <ol class="breadcrumb text-center text-black mt-10">
                <li><a href="<?php echo base_url();?>home">Home</a></li>
                <li><a href="<?php echo base_url();?>home/bukutamu">Buku Tamu</a></li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </section>
	<section>
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-md-offset-3">
            <center><h3>Scan Your ID</h3>
			<h5>Gunakan fasilitas ini sebagai buku tamu</h5></center>
					<!-- Mailchimp Subscription Form-->
					<form id="mailchimp-subscription-form1" class="newsletter-form mt-40">
					  <label for="mce-EMAIL"></label>
					  <div class="input-group">
						<input type="email" id="mce-EMAIL" data-height="45px" class="form-control input-lg" placeholder="ID NUMBER" name="idnumber" value="">
						<span class="input-group-btn">
						  <button type="submit" class="btn btn-colored btn-dark btn-lg m-0" data-height="45px">Scanning</button>
						</span>
					  </div>
					</form>
          </div>
        </div>
      </div>
    </section>
	<section>
      <div class="container mt-30 mb-30 pt-30 pb-30">
        <div class="row">
          <div class="col-md-9">
            <div class="blog-posts">
              <div class="col-md-12">
                <div class="row list-dashed">
					
					<table class="table table-striped">
                        <tbody>
						<tr>
							<th>No.</th>
							<th>Tanggal</th>
							<th>Jumlah</th>
						</tr>
                        <?php 
						$presensi=$this->Md_siperpus_presensi->getPresensi7Hari();
						if($presensi){
							$count=0;
							foreach($presensi as $row){
							$count++;
							$jumlah=$this->Md_siperpus_presensi->getJumlah(substr($row->tanggal,0,10));
							
						?>
						<tr>
							<td><?php echo $count;?></td>
							<td><?php echo substr($row->tanggal,0,10);?></td>
							<td><?php echo $jumlah;?></td>
						</tr>
						<?php 
							}
						}
						?>
						<tr>
						
						</tr>
                        </tbody>
                      </table>
				</div>
              </div>
             
            </div>
          </div>
            <?php include 'front-rightsidebar.php'; ?>
        </div>
      </div>
    </section>
	
	<?php }?>
	<?php if($page_content=='dbook'){?>
	<section class="inner-header divider parallax layer-overlay overlay-dark-8" data-bg-img="http://placehold.it/1920x1280">
      <div class="container pt-60 pb-60">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12 text-center">
              <h2 class="title text-white">Buku Digital</h2>
              <ol class="breadcrumb text-center text-black mt-10">
                <li><a href="<?php echo base_url();?>home">Home</a></li>
                <li><a href="<?php echo base_url();?>home/digital_book">Buku Digital</a></li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </section>
	<section>
      <div class="container mt-30 mb-30 pt-30 pb-30">
        <div class="row">
          <div class="col-md-9">
            <div class="blog-posts">
              <div class="col-md-12">
                <div class="row list-dashed">
					<table class="table table-striped">
                        <tbody>
						<tr>
							<th>No.</th>
							<th>No. Klasifikasi</th>
							<th>Judul Buku</th>
							<th>Deskripsi</th>
						</tr>
                        <?php 
						$buku=$this->Md_siperpus_buku_digital->getBukuDigital();
						if($buku){
							$count=0;
							foreach($buku as $row){
							$count++;
						?>
						<tr>
							<td><?php echo $count;?></td>
							<td><?php echo $row->no_klas;?></td>
							<td><?php echo $row->title;?></td>
							<td><?php echo $row->deskripsi;?></td>
						</tr>
						<?php 
							}
						}
						?>
						<tr>
						
						</tr>
                        </tbody>
                      </table>
				</div>
              </div>
             
            </div>
          </div>
          <?php include 'front-rightsidebar.php'; ?>
            
          </div>
        </div>
      </div>
    </section>
	
	<?php }?>
	<?php if($page_content=='pbuku'){?>
	 <section class="inner-header divider parallax layer-overlay overlay-dark-8" data-bg-img="http://placehold.it/1920x1280">
      <div class="container pt-60 pb-60">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12 text-center">
              <h2 class="title text-white">Penelusuran Buku</h2>
              <ol class="breadcrumb text-center text-black mt-10">
                <li><a href="<?php echo base_url();?>home">Home</a></li>
                <li><a href="<?php echo base_url();?>home/penelusuran_buku">Penelusuran Buku</a></li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </section>
	<section>
      <div class="container mt-30 mb-30 pt-30 pb-30">
        <div class="row">
          <div class="col-md-9">
            <div class="blog-posts">
              <div class="col-md-12">
                <div class="row list-dashed">
					<table class="table table-striped">
                        <tbody>
						<tr>
							<th>No.</th>
							<th>No. Klasifikasi</th>
							<th>Judul Buku</th>
							<th>Penulis</th>
							<th>Penerbit</th>
							<th>Jumlah Buku</th>
							<th>Review</th>
							<th>Stok</th>
						</tr>
                        <?php 
						$buku=$this->Md_siperpus_buku->getBuku();
						if($buku){
							$count=0;
							foreach($buku as $row){
							$count++;
							$penerbit=$this->Md_siperpus_penerbit->getPenerbitById($row->kd_penerbit);
							if($penerbit){
								$namapenerbit=$penerbit[0]->nama_penerbit;
							}else{
								$namapenerbit="-";
							}
						?>
						<tr>
							<td><?php echo $count;?></td>
							<td><?php echo $row->no_klas;?></td>
							<td><?php echo $row->judul;?></td>
							<td><?php echo $row->penulis;?></td>
							<td><?php echo $namapenerbit;?></td>
							<td><?php echo $row->jml_buku;?></td>
							<td><?php echo $row->review;?></td>
							<td>-</td>
						</tr>
						<?php 
							}
						}
						?>
						<tr>
						
						</tr>
                        </tbody>
                      </table>
				</div>
              </div>
             
            </div>
          </div>
           <?php include 'front-rightsidebar.php'; ?>
          </div>
        </div>
      </div>
    </section>
	
	<?php }?>
   <?php if($page_content=='pbukuprodi'){?>
	<section class="inner-header divider parallax layer-overlay overlay-dark-8" data-bg-img="http://placehold.it/1920x1280">
      <div class="container pt-60 pb-60">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12 text-center">
              <h2 class="title text-white">Penelusuran Buku Ref Prodi</h2>
              <ol class="breadcrumb text-center text-black mt-10">
                <li><a href="<?php echo base_url();?>home">Home</a></li>
                <li><a href="<?php echo base_url();?>home/penelusuran_bukuprodi">Penelusuran Buku Ref Prodi</a></li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </section>
	 <section>
      <div class="container mt-30 mb-30 pt-30 pb-30">
        <div class="row">
          <div class="col-md-9">
            <div class="blog-posts">
              <div class="col-md-12">
                <div class="row list-dashed">
					<table class="table table-striped">
                        <tbody>
						<tr>
							<th>No.</th>
							<th>No. Klasifikasi</th>
							<th>Judul Buku</th>
							<th>Penulis</th>
							<th>Penerbit</th>
							<th>Jumlah Buku</th>
							<th>Review</th>
							<th>Stok</th>
						</tr>
                        <?php 
						$buku=$this->Md_siperpus_buku->getBuku();
						if($buku){
							$count=0;
							foreach($buku as $row){
							$count++;
							$penerbit=$this->Md_siperpus_penerbit->getPenerbitById($row->kd_penerbit);
							if($penerbit){
								$namapenerbit=$penerbit[0]->nama_penerbit;
							}else{
								$namapenerbit="-";
							}
						?>
						<tr>
							<td><?php echo $count;?></td>
							<td><?php echo $row->no_klas;?></td>
							<td><?php echo $row->judul;?></td>
							<td><?php echo $row->penulis;?></td>
							<td><?php echo $namapenerbit;?></td>
							<td><?php echo $row->jml_buku;?></td>
							<td><?php echo $row->review;?></td>
							<td>-</td>
						</tr>
						<?php 
							}
						}
						?>
						<tr>
						
						</tr>
                        </tbody>
                      </table>
				</div>
              </div>
             
            </div>
          </div>
           <?php include 'front-rightsidebar.php'; ?>
          </div>
        </div>
      </div>
    </section>
	
	<?php }?>
     <?php if($page_content=='kontak'){?>
	<section class="inner-header divider parallax layer-overlay overlay-dark-8" data-bg-img="http://placehold.it/1920x1280">
      <div class="container pt-60 pb-60">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12 text-center">
              <h2 class="title text-white">Kontak</h2>
              <ol class="breadcrumb text-center text-black mt-10">
                <li><a href="<?php echo base_url();?>home">Home</a></li>
                <li><a href="<?php echo base_url();?>home/kontak">Kontak</a></li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </section>
	 <section class="divider">
      <div class="container pt-0">
        <div class="row mb-60 bg-deep">
          <div class="col-sm-12 col-md-4">
            <div class="contact-info text-center pt-60 pb-60 border-right">
              <i class="fa fa-phone font-36 mb-10 text-theme-colored"></i>
              <h4>Call Us</h4>
              <h6 class="text-gray">Phone: (0761)36581</h6>
            </div>
          </div>
          <div class="col-sm-12 col-md-4">
            <div class="contact-info text-center  pt-60 pb-60 border-right">
              <i class="fa fa-map-marker font-36 mb-10 text-theme-colored"></i>
              <h4>Address</h4>
              <h6 class="text-gray">Jl. Melur No. 103 Sukajadi-Pekanbaru</h6>
            </div>
          </div>
          <div class="col-sm-12 col-md-4">
            <div class="contact-info text-center  pt-60 pb-60">
              <i class="fa fa-envelope font-36 mb-10 text-theme-colored"></i>
              <h4>Email</h4>
              <h6 class="text-gray">pkr.riau@gmail.com</h6>
            </div>
          </div>
        </div>
        <div class="row pt-10">
          <div class="col-md-5">
          <h4 class="mt-0 mb-30 line-bottom">Find Our Location</h4>
          <!-- Google Map HTML Codes -->
          <div 
            data-address="Jl. Melur No. 103 Sukajadi-Pekanbaru"
            data-popupstring-id="#popupstring1"
            class="map-canvas autoload-map"
            data-mapstyle="style8"
            data-height="420"
            data-latlng="0.525954,101.434503"
            data-title="Politeknik Kesehatan Riau"
            data-zoom="12"
            data-marker="<?php echo base_url();?>assets/front/images/map-marker.png">
          </div>
          <div class="map-popupstring hidden" id="popupstring1">
            <div class="text-center">
              <h3>Politeknik Kesehatan Riau</h3>
              <p>Jl. Melur No. 103 Sukajadi-Pekanbaru</p>
            </div>
          </div>
          <!-- Google Map Javascript Codes -->
          <script src="http://maps.google.com/maps/api/js?key=AIzaSyAYWE4mHmR9GyPsHSOVZrSCOOljk8DU9B4"></script>
          <script src="<?php echo base_url();?>assets/front/js/google-map-init.js"></script>
          </div>
          <div class="col-md-7">
            <h4 class="mt-0 mb-30 line-bottom">Interested in discussing?</h4>
            <!-- Contact Form -->
            <form id="contact_form" name="contact_form" class="" action="includes/sendmail.php" method="post">

              <div class="row">
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="form_name">Name <small>*</small></label>
                    <input name="form_name" class="form-control" type="text" placeholder="Enter Name" required="">
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="form-group">
                    <label>Email <small>*</small></label>
                    <input name="form_email" class="form-control required email" type="email" placeholder="Enter Email">
                  </div>
                </div>
              </div>                
              <div class="row">
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="form_name">Subject <small>*</small></label>
                    <input name="form_subject" class="form-control required" type="text" placeholder="Enter Subject">
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="form_phone">Phone</label>
                    <input name="form_phone" class="form-control" type="text" placeholder="Enter Phone">
                  </div>
                </div>
              </div>

              <div class="form-group">
                <label for="form_name">Message</label>
                <textarea name="form_message" class="form-control required" rows="5" placeholder="Enter Message"></textarea>
              </div>
              <div class="form-group">
                <input name="form_botcheck" class="form-control" type="hidden" value="" />
                <button type="submit" class="btn btn-flat btn-theme-colored text-uppercase mt-10 mb-sm-30 border-left-theme-color-2-4px" data-loading-text="Please wait...">Send your message</button>
                <button type="reset" class="btn btn-flat btn-theme-colored text-uppercase mt-10 mb-sm-30 border-left-theme-color-2-4px">Reset</button>
              </div>
            </form>

            <!-- Contact Form Validation-->
            <script type="text/javascript">
              $("#contact_form").validate({
                submitHandler: function(form) {
                  var form_btn = $(form).find('button[type="submit"]');
                  var form_result_div = '#form-result';
                  $(form_result_div).remove();
                  form_btn.before('<div id="form-result" class="alert alert-success" role="alert" style="display: none;"></div>');
                  var form_btn_old_msg = form_btn.html();
                  form_btn.html(form_btn.prop('disabled', true).data("loading-text"));
                  $(form).ajaxSubmit({
                    dataType:  'json',
                    success: function(data) {
                      if( data.status == 'true' ) {
                        $(form).find('.form-control').val('');
                      }
                      form_btn.prop('disabled', false).html(form_btn_old_msg);
                      $(form_result_div).html(data.message).fadeIn('slow');
                      setTimeout(function(){ $(form_result_div).fadeOut('slow') }, 6000);
                    }
                  });
                }
              });
            </script>
          </div>
        </div>
      </div>
    </section>
	
	<?php }?>
    

    <!-- Section: Mission -->
	<!--
    <section id="mission">
      <div class="container-fluid pt-0 pb-0">
        <div class="row equal-height">
          <div class="col-sm-6 col-md-6 xs-pull-none bg-theme-colored wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.3s">
            <div class="pt-60 pb-40 pl-90 pr-160 p-md-30">
              <h2 class="title text-white text-uppercase line-bottom mt-0 mb-30">Why Choose Us?</h2>
              <div class="icon-box clearfix m-0 p-0 pb-10">
                <a href="#" class="icon icon-circled bg-white icon-lg pull-left flip sm-pull-none"> 
                  <i class="fa fa-desktop text-theme-color-2 font-36"></i> 
                </a>
                <div class="ml-120 ml-sm-0">
                  <h4 class="icon-box-title text-white mt-5 mb-10 letter-space-1">Best Lab</h4>
                  <p class="text-white">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam interdum diam tortor, egestas varius erat aliquam. </p>
                </div>
              </div>
              <div class="icon-box clearfix m-0 p-0 pb-10">
                <a href="#" class="icon icon-circled bg-white icon-lg pull-left flip sm-pull-none">
                  <i class="fa fa-user text-theme-color-2 font-36"></i> 
                </a>
                <div class="ml-120 ml-sm-0">
                  <h4 class="icon-box-title text-white mt-5 mb-10 letter-space-1">Best Teachers</h4>
                  <p class="text-white">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam interdum diam tortor, egestas varius erat aliquam. </p>
                </div>
              </div>
              <div class="icon-box clearfix m-0 p-0 pb-10">
                <a href="#" class="icon icon-circled bg-white icon-lg pull-left flip sm-pull-none">
                  <i class="fa fa-money text-theme-color-2 font-36"></i> 
                </a>
                <div class="ml-120 ml-sm-0">
                  <h4 class="icon-box-title text-white mt-5 mb-10 letter-space-1">Low Cost Services</h4>
                  <p class="text-white">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam interdum diam tortor, egestas varius erat aliquam. </p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-md-6 p-0 bg-img-cover wow fadeInRight hidden-xs" data-bg-img="http://placehold.it/800x455" data-wow-duration="1s" data-wow-delay="0.3s">
          </div>
        </div>
      </div>
    </section>
	-->
    <!-- Section: courses -->
    
	
	<?php if($page_content=='dashboard'){?>
	<section id="home">
        
      <!-- Slider Revolution Start -->
     <?php include 'front-slider.php'; ?>
	 <!-- end .rev_slider_wrapper -->
      
    </section>
     <!-- Section: About -->
    <section id="about">
      <div class="container mt-50 pb-70 pt-0">
        <div class="section-content">
          <div class="row mt-10">
            <div class="col-sm-12 col-md-6 mb-sm-20 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.5s">
              <h3 class="text-uppercase mt-0">Selamat Datang Di<span class="text-theme-color-2">  Perpustakaan POLTEKES KEMENKES RIAU </span></h3>
              <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisi cing elit. Quos dolo rem consequ untur, natus laudantium commodi earum aliquid in ullam.Lorem ipsum.</p>
              <p class="mb-15">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Earum sunt ut dolorem laboriosam culpa excepturi sed distinctio eius! Ut magnam numquam libero quia vero blanditiis fugit corporis quisquam, debitis quidem laudantium deleniti.</p>
              <p class="mb-10">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Earum sunt ut dolorem laboriosam culpa excepturi sed distinctio eius! Ut magnam numquam libero quia vero blanditiis fugit corporis quisquam, debitis quidem laudantium deleniti.</p>
              <a class="btn btn-colored btn-theme-colored btn-lg text-uppercase font-13 mt-0" href="#">View Details</a> 
            </div>
            <div class="col-sm-12 col-md-6 mt-0 wow fadeInDown" data-wow-duration="1s" data-wow-delay="0.5s">
              <div class="video-popup">                
                <a href="https://www.youtube.com/watch?v=V3-DqGAYffU" data-lightbox-gallery="youtube-video" title="PROFIL POLITEKNIK KEMENKES RIAU">
                  <img alt="" src="<?php echo base_url();?>assets/app/media/img/files/about.jpg" class="img-responsive img-fullwidth mt-10 ml-30 ml-xs-0 ml-sm-0">
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Divider: Funfact -->
    <section class="divider parallax layer-overlay" data-bg-img="http://placehold.it/1920x1280" data-parallax-ratio="0.7">
      <div class="container pt-70 pb-60">
        <div class="row">
          <div class="col-xs-12 col-sm-6 col-md-3 mb-md-50">
            <div class="funfact text-center">
              <i class="fa fa-book mt-5 text-white"></i>
              <h2 data-animation-duration="2000" data-value="50" class="animate-number text-white mt-0 font-38 font-weight-500">0</h2>
              <h4 class="text-white text-uppercase">Buku</h4>
            </div>
          </div>
          <div class="col-xs-12 col-sm-6 col-md-3 mb-md-50">
            <div class="funfact text-center">
              <i class="fa fa-files-o mt-5 text-white"></i>
              <h2 data-animation-duration="2000" data-value="75" class="animate-number text-white mt-0 font-38 font-weight-500">0</h2>
              <h4 class="text-white text-uppercase">Eksemplar Buku</h4>
            </div>
          </div>
          <div class="col-xs-12 col-sm-6 col-md-3 mb-md-50">
            <div class="funfact text-center">
              <i class="fa fa-bookmark mt-5 text-white"></i>
              <h2 data-animation-duration="2000" data-value="2324" class="animate-number text-white mt-0 font-38 font-weight-500">0</h2>
              <h4 class="text-white text-uppercase">Peminjaman Buku</h4>
            </div>
          </div>
          <div class="col-xs-12 col-sm-6 col-md-3 mb-md-50">
            <div class="funfact text-center">
              <i class="fa  fa-users mt-5 text-white"></i>
              <h2 data-animation-duration="2000" data-value="1524" class="animate-number text-white mt-0 font-38 font-weight-500">0</h2>
              <h4 class="text-white text-uppercase">Anggota Pustaka</h4>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Section: Teachers -->
	<!--
    <section id="teachers">
      <div class="container pt-70 pb-70">
        <div class="section-title text-center">
          <div class="row">
            <div class="col-md-8 col-md-offset-2">
              <h2 class="mt-0 line-height-1 text-center text-uppercase mb-10 text-black-333">Our <span class="text-theme-color-2"> Teachers</span></h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem autem<br> voluptatem obcaecati!</p>
            </div>
          </div>
        </div>
        <div class="row mtli-row-clearfix">
          <div class="col-md-12">
            <div class="owl-carousel-4col">
              <div class="item">
                <div class="team-members border-bottom-theme-color-2px text-center maxwidth400">
                  <div class="team-thumb">
                    <img class="img-fullwidth" alt="" src="http://placehold.it/275x370">
                    <div class="team-overlay"></div>
                  </div>
                  <div class="team-details bg-silver-light pt-10 pb-10">
                    <h4 class="text-uppercase font-weight-600 m-5"><a href="page-teachers-details.html">Jhon Smith</a></h4>
                    <h6 class="text-theme-colored font-15 font-weight-400 mt-0">Teacher Designation</h6>
                    <ul class="styled-icons icon-theme-colored icon-dark icon-circled icon-sm">
                      <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                      <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                      <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                      <li><a href="#"><i class="fa fa-skype"></i></a></li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="team-members border-bottom-theme-color-2px text-center maxwidth400">
                  <div class="team-thumb">
                    <img class="img-fullwidth" alt="" src="http://placehold.it/275x370">
                    <div class="team-overlay"></div>
                  </div>
                  <div class="team-details bg-silver-light pt-10 pb-10">
                    <h4 class="text-uppercase font-weight-600 m-5"><a href="page-teachers-details.html">Jhon Smith</a></h4>
                    <h6 class="text-theme-colored font-15 font-weight-400 mt-0">Teacher Designation</h6>
                    <ul class="styled-icons icon-theme-colored icon-dark icon-circled icon-sm">
                      <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                      <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                      <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                      <li><a href="#"><i class="fa fa-skype"></i></a></li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="team-members border-bottom-theme-color-2px text-center maxwidth400">
                  <div class="team-thumb">
                    <img class="img-fullwidth" alt="" src="http://placehold.it/275x370">
                    <div class="team-overlay"></div>
                  </div>
                  <div class="team-details bg-silver-light pt-10 pb-10">
                    <h4 class="text-uppercase font-weight-600 m-5"><a href="page-teachers-details.html">Jhon Smith</a></h4>
                    <h6 class="text-theme-colored font-15 font-weight-400 mt-0">Teacher Designation</h6>
                    <ul class="styled-icons icon-theme-colored icon-dark icon-circled icon-sm">
                      <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                      <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                      <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                      <li><a href="#"><i class="fa fa-skype"></i></a></li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="team-members border-bottom-theme-color-2px text-center maxwidth400">
                  <div class="team-thumb">
                    <img class="img-fullwidth" alt="" src="http://placehold.it/275x370">
                    <div class="team-overlay"></div>
                  </div>
                  <div class="team-details bg-silver-light pt-10 pb-10">
                    <h4 class="text-uppercase font-weight-600 m-5"><a href="page-teachers-details.html">Jhon Smith</a></h4>
                    <h6 class="text-theme-colored font-15 font-weight-400 mt-0">Teacher Designation</h6>
                    <ul class="styled-icons icon-theme-colored icon-dark icon-circled icon-sm">
                      <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                      <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                      <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                      <li><a href="#"><i class="fa fa-skype"></i></a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
	-->
    <!-- Section: events -->
	<!--
    <section id="events" class="divider parallax layer-overlay overlay-dark-8" data-stellar-background-ratio="0.5" data-bg-img="http://placehold.it/1920x1280">
      <div class="container pt-70 pb-40">
        <div class="section-title mb-30">
          <div class="row">
            <div class="col-md-6 col-md-offset-3 text-center">
              <h2 class="mt-0 line-height-1 text-center mb-10 text-white text-uppercase">Upcoming Events</h2>
              <p class="text-white">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem autem<br> voluptatem obcaecati!</p>
            </div>
          </div>
        </div>
        <div class="section-content">
          <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-6 mb-30 wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
              <div class="pricing table-horizontal maxwidth400">
                <div class="row">
                  <div class="col-md-6">
                    <div class="thumb">
                    <img class="img-fullwidth mb-sm-0" src="http://placehold.it/270x250" alt="">
                    </div>
                  </div>
                  <div class="col-md-6 p-30 pl-sm-50">
                    <h4 class="mt-0 mb-5"><a href="#" class="text-white">Upcoming Events Title</a></h4>
                    <ul class="list-inline mb-5 text-white">
                      <li class="pr-0"><i class="fa fa-calendar mr-5"></i> June 26, 2016 |</li>
                      <li class="pl-5"><i class="fa fa-map-marker mr-5"></i>New York</li>
                    </ul>
                    <p class="mb-15 mt-15 text-white">Lorem ipsum dolor sit amet, consectetur adi isicing elit. Quas eveniet, nemo dicta. Ullam nam.</p>
                    <a class="text-white font-weight-600" href="#">Read More →</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-6 mb-30 wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
              <div class="pricing table-horizontal maxwidth400">
                <div class="row">
                  <div class="col-md-6">
                    <div class="thumb">
                    <img class="img-fullwidth mb-sm-0" src="http://placehold.it/270x250" alt="">
                    </div>
                  </div>
                  <div class="col-md-6 p-30 pl-sm-50">
                    <h4 class="mt-0 mb-5"><a href="#" class="text-white">Upcoming Events Title</a></h4>
                    <ul class="list-inline mb-5 text-white">
                      <li class="pr-0"><i class="fa fa-calendar mr-5"></i> June 26, 2016 |</li>
                      <li class="pl-5"><i class="fa fa-map-marker mr-5"></i>New York</li>
                    </ul>
                    <p class="mb-15 mt-15 text-white">Lorem ipsum dolor sit amet, consectetur adi isicing elit. Quas eveniet, nemo dicta. Ullam nam.</p>
                    <a class="text-white font-weight-600" href="#">Read More →</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-6 mb-30 wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
              <div class="pricing table-horizontal maxwidth400">
                <div class="row">
                  <div class="col-md-6">
                    <div class="thumb">
                    <img class="img-fullwidth mb-sm-0" src="http://placehold.it/270x250" alt="">
                    </div>
                  </div>
                  <div class="col-md-6 p-30 pl-sm-50">
                    <h4 class="mt-0 mb-5"><a href="#" class="text-white">Upcoming Events Title</a></h4>
                    <ul class="list-inline mb-5 text-white">
                      <li class="pr-0"><i class="fa fa-calendar mr-5"></i> June 26, 2016 |</li>
                      <li class="pl-5"><i class="fa fa-map-marker mr-5"></i>New York</li>
                    </ul>
                    <p class="mb-15 mt-15 text-white">Lorem ipsum dolor sit amet, consectetur adi isicing elit. Quas eveniet, nemo dicta. Ullam nam.</p>
                    <a class="text-white font-weight-600" href="#">Read More →</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-6 mb-30 wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
              <div class="pricing table-horizontal maxwidth400">
                <div class="row">
                  <div class="col-md-6">
                    <div class="thumb">
                    <img class="img-fullwidth mb-sm-0" src="http://placehold.it/270x250" alt="">
                    </div>
                  </div>
                  <div class="col-md-6 p-30 pl-sm-50">
                    <h4 class="mt-0 mb-5"><a href="#" class="text-white">Upcoming Events Title</a></h4>
                    <ul class="list-inline mb-5 text-white">
                      <li class="pr-0"><i class="fa fa-calendar mr-5"></i> June 26, 2016 |</li>
                      <li class="pl-5"><i class="fa fa-map-marker mr-5"></i>New York</li>
                    </ul>
                    <p class="mb-15 mt-15 text-white">Lorem ipsum dolor sit amet, consectetur adi isicing elit. Quas eveniet, nemo dicta. Ullam nam.</p>
                    <a class="text-white font-weight-600" href="#">Read More →</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    -->
    <!-- Gallery Grid 3 -->
    
    <!-- Section: Client Say -->
	<!--
    <section class="divider parallax layer-overlay overlay-dark-4" data-background-ratio="0.5" data-bg-img="http://placehold.it/1920x1280">
      <div class="container pt-60 pb-60">
        <div class="row">
          <div class="col-md-8 col-md-offset-2">
              <h2 class="text-uppercase mt-0 pb-0  text-center text-white">Our Students say</h2>
            <div class="owl-carousel-1col" data-dots="true">
              <div class="item">
                <div class="testimonial-wrapper text-center">
                  <div class="thumb"><img class="" alt="" src="http://placehold.it/100x100"></div>
                  <div class="content pt-10">
                    <p class="lead text-white">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Neque est quasi, quas ipsam, expedita placeat facilis odio illo ex accusantium eaque itaque officiis et sit. Vero quo, impedit neque.</p>
                    <h4 class="author text-white mb-0">Catherine Grace</h4>
                    <h6 class="title text-white mt-0 mb-15">Designer</h6>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimonial-wrapper text-center">
                  <div class="thumb"><img class="" alt="" src="http://placehold.it/100x100"></div>
                  <div class="content pt-10">
                    <p class="lead text-white">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Neque est quasi, quas ipsam, expedita placeat facilis odio illo ex accusantium eaque itaque officiis et sit. Vero quo, impedit neque.</p>
                    <h4 class="author text-white mb-0">Catherine Grace</h4>
                    <h6 class="title text-white mt-0 mb-15">Designer</h6>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimonial-wrapper text-center">
                  <div class="thumb"><img class="" alt="" src="http://placehold.it/100x100"></div>
                  <div class="content pt-10">
                    <p class="lead text-white">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Neque est quasi, quas ipsam, expedita placeat facilis odio illo ex accusantium eaque itaque officiis et sit. Vero quo, impedit neque.</p>
                    <h4 class="author text-white mb-0">Catherine Grace</h4>
                    <h6 class="title text-white mt-0 mb-15">Designer</h6>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    -->
    <!-- Section: Blog -->
	
    <section id="blog">
      <div class="container pt-70">
        <div class="section-title text-center">
          <div class="row">
            <div class="col-md-8 col-md-offset-2">
              <h2 class="mt-0 line-height-1 text-uppercase">Artikel  <span class="text-theme-color-2"> Terbaru</span></h2>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
              <div class="owl-carousel-3col owl-nav-top mb-sm-0" data-dots="true">
              <div class="item">
                <article class="post clearfix maxwidth600 mb-sm-30 wow fadeInRight" data-wow-delay=".2s">
                  <div class="entry-header">
                    <div class="post-thumb thumb"> <img src="http://placehold.it/370x247" alt="" class="img-responsive img-fullwidth"> </div>
                    <div class="entry-meta meta-absolute text-center pl-10 pr-10">
                    <div class="display-table">
                      <div class="display-table-cell">
                        <ul>
                          <li><a class="text-white" href="#"><i class="fa fa-comments-o mt-0 pt-0"></i> 85 <br> comments</a></li>
                          <li><a class="text-white" href="#"><i class="fa fa-thumbs-o-up mt-20"></i> 250 <br> Likes</a></li>
                        </ul>
                      </div>
                    </div>
                    </div>
                  </div>
                  <div class="entry-content border-1px p-20">
                    <h4 class="entry-title mt-0 pt-0"><a href="#">Post Title Here</a></h4>
                      <span class="text-theme-colored mr-10 font-14">Admin | <i class="fa fa-calendar mr-5 text-theme-colored"></i> 21 February 2016</span>
                    <p class="text-left mb-20 mt-5 font-13">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.</p>
                    <a class="btn btn-flat btn-dark btn-theme-colored btn-sm pull-left" href="blog-single-left-sidebar.html">Read more</a>
                    <div class="clearfix"></div>
                  </div>
                </article>
              </div>
              <div class="item">
                <article class="post clearfix maxwidth600 mb-sm-30 wow fadeInRight" data-wow-delay=".4s">
                  <div class="entry-header">
                    <div class="post-thumb thumb"> <img src="http://placehold.it/370x247" alt="" class="img-responsive img-fullwidth"> </div>
                    <div class="entry-meta meta-absolute text-center pl-10 pr-10">
                      <div class="display-table">
                        <div class="display-table-cell">
                          <ul>
                            <li><a class="text-white" href="#"><i class="fa fa-comments-o mt-0 pt-0"></i> 85 <br> comments</a></li>
                            <li><a class="text-white" href="#"><i class="fa fa-thumbs-o-up mt-20"></i> 250 <br> Likes</a></li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="entry-content border-1px p-20">
                    <h4 class="entry-title mt-0 pt-0"><a href="#">Post Title Here</a></h4>
                      <span class="text-theme-colored mr-10 font-14">Admin | <i class="fa fa-calendar mr-5 text-theme-colored"></i> 21 February 2016</span>
                    <p class="text-left mb-20 mt-5 font-13">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.</p>
                    <a class="btn btn-flat btn-dark btn-theme-colored btn-sm pull-left" href="blog-single-left-sidebar.html">Read more</a>
                    <div class="clearfix"></div>
                  </div>
                </article>
              </div>
              <div class="item">
                <article class="post clearfix maxwidth600 mb-sm-30 wow fadeInRight" data-wow-delay=".6s">
                  <div class="entry-header">
                    <div class="post-thumb thumb"> <img src="http://placehold.it/370x247" alt="" class="img-responsive img-fullwidth"> </div>
                    <div class="entry-meta meta-absolute text-center pl-10 pr-10">
                      <div class="display-table">
                        <div class="display-table-cell">
                          <ul>
                            <li><a class="text-white" href="#"><i class="fa fa-comments-o mt-0 pt-0"></i> 85 <br> comments</a></li>
                            <li><a class="text-white" href="#"><i class="fa fa-thumbs-o-up mt-20"></i> 250 <br> Likes</a></li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="entry-content border-1px p-20">
                    <h4 class="entry-title mt-0 pt-0"><a href="#">Post Title Here</a></h4>
                      <span class="text-theme-colored mr-10 font-14">Admin | <i class="fa fa-calendar mr-5 text-theme-colored"></i> 21 February 2016</span>
                    <p class="text-left mb-20 mt-5 font-13">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.</p>
                    <a class="btn btn-flat btn-dark btn-theme-colored btn-sm pull-left" href="blog-single-left-sidebar.html">Read more</a>
                    <div class="clearfix"></div>
                  </div>
                </article>
              </div>
              <div class="item">
                <article class="post clearfix maxwidth600 mb-sm-30">
                  <div class="entry-header">
                    <div class="post-thumb thumb"> <img src="http://placehold.it/370x247" alt="" class="img-responsive img-fullwidth"> </div>
                    <div class="entry-meta meta-absolute text-center pl-10 pr-10">
                      <div class="display-table">
                        <div class="display-table-cell">
                          <ul>
                            <li><a class="text-white" href="#"><i class="fa fa-comments-o mt-0 pt-0"></i> 85 <br> comments</a></li>
                            <li><a class="text-white" href="#"><i class="fa fa-thumbs-o-up mt-20"></i> 250 <br> Likes</a></li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="entry-content border-1px p-20">
                    <h4 class="entry-title mt-0 pt-0"><a href="#">Post Title Here</a></h4>
                      <span class="text-theme-colored mr-10 font-14">Admin | <i class="fa fa-calendar mr-5 text-theme-colored"></i> 21 February 2016</span>
                    <p class="text-left mb-20 mt-5 font-13">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.</p>
                    <a class="btn btn-flat btn-dark btn-theme-colored btn-sm pull-left" href="blog-single-left-sidebar.html">Read more</a>
                    <div class="clearfix"></div>
                  </div>
                </article>
              </div>
              <div class="item">
                <article class="post clearfix maxwidth600 mb-sm-30">
                  <div class="entry-header">
                    <div class="post-thumb thumb"> <img src="http://placehold.it/370x247" alt="" class="img-responsive img-fullwidth"> </div>
                    <div class="entry-meta meta-absolute text-center pl-10 pr-10">
                      <div class="display-table">
                        <div class="display-table-cell">
                          <ul>
                            <li><a class="text-white" href="#"><i class="fa fa-comments-o mt-0 pt-0"></i> 85 <br> comments</a></li>
                            <li><a class="text-white" href="#"><i class="fa fa-thumbs-o-up mt-20"></i> 250 <br> Likes</a></li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="entry-content border-1px p-20">
                    <h4 class="entry-title mt-0 pt-0"><a href="#">Post Title Here</a></h4>
                      <span class="text-theme-colored mr-10 font-14">Admin | <i class="fa fa-calendar mr-5 text-theme-colored"></i> 21 February 2016</span>
                    <p class="text-left mb-20 mt-5 font-13">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.</p>
                    <a class="btn btn-flat btn-dark btn-theme-colored btn-sm pull-left" href="blog-single-left-sidebar.html">Read more</a>
                    <div class="clearfix"></div>
                  </div>
                </article>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
	<?php } ?>
    <!-- Divider: Clients -->
	<!--
    <section class="clients bg-theme-colored">
      <div class="container pt-10 pb-10 pb-sm-0 pt-sm-0">
        <div class="row">
          <div class="col-md-12">
            <!-- Section: Clients -->
			<!--
            <div class="owl-carousel-6col transparent text-center owl-nav-top">
              <div class="item"> <a href="#"><img src="http://placehold.it/200x120" alt=""></a></div>
              <div class="item"> <a href="#"><img src="http://placehold.it/200x120" alt=""></a></div>
              <div class="item"> <a href="#"><img src="http://placehold.it/200x120" alt=""></a></div>
              <div class="item"> <a href="#"><img src="http://placehold.it/200x120" alt=""></a></div>
              <div class="item"> <a href="#"><img src="http://placehold.it/200x120" alt=""></a></div>
              <div class="item"> <a href="#"><img src="http://placehold.it/200x120" alt=""></a></div>
              <div class="item"> <a href="#"><img src="http://placehold.it/200x120" alt=""></a></div>
              <div class="item"> <a href="#"><img src="http://placehold.it/200x120" alt=""></a></div>
              <div class="item"> <a href="#"><img src="http://placehold.it/200x120" alt=""></a></div>
              <div class="item"> <a href="#"><img src="http://placehold.it/200x120" alt=""></a></div>
            </div>
          </div>
        </div>
      </div>
	  -->
    <!--
	</section>      
	-->
  </div>
  <!-- end main-content -->
  