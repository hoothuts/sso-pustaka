<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>

  <!-- Header -->
  <header id="header" class="header">
    <div class="header-top bg-theme-color-2 sm-text-center">
      <div class="container">
        <div class="row">
          <div class="col-md-8">
            <div class="widget no-border m-0">
              <ul class="list-inline">
                <li class="m-0 pl-10 pr-10"> <i class="fa fa-phone text-white"></i> <a class="text-white" href="#">(0761)36581</a> </li>
                <li class="text-white m-0 pl-10 pr-10"> <i class="fa fa-clock-o text-white"></i> Senin - Jumat 08:00 to 17:00 </li>
                <li class="m-0 pl-10 pr-10"> <i class="fa fa-envelope-o text-white"></i> <a class="text-white" href="#">pkr.riau@gmail.com</a> </li>
              </ul>
            </div>
          </div>
		  <div class="col-md-4">
            <div class="widget no-border m-0">
              <ul class="list-inline pull-right flip sm-pull-none sm-text-center">
                <li> <a class="text-white" href="<?php echo base_url();?>home/loginform"><i class="fa fa-sign-in text-white"></i> Sign In</a> </li>
              </ul>
            </div>
          </div>
		  <!--
          <div class="col-md-4">
            <div class="widget no-border m-0">
              <ul class="list-inline text-right sm-text-center">
                <li>
                  <a href="#" class="text-white">FAQ</a>
                </li>
                <li class="text-white">|</li>
                <li>
                  <a href="#" class="text-white">Help Desk</a>
                </li>
                <li class="text-white">|</li>
                <li>
                  <a href="#" class="text-white">Support</a>
                </li>
              </ul>
            </div>
          </div>
		  -->
        </div>
      </div>
    </div>
    <div class="header-nav">
      <div class="header-nav-wrapper navbar-scrolltofixed bg-white">
        <div class="container">
          <nav id="menuzord-right" class="menuzord default">
            <a class="menuzord-brand pull-left flip" href="javascript:void(0)" >
              <img src="<?php echo base_url();?>assets/front/images/logo-wide.png" alt="">
            </a>
            <ul class="menuzord-menu">
              <li class="<?php if($page_content=='dashboard')echo 'current active';?>"><a href="<?php echo base_url();?>home/">Home</a>
              </li>
              <li class="<?php if($page_content=='about')echo 'current active';?>"><a href="<?php echo base_url();?>home/about">Profil Perpustakaan</a>
              </li>
              <li><a href="http://library.pkr.ac.id/one.php">One Search</a>
              </li>
			  <li class="<?php if($page_content=='bukutamu')echo 'current active';?>"><a href="<?php echo base_url();?>home/bukutamu">Buku Tamu</a>
              </li>
			  <li class="<?php if($page_content=='dbook')echo 'current active';?>"><a href="<?php echo base_url();?>home/digital_book">Digital Book</a>
              </li>
			   <li class="<?php if($page_content=='pbuku' || $page_content=='pbukuprodi')echo 'current active';?>"><a href="#">Penelusuran Buku</a>
                    <ul class="dropdown">
                      <li><a href="<?php echo base_url();?>home/penelusuran_buku">Penelusuran Buku</a>
					  </li>
					  <li><a href="<?php echo base_url();?>home/penelusuran_bukuprodi">Penelusuran Buku Ref. Prodi</a>
					  </li>
                    </ul>
                  </li>
			   <li class="<?php if($page_content=='kontak')echo 'current active';?>"><a href="<?php echo base_url();?>home/kontak">Kontak</a>
              </li>
			</ul>
          </nav>
        </div>
      </div>
    </div>
  </header>