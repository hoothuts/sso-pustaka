<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Md_siperpus_inventaris extends CI_Model {

  var $select= 'i.*, b.judul';
  var $table1 = 'siperpus_inventaris';
  var $table = 'siperpus_inventaris i, siperpus_buku b';
  var $where = 'i.ISBN = b.ISBN AND i.no_klas = b.no_klas';
  var $column_order = array(array('no_inv','no_inv'),array('tgl_inv','tgl_inv'),array('asal','asal')); //set column field database for datatable orderable
  var $column_search = array('no_inv','judul'); //set column field database for datatable searchable just firstname , lastname , address are searchable
  var $order = array('tanggal' => 'asc'); // default order

  public function countAll() {

        $this->db->from($this->table);
        return $this->db->count_all_results();
  }
  public function getValue($b,$text){
		foreach($b as $v)
		{
			if(in_array($text, $v, true))
			{
				return $v[1];
			}
		}
		return false;
	}
  private function getDatatablesQuery()
  {
    $this->db->select($this->select);
    $this->db->from($this->table);//from vwanggota
    $this->db->where($this->where);
    $i = 0;
    //checking if there's searching :

    foreach ($this->column_search as $item) // loop column
    {
      if($this->input->post('datatable[query][generalSearch]')) // if datatable send POST for search
      {
        if($i===0) // first loop
        {
          $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
          $this->db->like($item, $this->input->post('datatable[query][generalSearch]'));
        }
        else
        {
          $this->db->or_like($item, $this->input->post('datatable[query][generalSearch]'));
        }
        if(count($this->column_search) - 1 == $i) //last loop
          $this->db->group_end(); //close bracket
      }
      $i++;
    }
    if($this->input->post('datatable[query][klas]')){
			$this->db->like('i.no_klas', $this->input->post('datatable[query][klas]'), 'after');
		}
    // $name= $this->db->list_fields("vwanggota");
    // if($this->input->post('datatable[query][nama]')){
		// 	$this->db->where($name[0], $this->input->post('datatable[query][nama]'));
		// 	}
    //filtering order :

    $val=$this->getValue($this->column_order,$this->input->post('datatable[sort][field]'));
		if($val!= false) // here order processing
		{
			$this->db->order_by($val, $this->input->post('datatable[sort][sort]'));
		}
		else if(isset($this->order))
		{
			$order = $this->order;
			$this->db->order_by(key($order), $order[key($order)]);
		}
  }

  function getDatatables()
  {
    $this->getDatatablesQuery();
    if($this->input->post('datatable[pagination][perpage]') != -1)
      $this->db->limit($this->input->post('datatable[pagination][perpage]'), ($this->input->post('datatable[pagination][perpage]')*(($this->input->post('datatable[pagination][page]')-1))));

    $query = $this->db->get();
    return $query->result();
  }

  function countFiltered()
  {
    $this->getDatatablesQuery();
    $query = $this->db->get();
    return $query->num_rows();
  }

//SELECT *,(SELECT judul FROM `siperpus_buku` WHERE ISBN = inv.ISBN) as judul FROM `siperpus_inventaris` inv WHERE 1
  function getNumRowInvByNoKlas($no_klas){
    $this->db->where('no_klas',$no_klas);
    return $this->db->get('siperpus_inventaris')->num_rows();
  }
  function getNoBarcode(){
    $this->db->select_max('no_barcode');
    return $this->db->get('siperpus_inventaris')->row()->no_barcode;
  }
  function getInventarisByBarcode($barcode){
    $hasil = $this->db->get_where('siperpus_inventaris', array('no_barcode' => $barcode))->result();
    $data = $hasil;
    return $data;
  }

  function getInventarisAll() {
    $hasil = $this->db->query("SELECT *,(SELECT judul FROM `siperpus_buku` WHERE ISBN = inv.ISBN) as judul FROM siperpus_inventaris inv WHERE ISBN ='978.979.044.092.0' order by no_inv asc");
    if ($hasil->num_rows() > 0) {
      foreach ($hasil->result() as $row) {
        $data[] = $row;
      }
      return $data;
    }
  }
  function addInventaris($data){
         $this->db->insert('siperpus_inventaris', $data);
    }
  function hapusInventaris($data){
      $this->db->where('no_barcode',$data);//jangan hapus dengan menggunakan isbn, gunakan no_barcode
      $this->db->delete('siperpus_inventaris');
    }
  function updateInventaris($data){
        $this->db->where('no_barcode', $data['no_barcode']);
        $this->db->update('siperpus_inventaris', $data);
    }
  function getInventarisById($id) {
        $query = "SELECT *,(SELECT judul FROM `siperpus_buku` WHERE ISBN = inv.ISBN AND no_klas = inv.no_klas) as judul FROM siperpus_inventaris inv WHERE no_barcode = '".$id."'";
        $hasil = $this->db->query($query)->result();
        //$hasil = $this->db->get_where('siperpus_inventaris', array('ISBN' => $id))->result();
        $data = $hasil;
        return $data;
    }
  function getInventarisByISBNdanNoKlas($id,$no_klas) {
         $query = "SELECT *,(SELECT judul FROM `siperpus_buku` WHERE ISBN = inv.ISBN) as judul FROM siperpus_inventaris inv WHERE ISBN = '".$id."'" OR "no_klas = '".$no_klas."'";
         $hasil = $this->db->query($query)->result();
         //$hasil = $this->db->get_where('siperpus_inventaris', array('ISBN' => $id))->result();
         $data = $hasil;
         return $data;
     }
  function countByISBN($isbn){
    $where = "ISBN = '".$isbn."'";
    $this->db->from('siperpus_inventaris');//from vwanggota
    $this->db->where($where);
    $query = $this->db->get();
    return $query->num_rows();
  }
  function hapusInventarisAll($isbn){
    $this->db->where('ISBN',$isbn);
    $this->db->delete('siperpus_inventaris');
  }
  function getBarcode($no_barcode){
    $this->db->select('no_inv, no_barcode');
    $this->db->from("siperpus_inventaris");
    $this->db->where(array('no_barcode'=> $no_barcode));
    $data = $this->db->get();
    return $data->result();
  }
  function getDataCallNumber($no_barcode){
    // echo $no_barcode."a";die;
    $this->db->select('no_klas, no_inv, no_barcode');
    $this->db->from("siperpus_inventaris");
    $this->db->where("no_barcode", $no_barcode);
    // $isbn = $this->db->get()->result_array();
    return $this->db->get()->result_array();
  }
}
