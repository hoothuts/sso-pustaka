<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Md_laporan_inventaris extends CI_Model {

  public function getValue($b,$text){
		foreach($b as $v)
		{
			if(in_array($text, $v, true))
			{
				return $v[1];
			}
		}
		return false;
	}

	private function getDatatablesQuery()
	{
		//,array('tgl','ang.tgl_daftar'),array('berlaku','ang.berlaku_sampai')
		$table = 'siperpus_buku sb';
		$column_order = array(array('penulis','sb.penulis'),array('judul','sb.judul'),array('edisi','sb.edisi'),array('tahun','sb.thn_terbit'),array('ISBN','sb.ISBN'),array('jml','sb.jml_buku'),array('no_klas','sb.no_klas'),array('tanggal','sb.tanggal'));
		$column_search = array('sb.penulis','sb.judul','sb.edisi','sb.penerbit','sb.thn_terbit','sb.ISBN','sb.jml_buku','sb.no_klas','sb.tanggal'); 
		$order = array('sb.penulis' => 'asc'); // default order

		$this->db->from($table);

		$i = 0;

		foreach ($column_search as $item) // loop column
		{
			if($this->input->post('datatable[query][generalSearch]')) // if datatable send POST for search
			{

				if($i===0) // first loop
				{
					$this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
					$this->db->like($item, $this->input->post('datatable[query][generalSearch]'));
				}
				else
				{
					$this->db->or_like($item, $this->input->post('datatable[query][generalSearch]'));
				}

				if(count($column_search) - 1 == $i) //last loop
					$this->db->group_end(); //close bracket
			}
			$i++;
		}
		
			if($this->input->post('datatable[query][kategori]')){
				$this->db->where('sb.idkategori',$this->input->post('datatable[query][kategori]'));
			}
			if($this->input->post('datatable[query][tanggalawal]')){
				$this->db->where('sb.tanggal >=',$this->input->post('datatable[query][tanggalawal]'));
			}
			if($this->input->post('datatable[query][tanggalakhir]')){
				$this->db->where('sb.tanggal <=',$this->input->post('datatable[query][tanggalakhir]'));
			}
		//if($i > 0) $this->db->group_end(); //close bracket

		$val=$this->getValue($column_order,$this->input->post('datatable[sort][field]'));
		if($val!= false) // here order processing
		{
			$this->db->order_by($val, $this->input->post('datatable[sort][sort]'));
		}
		else if(isset($order))
		{
			$this->db->order_by(key($order), $order[key($order)]);
		}
	}
	
	private function getLaporanQuery($klas,$ktg,$ta,$tl,$src)
	{
		//,array('tgl','ang.tgl_daftar'),array('berlaku','ang.berlaku_sampai')
		$table = 'siperpus_buku sb';
		$column_order = array(array('penulis','sb.penulis'),array('judul','sb.judul'),array('edisi','sb.edisi'),array('tahun','sb.thn_terbit'),array('ISBN','sb.ISBN'),array('jml','sb.jml_buku'),array('no_klas','sb.no_klas'),array('tanggal','sb.tanggal'));
		$column_search = array('sb.penulis','sb.judul','sb.edisi','sb.penerbit','sb.thn_terbit','sb.ISBN','sb.jml_buku','sb.no_klas','sb.tanggal'); 
		$order = array('sb.penulis' => 'asc'); // default order

		$this->db->from($table);

		$i = 0;

		foreach ($column_search as $item) // loop column
		{
			if($src) // if datatable send POST for search
			{

				if($i===0) // first loop
				{
					$this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
					$this->db->like($item, $src);
				}
				else
				{
					$this->db->or_like($item, $src);
				}

				if(count($column_search) - 1 == $i) //last loop
					$this->db->group_end(); //close bracket
			}
			$i++;
		}

			if($ktg){
				$this->db->where('sb.idkategori',$ktg);
			}
			if($ta){
				$this->db->where('sb.tanggal >=',$ta);
			}
			if($tl){
				$this->db->where('sb.tanggal <=',$tl);
			}
			$this->db->order_by(key($order), $order[key($order)]);
	}
	function getDatatables()
	{
		$this->getDatatablesQuery();
		if($this->input->post('datatable[pagination][perpage]') != -1)
		  $this->db->limit($this->input->post('datatable[pagination][perpage]'), ($this->input->post('datatable[pagination][perpage]')*(($this->input->post('datatable[pagination][page]')-1))));

	  $query = $this->db->get();
		return $query->result();
	}

	function countFiltered()
	{
		$this->getDatatablesQuery();
		$query = $this->db->get();
		return $query->num_rows();
	}
	function getLaporan($klas,$ktg,$ta,$tl,$src) {
		
		$this->getLaporanQuery($klas,$ktg,$ta,$tl,$src);
		$query = $this->db->get();
		return $query->result();
  }
}
