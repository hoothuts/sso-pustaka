<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends CI_Controller {



	 function __construct() {

        parent::__construct();   
        date_default_timezone_set('Asia/Jakarta');     

        $this->load->database();
		$this->load->model('Md_siperpus_sysuser');
		$this->load->model('Md_siperpus_sysgroup');
		$this->load->model('Md_siperpus_sysgrant');
		$this->load->model('Md_vwsiswa');
		$this->load->model('Md_vwdosen');
		$this->load->model('Md_vwanggota');
		$this->load->model('Md_siperpus_anggota_luar');

		$this->load->model('Md_siperpus_klasifikasi');
		
		$this->load->model('Md_siperpus_setting');
		$this->load->model('Md_siperpus_config_transaksi');
		$this->load->model('Md_siperpus_kategori');
		$this->load->model('Md_siperpus_data_buku');
        $this->load->model('Md_siperpus_kategori_buku');
		$this->load->model('Md_siperpus_bahasa');
		$this->load->model('Md_siperpus_asal_buku');
		$this->load->model('Md_siperpus_penerbit');
		$this->load->model('Md_siperpus_keperluan_sbppl');
		$this->load->model('Md_vwprodi');
		$this->load->model('Md_siperpus_matakuliah');

		$this->load->model('Md_siperpus_sysmodul');

        $this->load->model('Md_siperpus_hilangrusak');
		$this->load->model('Md_siperpus_inventaris');
		$this->load->model('Md_siperpus_buku_prodi');
		$this->load->model('Md_siperpus_buku');
		$this->load->model('Md_siperpus_presensi');
		$this->load->model('Md_siperpus_transaksi');
		$this->load->model('Md_vwkaryawan');
		
        $this->load->model('Md_laporan_anggota');
		$this->load->model('Md_laporan_inventaris');
		$this->load->model('Md_laporan_kataloginventaris');
		$this->load->model('Md_laporan_hilang');
		$this->load->model('Md_laporan_denda');
		$this->load->model('Md_laporan_presensi');
		$this->load->model('Md_laporan_peminjaman');
		$this->load->model('Md_laporan_pengembalian');
		$this->load->model('Md_laporan_belumkembali');
		
		//from http://www.zedwood.com/article/php-calculate-duration-of-mp3

		//include APPPATH.'controllers/mp3file.php'; //load mp3file class for calculate duration

		/* cash control */

        $this->output->set_header('Last-Modified: ' . gMDate("D, d M Y H:i:s") . ' GMT');

        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');

        $this->output->set_header('Pragma: no-cache');

        $this->output->set_header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");

    }

	

	public function index()

	{

		if ($this->session->userdata('login_type') != 'admin')

			{

			$this->session->sess_destroy();

            redirect(base_url() . 'home', 'refresh');

			}

        if ($this->session->userdata('login') == 'A')

            redirect(base_url() . 'admin/dashboard', 'refresh');

	}


	function dashboard() {

        if ($this->session->userdata('login_type') != 'admin')
			$this->logout();

        $page_data['page_access'] = "admin";

        $page_data['page_name'] = 'dashboard';

        $page_data['page_now'] = 'dashboard';

        $page_data['page_title'] = 'Manage Dashboard';

		$this->load->view('index', $page_data);

    }
	/** *Data Mahasiswa* **/

	public function data_mahasiswa($param1='',$param2='')
	{
		if ($this->session->userdata('login_type') != 'admin')
				$this->logout();

		$date = new DateTime();
		$id=$this->session->userdata('user_id');

		$page_data['page_action'] = 'list';
		$page_data['page_title'] = 'Data Mahasiswa';
		$page_data['page_access'] = "admin";
		$page_data['page_name'] = 'data_mahasiswa';
		$page_data['page_now'] = 'Data Induk';
		$page_data['prodi'] = $this->Md_vwprodi->getProdiAll();

		if($param1 =='fetch'){
			if($this->input->post('datatable[query][generalSearch]'))
				$total=$this->Md_vwsiswa->countFiltered();
			else $total=$this->Md_vwsiswa->countAll();
				$page=$this->input->post('datatable[pagination][page]');
			if($page<1)
				$page=1;

			$perpage=10;
			$pages=$total/$perpage;
			$field=$this->input->post('datatable[sort][field]');

			if($field=='')
				$field=$this->input->post('datatable[pagination][field]');

			$sort=$this->input->post('datatable[sort][sort]');

			if($sort=='')
				$sort=$this->input->post('datatable[pagination][sort]');

			//mulai fetching data
			$data = array();
			$no = 0;
			$list=$this->Md_vwsiswa->getDatatables();

			foreach ($list as $row) {
				$no++;
				$arr = array();
				$arr['number'] = ($perpage*($page-1))+$no;
				$arr['nis'] = $row->nis;
				$arr['nama'] = $row->nama;
				$arr['kelas'] = $row->kelas;
				$arr['alamat'] = $row->alamat;
				$arr['telepon'] = $row->telepon;
				if ($row->status_siswa=='A')$row->status_siswa="Aktif";
				$arr['status_siswa'] = $row->status_siswa;
				$data[] = $arr;
			}

			$meta=array();
			$meta['page']=$page;
			$meta['pages']=$pages;
			$meta['perpage']=$perpage;
			$meta['total']=$total;
			$meta['sort']=$sort;
			$meta['field']=$field;
			$output = array(
							"meta" => $meta,
							"data" => $data
					);
			//output to json format
			echo json_encode($output);
		}else{
			$this->load->view('index', $page_data);
		}
	}
	
	/** *Data Dosen* **/
	public function data_dosen($param1='',$param2='')
	{
		if ($this->session->userdata('login_type') != 'admin')
				$this->logout();

		$date = new DateTime();
		$id=$this->session->userdata('user_id');

		$page_data['page_action'] = 'list';
		$page_data['page_title'] = 'Data Dosen';
		$page_data['page_access'] = "admin";
		$page_data['page_name'] = 'data_dosen';
		$page_data['page_now'] = 'Data Induk';

		if($param1 =='fetch'){
			if($this->input->post('datatable[query][generalSearch]'))
				$total=$this->Md_vwdosen->countFiltered();
			else $total=$this->Md_vwdosen->countAll();
				$page=$this->input->post('datatable[pagination][page]');
			if($page<1)
				$page=1;

			$perpage=10;
			$pages=$total/$perpage;
			$field=$this->input->post('datatable[sort][field]');

			if($field=='')
				$field=$this->input->post('datatable[pagination][field]');

			$sort=$this->input->post('datatable[sort][sort]');

			if($sort=='')
				$sort=$this->input->post('datatable[pagination][sort]');

			//mulai fetching data
			$data = array();
			$no = 0;
			$list=$this->Md_vwdosen->getDatatables();
			//$prodi= $this->Md_vwprodi->getProdiAll();

			foreach ($list as $row) {
				$no++;
				$arr = array();
				$arr['number'] = ($perpage*($page-1))+$no;
				$arr['nip'] = $row->nip;
				$arr['nama'] = $row->nama;
				$arr['kelas'] = $row->kelas;
				$arr['jabatan'] = "-";
				$arr['status'] = $row->status;
				$data[] = $arr;
			}

			$meta=array();
			$meta['page']=$page;
			$meta['pages']=$pages;
			$meta['perpage']=$perpage;
			$meta['total']=$total;
			$meta['sort']=$sort;
			$meta['field']=$field;
			$output = array(
							"meta" => $meta,
							"data" => $data
					);
			//output to json format
			echo json_encode($output);
		}else{
			$this->load->view('index', $page_data);
		}
	}

	/** *Data Anggota* **/

	public function data_anggota($param1='',$param2='')
	{
		if ($this->session->userdata('login_type') != 'admin')
				$this->logout();

		$date = new DateTime();
		$id=$this->session->userdata('user_id');

		$page_data['page_action'] = 'list';
		$page_data['page_title'] = 'Data Anggota';
		$page_data['page_access'] = "admin";
		$page_data['page_name'] = 'data_anggota';
		$page_data['page_now'] = 'Data Induk';

		if ($param1=='get' && $param2!='') {
			$data = $this->Md_vwanggota->getAnggotaById($param2);
			echo json_encode($data);
		}else if($param1 =='fetch'){
			if($this->input->post('datatable[query][generalSearch]'))
				$total=$this->Md_vwanggota->countFiltered();
			else $total=$this->Md_vwanggota->countAll();
				$page=$this->input->post('datatable[pagination][page]');
			if($page<1)
				$page=1;

			$perpage=10;
			$pages=$total/$perpage;
			$field=$this->input->post('datatable[sort][field]');

			if($field=='')
				$field=$this->input->post('datatable[pagination][field]');

			$sort=$this->input->post('datatable[sort][sort]');

			if($sort=='')
				$sort=$this->input->post('datatable[pagination][sort]');

			//mulai fetching datad
			$data = array();
			$no = 0;
			$list=$this->Md_vwanggota->getDatatables();
			//$prodi= $this->Md_vwprodi->getProdiAll();

			foreach ($list as $row) {
				$no++;
				$arr = array();
				$arr['number'] = ($perpage*($page-1))+$no;
				$arr['nis'] = $row->nis;
				$arr['nis1'] = $row->nis;
				$arr['nama'] = $row->nama;
				if ($row->status==1) $row->status="Aktif";
				$arr['status'] = $row->status;
				$arr['berlaku_sampai'] = $row->berlaku_sampai;
				if ($row->jk=='P')$row->jk="Perempuan";
				else $row->jk="Laki-Laki";
				$arr['jk'] = $row->jk;
				$arr['tempatlahir'] = $row->tempatlahir;
				$arr['tgllahir'] = $row->tgllahir;
				$data[] = $arr;
			}

			$meta=array();
			$meta['page']=$page;
			$meta['pages']=$pages;
			$meta['perpage']=$perpage;
			$meta['total']=$total;
			$meta['sort']=$sort;
			$meta['field']=$field;
			$output = array(
							"meta" => $meta,
							"data" => $data
					);
			//output to json format
			echo json_encode($output);
		}else{
			$this->load->view('index', $page_data);
		}
	}

	/** *Data Anggota Luar* **/
	public function data_anggota_luar($param1='',$param2='')
	{
		if ($this->session->userdata('login_type') != 'admin')
				$this->logout();

		$date = new DateTime();
		$id=$this->session->userdata('user_id');

		$page_data['page_action'] = 'list';
		$page_data['page_title'] = 'Data Anggota Luar';
		$page_data['page_access'] = "admin";
		$page_data['page_name'] = 'data_anggota_luar';
		$page_data['page_now'] = 'Data Induk';

		if ($param1 == 'submit') {
			$data = array('noid' => $this->input->post('noid'),
										'nama' => $this->input->post('nama'),
										'jk' => $this->input->post('jk'),
										'alamat' => $this->input->post('alamat'),
										'telepon' => $this->input->post('telepon'),
										'tempatlahir' => $this->input->post('tempatlahir'),
										'tgllahir' => $this->input->post('tgllahir'),
										'instansi_asal_nama' => $this->input->post('instansi_asal_nama'),
										'instansi_asal_alamat' => $this->input->post('instansi_asal_alamat'),
										'jabatan_semester' => $this->input->post('jabatan_semester')
							);
			if($data['noid']=='' || $data['nama']==''){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-danger');
				$this->session->set_flashdata('flash_message', 'Empty Field');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
			}else{
				$buku=$this->Md_siperpus_anggota_luar->getAnggotaLuarById($this->input->post('noid'));
				if($buku){
					//Id duplicate
					$this->session->set_flashdata('alert', 'alert-danger');
					$this->session->set_flashdata('flash_message', 'ID telah ada, data anggota luar gagal dibuat');
					echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "ID telah ada, data anggota luar gagal dibuat"));
					//redirect(base_url() . 'admin/klasifikasi_buku/tambah', 'refresh');
				}else{
					$this->Md_siperpus_anggota_luar->addKAnggotaLuar($data);
					$this->session->set_flashdata('alert', 'alert-focus');
					$this->session->set_flashdata('flash_message', 'Data Angota Luar Sukses dibuat');
					echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Data Angota Luar Sukses dibuat"));
					}
				}
			}else if ($param1 == 'update') {
				$id1=$this->input->post('id1');
				$data = array('noid' => $this->input->post('noid'),
											'nama' => $this->input->post('nama'),
											'jk' => $this->input->post('jk'),
											'alamat' => $this->input->post('alamat'),
											'telepon' => $this->input->post('telepon'),
											'tempatlahir' => $this->input->post('tempatlahir'),
											'tgllahir' => $this->input->post('tgllahir'),
											'instansi_asal_nama' => $this->input->post('instansi_asal_nama'),
											'instansi_asal_alamat' => $this->input->post('instansi_asal_alamat'),
											'jabatan_semester' => $this->input->post('jabatan_semester')
								);
				if($data['noid']=='' || $data['nama']==''){
					//Empty Field
					$this->session->set_flashdata('alert', 'alert-danger');
					$this->session->set_flashdata('flash_message', 'Empty Field');
					echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
				}else{
					$this->Md_siperpus_anggota_luar->updateAnggotaLuar($id1, $data);
					$this->session->set_flashdata('alert', 'alert-focus');
					$this->session->set_flashdata('flash_message', 'Anggota Luar Sukses diedit');
					echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Anggota Luar Sukses diedit"));
				}
			}else if ($param1=='hapus' && $param2 !='') {
				$this->Md_siperpus_anggota_luar->hapusAnggotaLuar($param2);
				$this->session->set_flashdata('alert', 'alert-focus');
				$this->session->set_flashdata('flash_message', 'Anggota Luar Sukses Dihapus');
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Anggota Luar Sukses Dihapus"));
			}else if($param1 =='edit' && $param2 !=''){
				$data = $this->Md_siperpus_anggota_luar->getAnggotaLuarById($param2);
				echo json_encode($data);
			}else if($param1 =='fetch'){
				if($this->input->post('datatable[query][generalSearch]'))
					$total=$this->Md_siperpus_anggota_luar->countFiltered();
				else $total=$this->Md_siperpus_anggota_luar->countAll();
					$page=$this->input->post('datatable[pagination][page]');
				if($page<1)
					$page=1;

				$perpage=10;
				$pages=$total/$perpage;
				$field=$this->input->post('datatable[sort][field]');

				if($field=='')
					$field=$this->input->post('datatable[pagination][field]');

				$sort=$this->input->post('datatable[sort][sort]');

				if($sort=='')
					$sort=$this->input->post('datatable[pagination][sort]');

				//mulai fetching data
				$data = array();
				$no = 0;
				$list=$this->Md_siperpus_anggota_luar->getDatatables();
				//$prodi= $this->Md_vwprodi->getProdiAll();

				foreach ($list as $row) {
					$no++;
					$arr = array();
					$arr['number'] = ($perpage*($page-1))+$no;
					$arr['noid'] = $row->noid;
					$arr['nama'] = $row->nama;
					$arr['instansi_asal_nama'] = $row->instansi_asal_nama;
					$data[] = $arr;
				}

				$meta=array();
				$meta['page']=$page;
				$meta['pages']=$pages;
				$meta['perpage']=$perpage;
				$meta['total']=$total;
				$meta['sort']=$sort;
				$meta['field']=$field;
				$output = array(
								"meta" => $meta,
								"data" => $data
						);
				//output to json format
				echo json_encode($output);
		}else{
			$this->load->view('index', $page_data);
		}
	}
	
	/** *Data Klasifikasi* **/
    function klasifikasi_buku($param1 = '', $param2 = '', $param3 = '')
		{
			if ($this->session->userdata('login_type') != 'admin') $this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');
	    $page_data['page_action'] = 'list';
	    $page_data['page_title'] = 'Data Klasifikasi Buku';
			$page_data['page_access'] = "admin";
			$page_data['page_name'] = 'klasifikasi_buku';
			$page_data['page_now'] = 'Data Referensi';

			if ($param1 == 'submit') {
				$data['id'] = $this->input->post('id');
				$data['nama'] = $this->input->post('nama');
				if($data['id']=='' || $data['nama']==''){
					//Empty Field
					$this->session->set_flashdata('alert', 'alert-danger');
					$this->session->set_flashdata('flash_message', 'Empty Field');
					echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
					//redirect(base_url() . 'admin/klasifikasi_buku/tambah', 'refresh');
				}else{
					$buku=$this->Md_siperpus_klasifikasi->getKlasifikasiById($this->input->post('id'));
					if($buku){
						//Id duplicate
						$this->session->set_flashdata('alert', 'alert-danger');
						$this->session->set_flashdata('flash_message', 'ID telah dipakai, klasifikasi buku gagal dibuat');
						echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "ID telah dipakai, Klasifikasi buku gagal dibuat"));
						//redirect(base_url() . 'admin/klasifikasi_buku/tambah', 'refresh');
					}else{
						$this->Md_siperpus_klasifikasi->addKlasifikasi($data);
						$this->session->set_flashdata('alert', 'alert-focus');
						$this->session->set_flashdata('flash_message', 'Klasifikasi Buku Sukses dibuat');
						echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Klasifikasi Buku Sukses dibuat"));
						//redirect(base_url() . 'admin/klasifikasi_buku', 'refresh');
						}
					}
	      }else if ($param1 == 'update') {
					$id1=$this->input->post('id1');
					$data['id'] = $this->input->post('id');
					$data['nama'] = $this->input->post('nama');
					if($data['id']=='' || $data['nama']==''){
						//Empty Field
						$this->session->set_flashdata('alert', 'alert-danger');
						$this->session->set_flashdata('flash_message', 'Empty Field');
						echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
					}else{
						$this->Md_siperpus_klasifikasi->updateKlasifikasi($id1, $data);
						$this->session->set_flashdata('alert', 'alert-focus');
						$this->session->set_flashdata('flash_message', 'Klasifikasi Buku Sukses diedit');
						echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Klasifikasi Buku Sukses diedit".$data['id']));
					}
	      }else if ($param1=='hapus' && $param2 !='') {
					$this->Md_siperpus_klasifikasi->hapusKlasifikasi($param2);
					$this->session->set_flashdata('alert', 'alert-focus');
					$this->session->set_flashdata('flash_message', 'Klasifikasi Buku Sukses Dihapus');
					echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Klasifikasi Buku Sukses Dihapus"));
				}else if($param1 =='edit' && $param2 !=''){
					$data = $this->Md_siperpus_klasifikasi->getKlasifikasiById($param2);
					echo json_encode($data);
				}else if($param1 =='fetch'){
					if($this->input->post('datatable[query][generalSearch]'))
						$total=$this->Md_siperpus_klasifikasi->countFiltered();
					else $total=$this->Md_siperpus_klasifikasi->countAll();
						$page=$this->input->post('datatable[pagination][page]');
					if($page<1)
						$page=1;

					$perpage=10;
					$pages=$total/$perpage;
					$field=$this->input->post('datatable[sort][field]');

					if($field=='')
						$field=$this->input->post('datatable[pagination][field]');

					$sort=$this->input->post('datatable[sort][sort]');

					if($sort=='')
						$sort=$this->input->post('datatable[pagination][sort]');

					$data = array();
					$no = 0;
					$list=$this->Md_siperpus_klasifikasi->getDatatables();

					foreach ($list as $row) {
						$no++;
						$arr = array();
						$arr['number'] = ($perpage*($page-1))+$no;
						$arr['id'] = $row->id;
						$arr['nama'] = $row->nama;
						$data[] = $arr;
					}
					$meta=array();
					$meta['page']=$page;
					$meta['pages']=$pages;
					$meta['perpage']=$perpage;
					$meta['total']=$total;
					$meta['sort']=$sort;
					$meta['field']=$field;
					$output = array(
									"meta" => $meta,
									"data" => $data
							);
					//output to json format
					echo json_encode($output);

				}else{
					$this->load->view('index', $page_data);
				}
		}
	/** Konfigurasi **/
    function konfigurasi($param1 = '', $param2 = '', $param3 = '') {

        if ($this->session->userdata('login_type') != 'admin')

            $this->logout();

		$date = new DateTime();

		$id=$this->session->userdata('user_id');

        $page_data['page_action'] = 'list';
        $page_data['data']=$this->Md_siperpus_setting->getSettingAll();
		$page_data['data_kategori']=$this->Md_siperpus_kategori->getKategoriAll();
        $page_data['page_title'] = 'Pengaturan Program';
		if ($param1 == 'update') {

			$setting1= $this->input->post('setting1');
			$setting2= $this->input->post('setting2');
			$setting3= $this->input->post('setting3');
			$setting4= $this->input->post('setting4');
			$setting5= $this->input->post('setting5');
			$setting6= $this->input->post('setting6');
			$setting7= $this->input->post('setting7');
			$setting8= $this->input->post('setting8');
			$setting9= $this->input->post('setting9');
			$setting10= $this->input->post('setting10');
			$setting1kode= $this->input->post('setting1kode');
			$setting2kode= $this->input->post('setting2kode');
			$setting3kode= $this->input->post('setting3kode');
			$setting4kode= $this->input->post('setting4kode');
			$setting5kode= $this->input->post('setting5kode');
			$setting6kode= $this->input->post('setting6kode');
			$setting7kode= $this->input->post('setting7kode');
			$setting8kode= $this->input->post('setting8kode');
			$setting9kode= $this->input->post('setting9kode');
			$setting10kode= $this->input->post('setting10kode');
			
			if($setting1 !=''&& $setting1kode !=''){
				$data['valsetting']=$setting1;
				$this->Md_siperpus_setting->updateSetting($setting1kode,$data);
			}
			if($setting2 !=''&& $setting2kode !=''){
				$data['valsetting']=$setting2;
				$this->Md_siperpus_setting->updateSetting($setting2kode,$data);
			}
			if($setting3 !=''&& $setting3kode !=''){
				$data['valsetting']=$setting3;
				$this->Md_siperpus_setting->updateSetting($setting3kode,$data);
			}
			if($setting4 !=''&& $setting4kode !=''){
				$data['valsetting']=$setting4;
				$this->Md_siperpus_setting->updateSetting($setting4kode,$data);
			}
			if($setting5 !=''&& $setting5kode !=''){
				$data['valsetting']=$setting5;
				$this->Md_siperpus_setting->updateSetting($setting5kode,$data);
			}
			if($setting6 !=''&& $setting6kode !=''){
				$data['valsetting']=$setting6;
				$this->Md_siperpus_setting->updateSetting($setting6kode,$data);
			}
			if($setting7 !=''&& $setting7kode !=''){
				$data['valsetting']=$setting7;
				$this->Md_siperpus_setting->updateSetting($setting7kode,$data);
			}
			if($setting8 !=''&& $setting8kode !=''){
				$data['valsetting']=$setting8;
				$this->Md_siperpus_setting->updateSetting($setting8kode,$data);
			}
			if($setting9 !=''&& $setting9kode !=''){
				$data['valsetting']=$setting9;
				$this->Md_siperpus_setting->updateSetting($setting9kode,$data);
			}
			if($setting10 !=''&& $setting10kode !=''){
				$data['valsetting']=$setting10;
				$this->Md_siperpus_setting->updateSetting($setting10kode,$data);
			}
			
			
				$this->session->set_flashdata('alert', 'alert-warning');

				$this->session->set_flashdata('flash_message', 'Update Setting Sukses');

				redirect(base_url() . 'admin/konfigurasi/', 'refresh');
			
			
        }
        $page_data['page_access'] = "admin";
        $page_data['page_name'] = 'konfigurasi';
        $page_data['page_now'] = 'Konfigurasi Transaksi';
        $this->load->view('index', $page_data);

    }
	public function logout(){

	$date = new DateTime();

		$id=$this->session->userdata('user_id');
		
		if(!empty($id)){
				/*
			$user=$this->Md_user->getuserById($id);
			$log['user_id']=$id;
			$log['tgl']=$date->format("Y-m-d H:i:s");
			$log['jenis_log']='admin';
			$log['jenis_akses']='LogOut';
			$log['status']=1;
			$log['keterangan']=$user[0]->username.' Melakukan LogOut';
			$log['IP']=$_SERVER['REMOTE_ADDR'];
			$this->Md_log->addLogBaru($log);
			*/
		}
		$this->session->sess_destroy();

	    redirect(base_url() . 'home', 'refresh');

	}

	/**Kategori Buku**/

	public function kategori_buku($param1='',$param2='')
		{
			if ($this->session->userdata('login_type') != 'admin')
					$this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');

			$page_data['page_action'] = 'list';
			$page_data['page_title'] = 'Data Kategori Buku';
			$page_data['page_access'] = "admin";
			$page_data['page_name'] = 'kategori_buku';
			$page_data['page_now'] = 'Data Referensi';

			if ($param1 == 'submit') {
				$data['id'] = $this->input->post('id');
				$data['nama'] = $this->input->post('nama');
				if($data['id']=='' || $data['nama']==''){
					//Empty Field
					$this->session->set_flashdata('alert', 'alert-danger');
					$this->session->set_flashdata('flash_message', 'Empty Field');
					echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
				}else{
					$buku=$this->Md_siperpus_kategori_buku->getKategoriById($this->input->post('idkategori'));
					if($buku){
						//Id duplicate
						$this->session->set_flashdata('alert', 'alert-danger');
						$this->session->set_flashdata('flash_message', 'ID telah dipakai, Kategori buku gagal dibuat');
						echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "ID telah dipakai, Kategori buku gagal dibuat"));
					}else{
						$this->Md_siperpus_kategori_buku->addKategoriBuku($data);
						$this->session->set_flashdata('alert', 'alert-focus');
						$this->session->set_flashdata('flash_message', 'Kategori Buku Sukses dibuat');
						echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Kategori Buku Sukses dibuat"));
						}
					}
	      }else if ($param1 == 'update') {
					$data['idkategori'] = $this->input->post('idkategori');
					$data['nmkategori'] = $this->input->post('nmkategori');
					if($data['idkategori']=='' || $data['nmkategori']==''){
						//Empty Field
						$this->session->set_flashdata('alert', 'alert-danger');
						$this->session->set_flashdata('flash_message', 'Empty Field');
						echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
					}else{
						$this->Md_siperpus_kategori_buku->updateKategoriBuku($data['idkategori'], $data);
						$this->session->set_flashdata('alert', 'alert-focus');
						$this->session->set_flashdata('flash_message', 'Kategori Buku Sukses diedit');
						echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Kategori Buku Sukses diedit"));
					}
	      }else if ($param1=='hapus' && $param2 !='') {
					$this->Md_siperpus_kategori_buku->hapusKategoriBuku($param2);
					$this->session->set_flashdata('alert', 'alert-focus');
					$this->session->set_flashdata('flash_message', 'Kategori Buku Sukses Dihapus');
					echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Kategori Buku Sukses Dihapus"));
				}else if($param1 =='edit' && $param2 !=''){
					$data = $this->Md_siperpus_kategori_buku->getKategoriById($param2);
					echo json_encode($data);
				}else if($param1 =='fetch'){
					if($this->input->post('datatable[query][generalSearch]'))
						$total=$this->Md_siperpus_kategori_buku->countFiltered();
					else $total=$this->Md_siperpus_kategori_buku->countAll();
						$page=$this->input->post('datatable[pagination][page]');
					if($page<1)
						$page=1;

					$perpage=10;
					$pages=$total/$perpage;
					$field=$this->input->post('datatable[sort][field]');

					if($field=='')
						$field=$this->input->post('datatable[pagination][field]');

					$sort=$this->input->post('datatable[sort][sort]');

					if($sort=='')
						$sort=$this->input->post('datatable[pagination][sort]');

					$data = array();
					$no = 0;
					$list=$this->Md_siperpus_kategori_buku->getDatatables();

					foreach ($list as $row) {
						$no++;
						$arr = array();
						$arr['number'] = ($perpage*($page-1))+$no;
						$arr['idkategori'] = $row->idkategori;
						$arr['nmkategori'] = $row->nmkategori;
						$data[] = $arr;
					}
					$meta=array();
					$meta['page']=$page;
					$meta['pages']=$pages;
					$meta['perpage']=$perpage;
					$meta['total']=$total;
					$meta['sort']=$sort;
					$meta['field']=$field;
					$output = array(
									"meta" => $meta,
									"data" => $data
							);
					//output to json format
					echo json_encode($output);

				}else{
					$this->load->view('index', $page_data);
				}
		}
		
		/** *Bahasa* **/

		public function bahasa($param1='',$param2='')
		{
			if ($this->session->userdata('login_type') != 'admin')
					$this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');

			$page_data['page_action'] = 'list';
			$page_data['page_title'] = 'Data Bahasa';
			$page_data['page_access'] = "admin";
			$page_data['page_name'] = 'bahasa';
			$page_data['page_now'] = 'Data Referensi';

			if ($param1 == 'submit') {
				$data['id'] = $this->input->post('id');
				$data['nama'] = $this->input->post('nama');
				$data['no_urut'] = $this->input->post('no_urut');
				if($data['id']=='' || $data['nama']==''){
					//Empty Field
					$this->session->set_flashdata('alert', 'alert-danger');
					$this->session->set_flashdata('flash_message', 'Empty Field');
					echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
				}else{
					$buku=$this->Md_siperpus_bahasa->getBahasaById($this->input->post('id'));
					if($buku){
						//Id duplicate
						$this->session->set_flashdata('alert', 'alert-danger');
						$this->session->set_flashdata('flash_message', 'ID telah dipakai, bahasa buku gagal dibuat');
						echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "ID telah dipakai, bahasa buku gagal dibuat"));
					}else{
						$this->Md_siperpus_bahasa->addBahasa($data);
						$this->session->set_flashdata('alert', 'alert-focus');
						$this->session->set_flashdata('flash_message', 'Kategori Buku Sukses dibuat');
						echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Bahasa Buku Sukses dibuat"));
						}
					}
	      }else if ($param1 == 'update') {
					$id1 = $this->input->post('id1');
					$data['id'] = $this->input->post('id');
					$data['nama'] = $this->input->post('nama');
					$data['no_urut'] = $this->input->post('no_urut');
					if($data['id']=='' || $data['nama']==''){
						//Empty Field
						$this->session->set_flashdata('alert', 'alert-danger');
						$this->session->set_flashdata('flash_message', 'Empty Field');
						echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
					}else{
						$this->Md_siperpus_bahasa->updateBahasa($id1, $data);
						$this->session->set_flashdata('alert', 'alert-focus');
						$this->session->set_flashdata('flash_message', 'Bahasa Buku Sukses diedit');
						echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Bahasa Buku Sukses diedit"));
					}
	      }else if ($param1=='hapus' && $param2 !='') {
					$this->Md_siperpus_bahasa->hapusBahasa($param2);
					$this->session->set_flashdata('alert', 'alert-focus');
					$this->session->set_flashdata('flash_message', 'Bahasa Buku Sukses Dihapus');
					echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Bahasa Buku Sukses Dihapus"));
				}else if($param1 =='edit' && $param2 !=''){
					$data = $this->Md_siperpus_bahasa->getBahasaById($param2);
					echo json_encode($data);
				}else if($param1 =='fetch'){
					if($this->input->post('datatable[query][generalSearch]'))
						$total=$this->Md_siperpus_bahasa->countFiltered();
					else $total=$this->Md_siperpus_bahasa->countAll();
						$page=$this->input->post('datatable[pagination][page]');
					if($page<1)
						$page=1;

					$perpage=10;
					$pages=$total/$perpage;
					$field=$this->input->post('datatable[sort][field]');

					if($field=='')
						$field=$this->input->post('datatable[pagination][field]');

					$sort=$this->input->post('datatable[sort][sort]');

					if($sort=='')
						$sort=$this->input->post('datatable[pagination][sort]');

					$data = array();
					$no = 0;
					$list=$this->Md_siperpus_bahasa->getDatatables();

					foreach ($list as $row) {
						$no++;
						$arr = array();
						$arr['number'] = ($perpage*($page-1))+$no;
						$arr['id'] = $row->id;
						$arr['nama'] = $row->nama;
						$arr['no_urut'] = $row->no_urut;
						$data[] = $arr;
					}
					$meta=array();
					$meta['page']=$page;
					$meta['pages']=$pages;
					$meta['perpage']=$perpage;
					$meta['total']=$total;
					$meta['sort']=$sort;
					$meta['field']=$field;
					$output = array(
									"meta" => $meta,
									"data" => $data
							);
					//output to json format
					echo json_encode($output);

				}else{
					$this->load->view('index', $page_data);
				}
		}
		/** *Asal Buku* **/

		public function asal_buku($param1='',$param2='')
		{
			if ($this->session->userdata('login_type') != 'admin')
					$this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');

			$page_data['page_action'] = 'list';
			$page_data['page_title'] = 'Data Asal Buku';
			$page_data['page_access'] = "admin";
			$page_data['page_name'] = 'asal_buku';
			$page_data['page_now'] = 'Data Referensi';

			if ($param1 == 'submit') {
				$data['id'] = $this->input->post('id');
				$data['nama'] = $this->input->post('nama');
				if($data['id']=='' || $data['nama']==''){
					//Empty Field
					$this->session->set_flashdata('alert', 'alert-danger');
					$this->session->set_flashdata('flash_message', 'Empty Field');
					echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
				}else{
					$buku=$this->Md_siperpus_asal_buku->getAsalBukuById($this->input->post('id'));
					if($buku){
						//Id duplicate
						$this->session->set_flashdata('alert', 'alert-danger');
						$this->session->set_flashdata('flash_message', 'ID telah dipakai, Asal buku gagal dibuat');
						echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "ID telah dipakai, Asal buku gagal dibuat"));
					}else{
						$this->Md_siperpus_asal_buku->addAsalBuku($data);
						$this->session->set_flashdata('alert', 'alert-focus');
						$this->session->set_flashdata('flash_message', 'Asal Buku Sukses dibuat');
						echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Asal Buku Sukses dibuat"));
						}
					}
	      }else if ($param1 == 'update') {
					$id1 = $this->input->post('id1');
					$data['id'] = $this->input->post('id');
					$data['nama'] = $this->input->post('nama');
					if($data['id']=='' || $data['nama']==''){
						//Empty Field
						$this->session->set_flashdata('alert', 'alert-danger');
						$this->session->set_flashdata('flash_message', 'Empty Field');
						echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
					}else{
						$this->Md_siperpus_asal_buku->updateAsalBuku($id1, $data);
						$this->session->set_flashdata('alert', 'alert-focus');
						$this->session->set_flashdata('flash_message', 'Asal Buku Sukses diedit');
						echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Asal Buku Sukses diedit"));
					}
	      }else if ($param1=='hapus' && $param2 !='') {
					$this->Md_siperpus_asal_buku->hapusAsalBuku($param2);
					$this->session->set_flashdata('alert', 'alert-focus');
					$this->session->set_flashdata('flash_message', 'Asal Buku Sukses Dihapus');
					echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Asal Buku Sukses Dihapus"));
				}else if($param1 =='edit' && $param2 !=''){
					$data = $this->Md_siperpus_asal_buku->getAsalBukuById($param2);
					echo json_encode($data);
				}else if($param1 =='fetch'){
					if($this->input->post('datatable[query][generalSearch]'))
						$total=$this->Md_siperpus_asal_buku->countFiltered();
					else $total=$this->Md_siperpus_asal_buku->countAll();
						$page=$this->input->post('datatable[pagination][page]');
					if($page<1)
						$page=1;

					$perpage=10;
					$pages=$total/$perpage;
					$field=$this->input->post('datatable[sort][field]');

					if($field=='')
						$field=$this->input->post('datatable[pagination][field]');

					$sort=$this->input->post('datatable[sort][sort]');

					if($sort=='')
						$sort=$this->input->post('datatable[pagination][sort]');

					$data = array();
					$no = 0;
					$list=$this->Md_siperpus_asal_buku->getDatatables();

					foreach ($list as $row) {
						$no++;
						$arr = array();
						$arr['number'] = ($perpage*($page-1))+$no;
						$arr['id'] = $row->id;
						$arr['nama'] = $row->nama;
						$data[] = $arr;
					}
					$meta=array();
					$meta['page']=$page;
					$meta['pages']=$pages;
					$meta['perpage']=$perpage;
					$meta['total']=$total;
					$meta['sort']=$sort;
					$meta['field']=$field;
					$output = array(
									"meta" => $meta,
									"data" => $data
							);
					//output to json format
					echo json_encode($output);

				}else{
					$this->load->view('index', $page_data);
				}
		}
		/** *Penerbit* **/

		public function penerbit($param1='',$param2='')
		{
			if ($this->session->userdata('login_type') != 'admin')
					$this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');

			$page_data['page_action'] = 'list';
			$page_data['page_title'] = 'Data Penerbit';
			$page_data['page_access'] = "admin";
			$page_data['page_name'] = 'penerbit';
			$page_data['page_now'] = 'Data Referensi';

			if ($param1 == 'submit') {
				$data = array('nama_penerbit' => $this->input->post('nama_penerbit'),
											'kota' => $this->input->post('kota')
								);
				if($data['nama_penerbit']=='' || $data['kota']==''){
					//Empty Field
					$this->session->set_flashdata('alert', 'alert-danger');
					$this->session->set_flashdata('flash_message', 'Empty Field');
					echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
				}else{
					$buku=$this->Md_siperpus_penerbit->getPenerbitByNama($this->input->post('nama_penerbit'));
					if($buku){
						//Id duplicate
						$this->session->set_flashdata('alert', 'alert-danger');
						$this->session->set_flashdata('flash_message', 'Nama Penerbit Sudah Ada, Penerbit gagal dibuat');
						echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Nama Penerbit Sudah Ada, Penerbit gagal dibuat"));
					}else{
						$this->Md_siperpus_penerbit->addPenerbit($data);
						$this->session->set_flashdata('alert', 'alert-focus');
						$this->session->set_flashdata('flash_message', 'Penerbit Sukses dibuat');
						echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Penerbit Sukses dibuat"));
						}
					}
	      }else if ($param1 == 'update') {
					$id1 = $this->input->post('id1');
					$data = array('nama_penerbit' => $this->input->post('nama_penerbit'),
												'kota' => $this->input->post('kota')
									);
					if( $data['nama_penerbit']=='' || $data['kota']==''){
						//Empty Field
						$this->session->set_flashdata('alert', 'alert-danger');
						$this->session->set_flashdata('flash_message', 'Empty Field');
						echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
					}else{
						$this->Md_siperpus_penerbit->updatePenerbit($id1, $data);
						$this->session->set_flashdata('alert', 'alert-focus');
						$this->session->set_flashdata('flash_message', 'Penerbit Sukses diedit');
						echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Penerbit Sukses diedit"));
					}
	      }else if ($param1=='hapus' && $param2 !='') {
					$this->Md_siperpus_penerbit->hapusPenerbit($param2);
					$this->session->set_flashdata('alert', 'alert-focus');
					$this->session->set_flashdata('flash_message', 'Penerbit Sukses Dihapus');
					echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Penerbit Sukses Dihapus"));
				}else if($param1 =='edit' && $param2 !=''){
					$data = $this->Md_siperpus_penerbit->getPenerbitById($param2);
					echo json_encode($data);
				}else if($param1 =='fetch'){
					if($this->input->post('datatable[query][generalSearch]'))
						$total=$this->Md_siperpus_penerbit->countFiltered();
					else $total=$this->Md_siperpus_penerbit->countAll();
						$page=$this->input->post('datatable[pagination][page]');
					if($page<1)
						$page=1;

					$perpage=10;
					$pages=$total/$perpage;
					$field=$this->input->post('datatable[sort][field]');

					if($field=='')
						$field=$this->input->post('datatable[pagination][field]');

					$sort=$this->input->post('datatable[sort][sort]');

					if($sort=='')
						$sort=$this->input->post('datatable[pagination][sort]');

					$data = array();
					$no = 0;
					$list=$this->Md_siperpus_penerbit->getDatatables();

					foreach ($list as $row) {
						$no++;
						$arr = array();
						$arr['number'] = ($perpage*($page-1))+$no;
						$arr['kd_penerbit'] = $row->kd_penerbit;
						$arr['nama_penerbit'] = $row->nama_penerbit;
						$arr['kota'] = $row->kota;
						$data[] = $arr;
					}
					$meta=array();
					$meta['page']=$page;
					$meta['pages']=$pages;
					$meta['perpage']=$perpage;
					$meta['total']=$total;
					$meta['sort']=$sort;
					$meta['field']=$field;
					$output = array(
									"meta" => $meta,
									"data" => $data
							);
					//output to json format
					echo json_encode($output);

				}else{
					$this->load->view('index', $page_data);
				}
		}
		/** *Keperluan SPPBL* **/

		public function keperluan_sbppl($param1='',$param2='')
		{
			if ($this->session->userdata('login_type') != 'admin')
					$this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');

			$page_data['page_action'] = 'list';
			$page_data['page_title'] = 'Keperluan SBPPL';
			$page_data['page_access'] = "admin";
			$page_data['page_name'] = 'keperluan_sbppl';
			$page_data['page_now'] = 'Data Referensi';

			if ($param1 == 'submit') {
				$data['nama'] = $this->input->post('nama');
				$data['no_urut'] = $this->input->post('no_urut');
				if($data['nama']=='' || $data['no_urut'] == ''){
					//Empty Field
					$this->session->set_flashdata('alert', 'alert-danger');
					$this->session->set_flashdata('flash_message', 'Empty Field');
					echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
				}else{
					$buku=$this->Md_siperpus_keperluan_sbppl->getSbpplByNama($this->input->post('nama'));
					if($buku){
						//Id duplicate
						$this->session->set_flashdata('alert', 'alert-danger');
						$this->session->set_flashdata('flash_message', 'ID telah dipakai, SBPPL gagal dibuat');
						echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "ID telah dipakai, SBPPL gagal dibuat"));
					}else{
						$this->Md_siperpus_keperluan_sbppl->addSbppl($data);
						$this->session->set_flashdata('alert', 'alert-focus');
						$this->session->set_flashdata('flash_message', 'SBPPL Sukses dibuat');
						echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "SBPPL Sukses dibuat"));
						}
					}
	      }else if ($param1 == 'update') {
					$id1 = $this->input->post('id1');
					$data['nama'] = $this->input->post('nama');
					$data['no_urut'] = $this->input->post('no_urut');
					if($data['nama']=='' || $data['no_urut']==''){
						//Empty Field
						$this->session->set_flashdata('alert', 'alert-danger');
						$this->session->set_flashdata('flash_message', 'Empty Field');
						echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
					}else{
						$this->Md_siperpus_keperluan_sbppl->updateSbppl($id1, $data);
						$this->session->set_flashdata('alert', 'alert-focus');
						$this->session->set_flashdata('flash_message', 'SBPPL Sukses diedit');
						echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "SBPPL Sukses diedit"));
					}
	      }else if ($param1=='hapus' && $param2 !='') {
					$this->Md_siperpus_keperluan_sbppl->hapusSbppl($param2);
					$this->session->set_flashdata('alert', 'alert-focus');
					$this->session->set_flashdata('flash_message', 'SBPPL Sukses Dihapus');
					echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "SBPPL Sukses Dihapus"));
				}else if($param1 =='edit' && $param2 !=''){
					$data = $this->Md_siperpus_keperluan_sbppl->getSbpplById($param2);
					echo json_encode($data);
				}else if($param1 =='fetch'){
					if($this->input->post('datatable[query][generalSearch]'))
						$total=$this->Md_siperpus_keperluan_sbppl->countFiltered();
					else $total=$this->Md_siperpus_keperluan_sbppl->countAll();
						$page=$this->input->post('datatable[pagination][page]');
					if($page<1)
						$page=1;

					$perpage=10;
					$pages=$total/$perpage;
					$field=$this->input->post('datatable[sort][field]');

					if($field=='')
						$field=$this->input->post('datatable[pagination][field]');

					$sort=$this->input->post('datatable[sort][sort]');

					if($sort=='')
						$sort=$this->input->post('datatable[pagination][sort]');

					$data = array();
					$no = 0;
					$list=$this->Md_siperpus_keperluan_sbppl->getDatatables();

					foreach ($list as $row) {
						$no++;
						$arr = array();
						$arr['number'] = ($perpage*($page-1))+$no;
						$arr['id'] = $row->id;
						$arr['nama'] = $row->nama;
						$arr['no_urut'] = $row->no_urut;
						$data[] = $arr;
					}
					$meta=array();
					$meta['page']=$page;
					$meta['pages']=$pages;
					$meta['perpage']=$perpage;
					$meta['total']=$total;
					$meta['sort']=$sort;
					$meta['field']=$field;
					$output = array(
									"meta" => $meta,
									"data" => $data
							);
					//output to json format
					echo json_encode($output);

				}else{
					$this->load->view('index', $page_data);
				}
		}
		/** *Proram Studi* **/

		public function program_studi($param1='',$param2='')
		{
			if ($this->session->userdata('login_type') != 'admin')
					$this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');

			$page_data['page_action'] = 'list';
			$page_data['page_title'] = 'Program Studi';
			$page_data['page_access'] = "admin";
			$page_data['page_name'] = 'program_studi';
			$page_data['page_now'] = 'Data Referensi';

			if($param1 =='fetch'){
				if($this->input->post('datatable[query][generalSearch]'))
					$total=$this->Md_vwprodi->countFiltered();
				else $total=$this->Md_vwprodi->countAll();
					$page=$this->input->post('datatable[pagination][page]');
				if($page<1)
					$page=1;

				$perpage=10;
				$pages=$total/$perpage;
				$field=$this->input->post('datatable[sort][field]');

				if($field=='')
					$field=$this->input->post('datatable[pagination][field]');

				$sort=$this->input->post('datatable[sort][sort]');

				if($sort=='')
					$sort=$this->input->post('datatable[pagination][sort]');

				$data = array();
				$no = 0;
				$list=$this->Md_vwprodi->getDatatables();

				foreach ($list as $row) {
					$no++;
					$arr = array();
					$arr['number'] = ($perpage*($page-1))+$no;
					$arr['idmspst'] = $row->idmspst;
					$arr['kodemspst'] = $row->kodemspst;
					$arr['nmmspst'] = $row->nmmspst;
					$data[] = $arr;
				}
				$meta=array();
				$meta['page']=$page;
				$meta['pages']=$pages;
				$meta['perpage']=$perpage;
				$meta['total']=$total;
				$meta['sort']=$sort;
				$meta['field']=$field;
				$output = array(
								"meta" => $meta,
								"data" => $data
						);
				//output to json format
				echo json_encode($output);

			}else{
				$this->load->view('index', $page_data);
			}
		}
		
		/** *Matakuliah* **/

		public function matakuliah($param1='',$param2='')
		{
			if ($this->session->userdata('login_type') != 'admin')
					$this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');

			$page_data['page_action'] = 'list';
			$page_data['page_title'] = 'Data Mata Kuliah';
			$page_data['page_access'] = "admin";
			$page_data['page_name'] = 'matakuliah';
			$page_data['page_now'] = 'Data Referensi';
            $page_data['prodi'] = $this->Md_vwprodi->getProdiAll();
            
			if($param1 =='fetch'){
				if($this->input->post('datatable[query][generalSearch]'))
					$total=$this->Md_siperpus_matakuliah->countFiltered();
				else $total=$this->Md_siperpus_matakuliah->countAll();
					$page=$this->input->post('datatable[pagination][page]');
				if($page<1)
					$page=1;

				$perpage=10;
				$pages=$total/$perpage;
				$field=$this->input->post('datatable[sort][field]');

				if($field=='')
					$field=$this->input->post('datatable[pagination][field]');

				$sort=$this->input->post('datatable[sort][sort]');

				if($sort=='')
					$sort=$this->input->post('datatable[pagination][sort]');

				$data = array();
				$no = 0;
				$list=$this->Md_siperpus_matakuliah->getDatatables();

				foreach ($list as $row) {
					$no++;
					$arr = array();
					$arr['number'] = ($perpage*($page-1))+$no;
					$arr['kodetbkmk'] = $row->kodetbkmk;
					$arr['nmtbkmk'] = $row->nmtbkmk;
					$arr['pengajartbkmk'] = $row->pengajartbkmk;
					$arr['gelarpengajartbkmk'] = $row->gelarpengajartbkmk;
					$arr['nmmspst'] = $row->nmmspst;
					$data[] = $arr;
				}
				$meta=array();
				$meta['page']=$page;
				$meta['pages']=$pages;
				$meta['perpage']=$perpage;
				$meta['total']=$total;
				$meta['sort']=$sort;
				$meta['field']=$field;
				$output = array(
								"meta" => $meta,
								"data" => $data
						);
				//output to json format
				echo json_encode($output);

			}else{
				$this->load->view('index', $page_data);
			}
		}
		
		/**Data Buku**/

		public function data_buku($param1='',$param2='',$param3='',$param4='')
	    {
// 		if ($this->session->userdata('login') != 'A')
// 				$this->logout();

		$date = new DateTime();
		$id=$this->session->userdata('user_id');

		$page_data['page_action'] = 'list';
		$page_data['page_title'] = 'Data Data Buku';
		$page_data['page_access'] = "admin";
		$page_data['page_name'] = 'data_buku';
		$page_data['page_now'] = 'Buku & Inventarisasi';
		$page_data['klasifikasi'] = $this->Md_siperpus_klasifikasi->getKlasifikasiAll();
		$page_data['kategori'] = $this->Md_siperpus_kategori_buku->getKategoriBukuAll();
		$x=str_replace('_','/',$param2);
		$y=str_replace('%20',' ',$param3);

		if ($param1 == 'submit') {
			$data = array('no_klas' => $this->input->post('no_klas'),
										'ISBN' => $this->input->post('isbn'),
										'idkategori' => $this->input->post('kategori_buku'),
										'judul' => $this->input->post('judul'),
										'cetakkatalog_judulpenggal' => $this->input->post('cetakkatalog_judulpenggal'),
										'judulasli' => $this->input->post('judulasli'),
										'allow_review' => $this->input->post('allow_review'),
										'deskripsi' => $this->input->post('deskripsi'),
										'penulis' => $this->input->post('penulis'),
										'penyadur' => $this->input->post('penyadur'),
										'penerjemah' => $this->input->post('penerjemah'),
										'penyusun' => $this->input->post('penyusun'),
										'penyunting' => $this->input->post('penyunting'),
										'illustrator' => $this->input->post('illustrator'),
										'editor' => $this->input->post('editor'),
										'edisi' => $this->input->post('edisi'),
										'cetakan' => $this->input->post('cetakan'),
										'kd_penerbit' => $this->input->post('penerbit'),
										'thn_terbit' => $this->input->post('thn_terbit'),
										'jilid' => $this->input->post('jilid'),
										'hlm_romawi' => $this->input->post('hlm_romawi'),
										'jml_hal' => $this->input->post('jml_hal'),
										'ilustrasi' => $this->input->post('ilustrasi'),
										'tabel' => $this->input->post('tabel'),
										'ukuran_fisik' => $this->input->post('ukuran_fisik'),
										'bibliografi' => $this->input->post('bibliografi'),
										'indeks' => $this->input->post('indeks'),
										'bahasa' => $this->input->post('bahasa'),
										'no_rak' => $this->input->post('no_rak'),
										'seri' => $this->input->post('seri'),
										'tajuk' => $this->input->post('tajuk'),
										'tajuksubyek' => $this->input->post('tajuksubyek'),
										'tanggal' => $date->format('Y-m-d H:i:s'),
										//'matkul' => $this->input->post('matkul')
		 						);
		 	$prodi = $this->input->post('prodi');
			for ($i=0; $i < sizeof($prodi); $i++) {
				$dataBukuProdi = array('no_klas' => $this->input->post('no_klas'),
												'ISBN' => $this->input->post('isbn'),
												'idmspst'=> $prodi[$i]
											);
				$this->Md_siperpus_buku_prodi->addBukuProdi($dataBukuProdi);
			}
			if ($this->input->post('kategori_buku')==3) {
				$data_kti = array('no_klas_ta' => $this->input->post('no_klas'),
													'ISBN_ta' => $this->input->post('isbn'),
													'nis_ta' => $this->input->post('nis_ta'),
													'tabel_ta' => $this->input->post('tabel_ta'),
													'lampiran_ta' => $this->input->post('lampiran_ta'),
													'pembimbing_ta' => $this->input->post('pembimbing_ta'),
										);
				if ($data_kti['tabel_ta']=='') $data_kti['tabel_ta']=0;
				if ($data_kti['lampiran_ta']=='') $data_kti['lampiran_ta']=0;
				$this->Md_siperpus_data_buku->addDataBukuTa($data_kti);
			}
			$config1 = array('upload_path' => FCPATH ."file/images",
										'allowed_types' => 'gif|jpg|png|jpeg|bmp',
										'max_size' => 1024 * 8
			);
			$config2 = array('upload_path' => FCPATH ."file/docs",
						'allowed_types' => 'pdf|doc|docx|xls|xlsx|zip|',
						'max_size' => 1024 * 1000
			);
			if ($data['ilustrasi']=='') $data['ilustrasi']=0;
			if ($data['tabel']=='') $data['tabel']=0;
			if ($data['allow_review']=='') $data['allow_review']=0;
			if($data['no_klas']=='' || $data['jml_hal']==''||$data['kd_penerbit']=='' || $data['ukuran_fisik']==''||$data['penulis']=='' || $data['judul']==''||$data['tajuksubyek']=='' || $data['ISBN']==''|| $data['thn_terbit']=='' ){
	 				//Empty Field
	 		}else{
				$this->Md_siperpus_data_buku->addDataBuku($data);//Upload Data

				// upload image.
				$this->load->library('upload', $config1);
				if (!$this->upload->do_upload('gambar')){
					$file = NULL;
					$data_upload['cover'] = $file;
				}
				else{
					$data_up = $this->upload->data();
					$file ="file/images/".$data['no_klas']."-".$data_up['file_name'];
					$data_upload['cover'] = $file;
				}

				// upload file
				$this->upload->initialize($config2);
	 			if (!$this->upload->do_upload('file')){
					$file = NULL;
					$data_upload['file'] = $file;
				}
				else{
					$data_up = $this->upload->data();
					$file = "file/docs/".$data['no_klas']."-".$data_up['file_name'];
					$data_upload['file'] = $file;
				}

				$data_upload['no_klas'] = $data['no_klas'];
				if($this->Md_siperpus_data_buku->addDataCover($data_upload)){
					$this->session->set_flashdata('alert', 'alert-success');
	 				$this->session->set_flashdata('flash_message', 'Data Buku Sukses Ditambah');
				}
				else{
					@unlink($data_up['full_path']);
					$status = FALSE;
					$msg = "Something went wrong when saving the file, please try again.";
				}
			}
			redirect(base_url() . 'admin/data_buku', 'refresh');
		}
		else if ($param1=='hapus') {
			$this->Md_siperpus_data_buku->hapusDataBuku($x,$y);
			$this->Md_siperpus_inventaris->hapusInventarisAll($x);
			echo json_encode(array("status" => TRUE,"msg" => "Data Buku Sukses Dihapus"));
		}
		else if ($param1=='hapus_inv') {
			$this->Md_siperpus_inventaris->hapusInventaris($param4);
			$row=$this->Md_siperpus_inventaris->getNumRowInvByNoKlas($y);
			$this->Md_siperpus_data_buku->updateJmlBuku($x,$y,$row);
			echo json_encode(array("status" => TRUE,"msg" => "Data Inventaris Sukses Dihapus"));
		}
		else if ($param1=='update') {
			$data = array('no_klas' => $this->input->post('no_klas'),
										'ISBN' => $this->input->post('isbn'),
										'idkategori' => $this->input->post('kategori_buku'),
										'judul' => $this->input->post('judul'),
										'cetakkatalog_judulpenggal' => $this->input->post('cetakkatalog_judulpenggal'),
										'judulasli' => $this->input->post('judulasli'),
										'allow_review' => $this->input->post('allow_review'),
										'deskripsi' => $this->input->post('deskripsi'),
										'penulis' => $this->input->post('penulis'),
										'penyadur' => $this->input->post('penyadur'),
										'penerjemah' => $this->input->post('penerjemah'),
										'penyusun' => $this->input->post('penyusun'),
										'penyunting' => $this->input->post('penyunting'),
										'illustrator' => $this->input->post('illustrator'),
										'editor' => $this->input->post('editor'),
										'edisi' => $this->input->post('edisi'),
										'cetakan' => $this->input->post('cetakan'),
										'kd_penerbit' => $this->input->post('kd_penerbit'),
										'thn_terbit' => $this->input->post('thn_terbit'),
										'jilid' => $this->input->post('jilid'),
										'hlm_romawi' => $this->input->post('hlm_romawi'),
										'jml_hal' => $this->input->post('jml_hal'),
										'ilustrasi' => $this->input->post('ilustrasi'),
										'tabel' => $this->input->post('tabel'),
										'ukuran_fisik' => $this->input->post('ukuran_fisik'),
										'bibliografi' => $this->input->post('bibliografi'),
										'indeks' => $this->input->post('indeks'),
										'bahasa' => $this->input->post('bahasa'),
										'no_rak' => $this->input->post('no_rak'),
										'seri' => $this->input->post('seri'),
										'tajuk' => $this->input->post('tajuk'),
										'tajuksubyek' => $this->input->post('tajuksubyek'),
										'tanggal' => $date->format('Y-m-d H:i:s')
										//'matkul' => $this->input->post('matkul')
		 						);
			if ($this->input->post('kategori_buku')==3) {
				$data_kti = array('no_klas_ta' => $this->input->post('no_klas'),
													'ISBN_ta' => $this->input->post('isbn'),
													'nis_ta' => $this->input->post('nis_ta'),
													'tabel_ta' => $this->input->post('tabel_ta'),
													'lampiran_ta' => $this->input->post('lampiran_ta'),
													'pembimbing_ta' => $this->input->post('pembimbing_ta'),
										);
				if ($data_kti['tabel_ta']=='') $data_kti['tabel_ta']=0;
				if ($data_kti['lampiran_ta']=='') $data_kti['lampiran_ta']=0;
				$this->Md_siperpus_data_buku->updateDataBukuTa($data_kti);
		 }
		 if ($data['ilustrasi']=='') {$data['ilustrasi']=0;}
		 if ($data['tabel']=='') {$data['tabel']=0;}
		 if ($data['allow_review']=='') {$data['allow_review']=0;}
		 if ($data['no_klas']==''||$data['judul']==''|| $data['penulis']==''){
				//Empty Field
		 }else{
			  $this->Md_siperpus_data_buku->updateDataBuku($x, $data);
				echo json_encode(array("status" => TRUE,"msg" => "Data Buku Berhasil Diedit"));
				}
		}
		else if ($param1=='edit') {
			 $page_data['data']=$this->Md_siperpus_data_buku->getDataBukuByISBNdanNo_klas($x,$y);
			 $page_data['data']['kel_buku']=$this->Md_siperpus_kategori_buku->getKategoriBukuAll();
			 $page_data['data']['penerbit']=$this->Md_siperpus_penerbit->getPenerbitAll();
			 $page_data['data']['bahasa']=$this->Md_siperpus_bahasa->getBahasaAll();
			 $page_data['page_action'] = "edit";
			 $page_data['page_title'] = 'Tambah Data Buku';
			 $this->load->view('index', $page_data);
		}
		else if ($param1=='get') {
			 $data = $this->Md_siperpus_data_buku->getDataBukuByISBNdanNo_klas($x,$y);
			 echo json_encode($data);
		}
		else if ($param1=='cek') {
			 $data = $this->Md_siperpus_data_buku->getDataBukuByISBN($x);
			 if ($data) {
			 	echo json_encode(array("status" => TRUE,"msg" => "Data ISBN Sudah Ada"));
			}else {
				echo json_encode(array("status" => false,"msg" => "Data ISBN Dapat Digunakan"));
			}
		}
		else if ($param1=='set_inv') {
			$page_data['data']=$this->Md_siperpus_data_buku->getDataBukuByISBN($x);
			$page_data['data']['asal_buku']=$this->Md_siperpus_asal_buku->getAsalBukuAll();
			$page_data['isbn']=$param2;
			$page_data['no_klas']=$param3;
			$page_data['page_action'] = "set_inv";
			$page_data['page_title'] = 'Inventaris Buku';
			$this->load->view('index', $page_data);
		}
		else if ($param1=='get_inv') {
			$total=$this->Md_siperpus_inventaris->countByISBN($x);
			$page=$this->input->post('datatable[pagination][page]');
			if($page<1)
				$page=1;
			$perpage=10;
			$pages=$total/$perpage;
			$field=$this->input->post('datatable[sort][field]');
			if($field=='')
				$field=$this->input->post('datatable[pagination][field]');
			$sort=$this->input->post('datatable[sort][sort]');
			if($sort=='')
				$sort=$this->input->post('datatable[pagination][sort]');
			$data = array();
			$no = 0;
			$inv=$this->Md_siperpus_inventaris->getInventarisByISBNdanNoKlas($x,$y);
			foreach ($inv as $row) {
				$no++;
				$arr = array();
				$arr['number'] = ($perpage*($page-1))+$no;
				$arr['no_inv'] = $row->no_inv;
				$arr['isbn'] = $row->ISBN;
				$arr['tgl_inv'] = $row->tgl_inv;
				$arr['asal'] = $row->asal;
				$arr['ket'] = $row->ket;
				$arr['no_barcode'] = $row->no_barcode;
				$arr['no_klas'] = $row->no_klas;
				$data[] = $arr;
			}
			$meta=array();
			$meta['page']=$page;
			$meta['pages']=$pages;
			$meta['perpage']=$perpage;
			$meta['total']=$total;
			$meta['sort']=$sort;
			$meta['field']=$field;
			$output = array(
							"meta" => $meta,
							"data" => $data
					);
			//output to json format
			echo json_encode($output);
		}
		else if ($param1=='list') {
			if($this->input->post('datatable[query][generalSearch]'))
				$total=$this->Md_siperpus_data_buku->countFiltered();
			else $total=$this->Md_siperpus_data_buku->countAll();
				$page=$this->input->post('datatable[pagination][page]');
			if($page<1)
				$page=1;

			$perpage=10;
			$pages=$total/$perpage;
			$field=$this->input->post('datatable[sort][field]');

			if($field=='')
				$field=$this->input->post('datatable[pagination][field]');

			$sort=$this->input->post('datatable[sort][sort]');

			if($sort=='')
				$sort=$this->input->post('datatable[pagination][sort]');

			$data = array();
			$no = 0;
			$list=$this->Md_siperpus_data_buku->getDatatables();

			foreach ($list as $row) {
				$no++;
				$arr = array();
				$arr['number'] = ($perpage*($page-1))+$no;
				$arr['id'][0] = $row->no_klas;
				$arr['id'][1] = $row->ISBN;
				$arr['isbn'] = $row->ISBN;
				$arr['no_klas'] = $row->no_klas;
				$arr['no_rak'] = $row->no_rak;
				$arr['judul'] = $row->judul;
				$arr['penulis'] = $row->penulis;
				$arr['penerbit'] = $row->nama_penerbit;
				$arr['jml_buku'] = $row->jml_buku;
				$arr['dipinjam'] = "";//$row->dipinjam;
				$arr['mk'] = "";//$row->mk;
				$arr['prodi'] = "";//$row->prodi;
				$data[] = $arr;
			}
			$meta=array();
			$meta['page']=$page;
			$meta['pages']=$pages;
			$meta['perpage']=$perpage;
			$meta['total']=$total;
			$meta['sort']=$sort;
			$meta['field']=$field;
			$output = array(
							"meta" => $meta,
							"data" => $data
					);
			//output to json format
			echo json_encode($output);

		}
		else if ($param1=='tambah') {
			$page_data['data']['kel_buku']=$this->Md_siperpus_kategori_buku->getKategoriBukuAll();
			 $page_data['data']['penerbit']=$this->Md_siperpus_penerbit->getPenerbitAll();
			 $page_data['data']['bahasa']=$this->Md_siperpus_bahasa->getBahasaAll();
			 $page_data['data']['prodi']=$this->Md_vwprodi->getProdiAll();
			 $page_data['page_action'] = $param1;
			 $page_data['page_title'] = 'Tambah Data Buku';
			$this->load->view('index', $page_data);
		}
		else if ($param1=='tambah_inv') {

			$data = array('no_barcode' => $this->input->post('no_barcode'),
										'no_inv' => $this->input->post('no_inv'),
										'tgl_inv' => $this->input->post('tgl_inv'),
										'asal' => $this->input->post('asal'),
										'ket' => $this->input->post('ket'),
										'no_klas' => str_replace('%20',' ',$this->input->post('no_klas')),
										'isbn' => str_replace('_','/',$this->input->post('isbn')),
										'status' => $this->input->post('status'),
										'tanggal' => $date->format('Y-m-d H:i:s')
							);
			if ($data['ket']=='') $data['ket']='-';
			$this->Md_siperpus_inventaris->addInventaris($data);
			$row=$this->Md_siperpus_inventaris->getNumRowInvByNoKlas($data['no_klas']);
			$this->Md_siperpus_data_buku->updateJmlBuku($data['isbn'],$data['no_klas'],$row);
			echo json_encode(array("status" => TRUE,"msg" => "Data Inventaris Berhasil Ditambah"));
		}
		else if ($param1=='get_barcode') {
			$output['barcode']=$this->Md_siperpus_inventaris->getNoBarcode();
			$output['barcode']++;
			echo json_encode($output);
		}
		else if ($param1=='get_data_inv') {
			$inv=$this->Md_siperpus_inventaris->getInventarisByBarcode($param2);
			echo json_encode($inv);
		}
		else if ($param1=='edit_inv') {
			$data = array('no_barcode' => $this->input->post('no_barcode2'),
										'no_inv' => $this->input->post('no_inv2'),
										'tgl_inv' => $this->input->post('tgl_inv2'),
										'asal' => $this->input->post('asal2'),
										'ket' => $this->input->post('ket2'),
										'no_klas' => str_replace('%20',' ',$this->input->post('no_klas2')),
										'isbn' => str_replace('_','/',$this->input->post('isbn2')),
										'status' => $this->input->post('status2'),
										'tanggal' => $date->format('Y-m-d H:i:s')
							);
			if ($data['ket']=='') $data['ket']=' ';
			$this->Md_siperpus_inventaris->updateInventaris($data);
			echo json_encode(array("status" => TRUE,"msg" => "Data Inventaris Berhasil Diubah"));
			// $inv=$this->Md_siperpus_inventaris->getInventarisByBarcode($param2);
			// echo json_encode($inv);
		}
		else if ($param1=='ubah_rak') {
			$page_data['klasifikasi'] = $this->Md_siperpus_klasifikasi->getKlasifikasiAll();
			$page_data['kategori'] = $this->Md_siperpus_kategori_buku->getKategoriBukuAll();
			$page_data['page_action'] = $param1;
			$page_data['page_title'] = 'Ubah Rak Buku';
			$this->load->view('index', $page_data);
		}
		else if ($param1=='simpan_ubah_rak') {
			$data = $this->input->post('data');//array('data' => , );
			// echo count($data);
			for ($i=0; $i < count($data); $i++) {
				if ($data[$i][1]!='') {
					$this->Md_siperpus_data_buku->updateRakBuku($data[$i][0],$data[$i][1]);
				}
			}
			echo json_encode(array("status" => TRUE,"msg" => "Rak Buku Berhasil Diubah"));
		}
		else if ($param1=='cetak_katalog') {
			$data = array();
			$data_final = $this->input->post('final');
			for ($i=0; $i < sizeof($data_final); $i++) {
				$data[] = $this->Md_siperpus_data_buku->getDataKatalog($data_final[$i][0],$data_final[$i][1]);
			}
			echo json_encode($data);
		}
		else if ($param1=='cetak_callnumber') {
			$data = array();
			$data_final = $this->input->post('final');
			for ($i=0; $i < sizeof($data_final); $i++) {
				$data[] = $this->Md_siperpus_data_buku->getDataCallNumber($data_final[$i]);
			}
			echo json_encode($data);
		}
		else if ($param1=='cetak_barcode') {
			$data = array();
			$data_final = $this->input->post('final');
			for ($i=0; $i < sizeof($data_final); $i++) {
				$data[] = $this->Md_siperpus_data_buku->getBarcode($data_final[$i][0],$data_final[$i][1]);
			}
			echo json_encode($data);
		}
		else{
			$this->load->view('index', $page_data);
		}
	}
	
	/**Inventarisasi**/
function inventaris($param1='',$param2='',$param3='')
	{
// 		if ($this->session->userdata('login') != 'A')
// 				$this->logout();

		$date = new DateTime();
		$id=$this->session->userdata('user_id');
    $page_data['page_action'] = 'list';
    $page_data['page_title'] = 'Inventaris';
		$page_data['page_access'] = "admin";
    $page_data['page_name'] = 'inventaris';
    $page_data['page_now'] = 'Buku & Inventarisasi';
		$page_data['klasifikasi'] = $this->Md_siperpus_klasifikasi->getKlasifikasiAll();
		$page_data['data']['asal_buku']=$this->Md_siperpus_asal_buku->getAsalBukuAll();
		$x=str_replace('_','/',$param2);
		$y=str_replace('%20',' ',$param3);

		if ($param1 == 'list') {
			if($this->input->post('datatable[query][generalSearch]'))
				$total=$this->Md_siperpus_klasifikasi->countFiltered();
			else
				$total=$this->Md_siperpus_klasifikasi->countAll();
			$page=$this->input->post('datatable[pagination][page]');
			if($page<1)
				$page=1;

			$perpage=10;
			$pages=$total/$perpage;
			$field=$this->input->post('datatable[sort][field]');

			if($field=='')
				$field=$this->input->post('datatable[pagination][field]');

			$sort=$this->input->post('datatable[sort][sort]');

			if($sort=='')
				$sort=$this->input->post('datatable[pagination][sort]');

			//mulai fetching data
			$data = array();
			$no = 0;
			$list=$this->Md_siperpus_inventaris->getDatatables();
			$klasifikasi=$this->Md_siperpus_klasifikasi->getKlasifikasiAll();

			foreach ($list as $row) {
				$no++;
				$arr = array();
				$arr['number'] = ($perpage*($page-1))+$no;
				$arr['no_inv'] = $row->no_inv;
				$arr['tgl_inv'] = $row->tgl_inv;
				$arr['no_klas'] = $row->no_klas;
				if ($row->status == 'A') $row->status='Ada';
				$arr['status'] = $row->status;
				$arr['asal'] = $row->asal;
				$arr['ket'] = $row->ket;
				$arr['judul'] = $row->judul;
				$arr['id'] = $row->ISBN;
				$arr['no_barcode'] = $row->no_barcode;
				$data[] = $arr;
			}

			$meta=array();
			$meta['page']=$page;
			$meta['pages']=$pages;
			$meta['perpage']=$perpage;
			$meta['total']=$total;
			$meta['sort']=$sort;
			$meta['field']=$field;
			$output = array(
							"meta" => $meta,
							"data" => $data
					);
			echo json_encode($output);//output to json format
		}
		else if ($param1 == 'update') {
			$data = array('no_inv' => $this->input->post('no_inv'),
										'tgl_inv' => $this->input->post('tgl_inv'),
										'asal' => $this->input->post('asal'),
										'no_barcode' => $this->input->post('no_barcode'),
										'no_klas' => $this->input->post('no_klas_e'),
										'isbn' => $this->input->post('isbn_e'),
										'status' => $this->input->post('status_e'),
										'ket' => $this->input->post('ket_e'),
										'tanggal' => $this->input->post('tanggal_e')
							);
				$this->Md_siperpus_inventaris->updateInventaris($data);
				echo json_encode(array("status" => TRUE,"msg" => "Inventaris Berhasil Diubah"));
    }
		else if ($param1 == 'edit') {
			$data = $this->Md_siperpus_inventaris->getInventarisById($param2);
			echo json_encode($data);
		}
		else if ($param1=='cetak_barcode') {
			$data = array();
			$data_final = $this->input->post('final');
			for ($i=0; $i < sizeof($data_final); $i++) {
				$data[] = $this->Md_siperpus_inventaris->getBarcode($data_final[$i]);
			}
			echo json_encode($data);
		}
		else if ($param1=='cetak_callnumber') {
			$data = array();
			$data_final = $this->input->post('final');
			for ($i=0; $i < sizeof($data_final); $i++) {
				$data[] = $this->Md_siperpus_inventaris->getDataCallNumber($data_final[$i]);
				$x = explode("/",$data[$i][0]['no_inv']);
				$data[$i][0]['no_inv'] = $x[sizeof($x)-1];
				if ($data[$i][0]['no_barcode']==$data_final[$i]) {
					$output[]=$data[$i][0];
				}
			}
			echo json_encode($output);
		}
		else {
			$this->load->view('index', $page_data);
		}
	}
	
	
	/** *buku_prodi* **/
	function buku_prodi($param1='',$param2='',$param3='')
	{
// 		if ($this->session->userdata('login') != 'A')
// 				$this->logout();

		$date = new DateTime();
		$id=$this->session->userdata('user_id');
    $page_data['page_action'] = 'list';
    $page_data['page_title'] = 'Buku Jurusan';
		$page_data['page_access'] = "admin";
    $page_data['page_name'] = 'buku_prodi';
    $page_data['page_now'] = 'Buku & Inventarisasi';
		$page_data['klasifikasi'] = $this->Md_siperpus_klasifikasi->getKlasifikasiAll();
		$page_data['kategori'] = $this->Md_siperpus_kategori_buku->getKategoriBukuAll();
		$page_data['prodi'] = $this->Md_vwprodi->getProdiAll();
		$page_data['data']['asal_buku']=$this->Md_siperpus_asal_buku->getAsalBukuAll();
		$x=str_replace('_','/',$param2);
		$y=str_replace('%20',' ',$param3);

		if ($param1 == 'list') {
			if($this->input->post('datatable[query][generalSearch]'))
				$total=$this->Md_siperpus_klasifikasi->countFiltered();
			else
				$total=$this->Md_siperpus_klasifikasi->countAll();
			$page=$this->input->post('datatable[pagination][page]');
			if($page<1)
				$page=1;

			$perpage=10;
			$pages=$total/$perpage;
			$field=$this->input->post('datatable[sort][field]');

			if($field=='')
				$field=$this->input->post('datatable[pagination][field]');

			$sort=$this->input->post('datatable[sort][sort]');

			if($sort=='')
				$sort=$this->input->post('datatable[pagination][sort]');

			//mulai fetching data
			$data = array();
			$no = 0;
			$list=$this->Md_siperpus_buku_prodi->getDatatables();
			$list = json_decode(json_encode($list), FALSE);

			foreach ($list as $row) {
				$no++;
				$arr = array();
				$arr['number'] = ($perpage*($page-1))+$no;
				$arr['id'][0] = $row->no_klas;
				$arr['id'][1] = $row->ISBN;
				$arr['no_klas'] = $row->no_klas;
				$arr['judul'] = $row->judul;
				$arr['penerbit'] = $row->nama_penerbit.": ".$row->thn_terbit;
				$arr['prodi'] = '<ul>';
				for ($i=0; $i < sizeof($row->prodi); $i++) {
					$arr['prodi'] .= '<li>'.$row->prodi[$i].'</li>';
				}
				$arr['prodi'] .= '</ul>';
				$arr['jml_buku'] = $row->jml_buku;
				$data[] = $arr;
			}

			$meta=array();
			$meta['page']=$page;
			$meta['pages']=$pages;
			$meta['perpage']=$perpage;
			$meta['total']=$total;
			$meta['sort']=$sort;
			$meta['field']=$field;
			$output = array(
							"meta" => $meta,
							"data" => $data
					);
			echo json_encode($output);//output to json format
		}
		else if ($param1 == 'update') {
			$data = array('no_inv' => $this->input->post('no_inv'),
										'tgl_inv' => $this->input->post('tgl_inv'),
										'asal' => $this->input->post('asal'),
										'no_barcode' => $this->input->post('no_barcode'),
										'no_klas' => $this->input->post('no_klas_e'),
										'isbn' => $this->input->post('isbn_e'),
										'status' => $this->input->post('status_e'),
										'ket' => $this->input->post('ket_e'),
										'tanggal' => $this->input->post('tanggal_e')
							);
				$this->Md_siperpus_inventaris->updateInventaris($data);
				echo json_encode(array("status" => TRUE,"msg" => "Inventaris Berhasil Diubah"));
    }
		else if ($param1 == 'edit') {
			$data = $this->Md_siperpus_inventaris->getInventarisById($param2);
			echo json_encode($data);
		}
		else if ($param1=='cetak_barcode') {
			$data = array();
			$data_final = $this->input->post('final');
			for ($i=0; $i < sizeof($data_final); $i++) {
				$data[] = $this->Md_siperpus_inventaris->getBarcode($data_final[$i]);
			}
			echo json_encode($data);
		}
		else if ($param1=='cetak_callnumber') {
			$data = array();
			$data_final = $this->input->post('final');
			for ($i=0; $i < sizeof($data_final); $i++) {
				$data[] = $this->Md_siperpus_inventaris->getDataCallNumber($data_final[$i]);
				$x = explode("/",$data[$i][0]['no_inv']);
				$data[$i][0]['no_inv'] = $x[sizeof($x)-1];
				if ($data[$i][0]['no_barcode']==$data_final[$i]) {
					$output[]=$data[$i][0];
				}
			}
			echo json_encode($output);
		}
		else {
			$this->load->view('index', $page_data);
		}
	}
	
	
	
	/** Hari Libur **/
	function hari_libur($param1='')
	{
		if ($this->session->userdata('login_type') != 'admin')
				$this->logout();

		$date = new DateTime();
		$id=$this->session->userdata('user_id');

      $page_data['page_action'] = 'list';
      //$page_data['data']=$this->Md_siperpus_inventaris->getInventarisAll();
      $page_data['page_title'] = 'Hari Libur';
			$page_data['page_access'] = "admin";
      $page_data['page_name'] = 'hari_libur';
      $page_data['page_now'] = 'Konfigurasi & Transaksi';
			$this->load->view('index',$page_data);
	}
		
	/** Konfigurasi **/
    function konfigurasi_transaksi($param1 = '', $param2 = '', $param3 = '') {

        if ($this->session->userdata('login_type') != 'admin')

            $this->logout();

		$date = new DateTime();

		$id=$this->session->userdata('user_id');

        $page_data['page_action'] = 'list';
        $page_data['data']=$this->Md_siperpus_config_transaksi->getConfigAll('m');
        $page_data['page_title'] = 'Pengaturan Transaksi';
		if ($param1 == 'update') {

			$setting1= $this->input->post('setting1');
			$setting2= $this->input->post('setting2');
			$setting3= $this->input->post('setting3');
			$setting4= $this->input->post('setting4');
			$setting5= $this->input->post('setting5');
			
			if($setting1 !=''){
				$data['jml_buku']=$setting1;
			}
			if($setting2 !=''){
				$data['lama']=$setting2;
			}
			if($setting3 !=''){
				$data['denda']=$setting3;
			}
			if($setting4 !=''){
				$data['perpanjang']=$setting4;
			}
			if($setting5 !=''){
				$data['masa_berlaku']=$setting5;
			}
				$this->Md_siperpus_config_transaksi->updateConfig('m',$data);
			
			
				$this->session->set_flashdata('alert', 'alert-warning');

				$this->session->set_flashdata('flash_message', 'Update Konfigurasi Transaksi Sukses');

				redirect(base_url() . 'admin/konfigurasi_transaksi/', 'refresh');
			
        }if ($param1 == 'forceupdate') {

			$tgl= $this->input->post('tgl');
			
			if($tgl ==''){
				$this->session->set_flashdata('alert', 'alert-warning');

				$this->session->set_flashdata('flash_message', 'Empty Field');

				redirect(base_url() . 'admin/konfigurasi_transaksi/', 'refresh');
			}else{
				$this->Md_siperpus_config_transaksi->updateConfig('m',$data);
				$this->session->set_flashdata('alert', 'alert-warning');
				$this->session->set_flashdata('flash_message', 'Update Konfigurasi Transaksi Sukses');
				redirect(base_url() . 'admin/konfigurasi_transaksi/', 'refresh');
			}
			
        }
        $page_data['page_access'] = "admin";
        $page_data['page_name'] = 'konfigurasi_transaksi';
        $page_data['page_now'] = 'Konfigurasi Transaksi';
        $this->load->view('index', $page_data);

    }
	/** *Group User* **/

    function group_user($param1 = '', $param2 = '', $param3 = '') {

        if ($this->session->userdata('login_type') != 'admin')

            $this->logout();

		$date = new DateTime();

		$id=$this->session->userdata('user_id');

        $page_data['page_action'] = 'list';
         $page_data['page_title'] = 'Daftar Group User';
		$page_data['page_access'] = "admin";
		$page_data['page_name'] = 'group_user';
		$page_data['page_now'] = 'Administrator';
		$page_data['modul']=$this->Md_siperpus_sysmodul->getModulAll();
        if ($param1 == 'submit') {

			$data['idsysgroup'] = $this->input->post('id');
			$data['name'] = $this->input->post('nama');
			$data['def_modul'] = $this->input->post('default');
			
			if( $data['def_modul']=='' || $data['idsysgroup']=='' || $data['name']==''){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-danger');

				$this->session->set_flashdata('flash_message', 'Empty Field');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
			}else{
				$Group=$this->Md_siperpus_sysgroup->getGroupById($this->input->post('id'));
				
				if($Group){
					$this->session->set_flashdata('alert', 'alert-danger');

					$this->session->set_flashdata('flash_message', 'ID telah dipakai,Group User gagal dibuat');
					echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "ID telah dipakai, User Gagal Dibuat"));

				}else{
					$this->Md_siperpus_sysgroup->addGroup($data);
					
					$this->session->set_flashdata('alert', 'alert-focus');

					$this->session->set_flashdata('flash_message', 'Group User Sukses dibuat');
					echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Group User Sukses dibuat"));
					//redirect(base_url() . 'admin/klasifikasi_buku', 'refresh');
				}
			}
        }else if ($param1 == 'update') {

			$id1 = $this->input->post('id1');
			$data['idsysgroup'] = $this->input->post('id');
			$data['name'] = $this->input->post('nama');
			$data['def_modul'] = $this->input->post('default');
			
			if($id1=='' || $data['def_modul']=='' || $data['idsysgroup']=='' || $data['name']==''){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-danger');

				$this->session->set_flashdata('flash_message', 'Empty Field');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
			}else{
				$this->Md_siperpus_sysgroup->updateGroup($id1, $data);
				$this->session->set_flashdata('alert', 'alert-focus');
				$this->session->set_flashdata('flash_message', 'Group User Sukses diedit');
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Group User Sukses diedit"));
			}
			
        }else if($param1 =='edit' && $param2 !=''){
			$data = $this->Md_siperpus_sysgroup->getGroupById($param2);
			echo json_encode($data);

		}else if($param1 =='fetch'){
			if($this->input->post('datatable[query][generalSearch]'))$total=$this->Md_siperpus_sysgroup->countFiltered();
			else $total=$this->Md_siperpus_sysgroup->countAll();
			$page=$this->input->post('datatable[pagination][page]');
			if($page<1)$page=1;
			$perpage=10;
			$pages=$total/$perpage;
			$field=$this->input->post('datatable[sort][field]');
			if($field=='')$field=$this->input->post('datatable[pagination][field]');
			$sort=$this->input->post('datatable[sort][sort]');
			if($sort=='')$sort=$this->input->post('datatable[pagination][sort]');
			$data = array();
			$no = 0;
			$list=$this->Md_siperpus_sysgroup->getDatatables();
			foreach ($list as $row) {
				$no++;
				$arr = array();
				$arr['number'] = ($perpage*($page-1))+$no;
				$arr['id'] = $row->idsysgroup;
				$arr['nama'] = $row->name;
				$modul=$this->Md_siperpus_sysmodul->getModulById($row->def_modul);
				if($modul)$arr['def'] = $modul[0]->name;
				else $arr['def']='';
				
				$data[] = $arr;
			}
			$meta=array();
			$meta['page']=$page;
			$meta['pages']=$pages;
			$meta['perpage']=$perpage;
			$meta['total']=$total;
			$meta['sort']=$sort;
			$meta['field']=$field;
			$output = array(
							"meta" => $meta,
							"data" => $data
					);
			//output to json format
			echo json_encode($output);

		}else{
			$this->load->view('index', $page_data);
		}
    }
	/** *Daftar User* **/
	
    function daftar_user($param1 = '', $param2 = '', $param3 = '') {

        if ($this->session->userdata('login_type') != 'admin')

            $this->logout();

		$date = new DateTime();

		$id=$this->session->userdata('user_id');

        $page_data['page_action'] = 'list';
         $page_data['page_title'] = 'Daftar User Program';
		$page_data['page_access'] = "admin";
		$page_data['page_name'] = 'daftar_user';
		$page_data['page_now'] = 'Administrator';
		$page_data['sysgroup']=$this->Md_siperpus_sysgroup->getGroupAll();
        if ($param1 == 'submit') {

			$data['idsysuser'] = $this->input->post('id');
			$data['name'] = $this->input->post('nama');
			$data['pass'] = $this->input->post('password');
			$confirm = $this->input->post('password2');
			$data['idsysgroup'] = $this->input->post('group');
			$data['active'] = $this->input->post('status');
			if($data['pass']!=$confirm){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-danger');

				$this->session->set_flashdata('flash_message', 'Password Tidak Sama');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Password Tidak Sama"));
			}else if($data['idsysuser']=='' || $data['pass']=='' || $data['name']=='' || $data['idsysgroup']=='' || $data['active']==''){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-danger');

				$this->session->set_flashdata('flash_message', 'Empty Field');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
			}else{
				$user=$this->Md_siperpus_sysuser->getUserById($this->input->post('id'));
				
				if($user){
					$this->session->set_flashdata('alert', 'alert-danger');

					$this->session->set_flashdata('flash_message', 'ID telah dipakai, User gagal dibuat');
					echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "ID telah dipakai, User Gagal Dibuat"));

				}else{
					$this->Md_siperpus_sysuser->addUser($data);
					
					$this->session->set_flashdata('alert', 'alert-focus');

					$this->session->set_flashdata('flash_message', 'User Sukses dibuat');
					echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "User Sukses dibuat"));
					//redirect(base_url() . 'admin/klasifikasi_buku', 'refresh');
				}
			}
        }else if ($param1 == 'update') {

			$id1 = $this->input->post('id1');
			$data['idsysuser'] = $this->input->post('id');
			$data['name'] = $this->input->post('nama');
			$pass = $this->input->post('password');
			$confirm = $this->input->post('password2');
			$data['idsysgroup'] = $this->input->post('group');
			$data['active'] = $this->input->post('status');
			
			if( $pass != $confirm && $confirm != '' ){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-danger');

				$this->session->set_flashdata('flash_message', 'Password Tidak Sama');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Password Tidak Sama"));
			}else if($id1=='' || $data['idsysuser']=='' || $pass=='' || $data['name']=='' || $data['idsysgroup']=='' || $data['active']==''){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-danger');

				$this->session->set_flashdata('flash_message', 'Empty Field');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
			}else{
				
				//$data['pass'] = $pass;
			
				$this->Md_siperpus_sysuser->updateUser($id1, $data);

				$this->session->set_flashdata('alert', 'alert-focus');

				$this->session->set_flashdata('flash_message', 'User Sukses diedit');
				//redirect(base_url() . 'admin/klasifikasi_buku', 'refresh');
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "User Sukses diedit"));
			}
			
        }else if ($param1=='hapus' && $param2 !='') {
				$this->Md_siperpus_sysuser->hapusUser($param2);
				$this->session->set_flashdata('alert', 'alert-focus');
				$this->session->set_flashdata('flash_message', 'User Sukses Dihapus');
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "User Sukses Dihapus"));
		}else if($param1 =='pass' && $param2 !=''){
			$data = $this->Md_siperpus_sysuser->getUserById($param2);
			echo json_encode(array("status" => TRUE,"pass" => $data[0]->pass));

		}else if($param1 =='edit' && $param2 !=''){
			$data = $this->Md_siperpus_sysuser->getUserById($param2);
			echo json_encode($data);

		}else if($param1 =='fetch'){
			if($this->input->post('datatable[query][generalSearch]') || $this->input->post('datatable[query][group]')||$this->input->post('datatable[query][status]')||$this->input->post('datatable[query][status]')=='0')$total=$this->Md_siperpus_sysuser->countFiltered();
			else $total=$this->Md_siperpus_sysuser->countAll();
			$page=$this->input->post('datatable[pagination][page]');
			if($page<1)$page=1;
			$perpage=10;
			$pages=$total/$perpage;
			$field=$this->input->post('datatable[sort][field]');
			if($field=='')$field=$this->input->post('datatable[pagination][field]');
			$sort=$this->input->post('datatable[sort][sort]');
			if($sort=='')$sort=$this->input->post('datatable[pagination][sort]');
			$data = array();
			$no = 0;
			$list=$this->Md_siperpus_sysuser->getDatatables();
			foreach ($list as $row) {
				$no++;
				$arr = array();
				$arr['number'] = ($perpage*($page-1))+$no;
				$arr['id'] = $row->idsysuser;
				$arr['nama'] = $row->name;
				$arr['pass'] = "******";
				$arr['group'] = $row->idsysgroup;
				if($row->active ==1)$arr['active'] = "Aktif";
				else $arr['active'] = "Non-Aktif";
				
				$data[] = $arr;
			}
			$meta=array();
			$meta['page']=$page;
			$meta['pages']=$pages;
			$meta['perpage']=$perpage;
			$meta['total']=$total;
			$meta['sort']=$sort;
			$meta['field']=$field;
			$output = array(
							"meta" => $meta,
							"data" => $data
					);
			//output to json format
			echo json_encode($output);

		}else{
			$this->load->view('index', $page_data);
		}
    }
	/** *User Grant* **/
	
    function user_grant($param1 = '', $param2 = '', $param3 = '') {

        if ($this->session->userdata('login_type') != 'admin')

            $this->logout();

		$date = new DateTime();

		$id=$this->session->userdata('user_id');

        $page_data['page_action'] = 'list';
         $page_data['page_title'] = 'Daftar Hak Akses User';
		$page_data['page_access'] = "admin";
		$page_data['page_name'] = 'user_grant';
		$page_data['page_now'] = 'Administrator';
		$page_data['group']=$this->Md_siperpus_sysgroup->getGroupAll();
        $page_data['modulall']=$this->Md_siperpus_sysmodul->getModulAll();
		$page_data['modul']=$this->Md_siperpus_sysmodul->getModulNoAkses('A');
		if ($param1 == 'submit') {

			$id=$this->Md_siperpus_sysgrant->getLastId();
			$data['idsysgrant'] = $id+1;
			$data['idsysmodul'] = $this->input->post('modul');
			$data['idsysgroup'] = $this->input->post('group');
			if($this->input->post('add') && $this->input->post('add')==1)$data['allow_add'] = 1;
			else $data['allow_add'] = 0;
			if($this->input->post('edit') && $this->input->post('edit')==1)$data['allow_edit'] = 1;
			else $data['allow_edit'] = 0;
			if($this->input->post('delete') && $this->input->post('delete')==1)$data['allow_delete'] = 1;
			else $data['allow_delete'] = 0;
			if($this->input->post('view') && $this->input->post('view')==1)$data['allow_view'] = 1;
			else $data['allow_view'] = 0;
			if($this->input->post('print') && $this->input->post('print')==1)$data['allow_print'] = 1;
			else $data['allow_print'] = 0;
			if($data['idsysmodul']=='' || $data['idsysgroup']==''){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-danger');

				$this->session->set_flashdata('flash_message', 'Empty Field');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
			}else{
				$user=$this->Md_siperpus_sysgrant->getGrantByModul($data['idsysmodul'],$data['idsysgroup']);
				
				if($user){
					$this->session->set_flashdata('alert', 'alert-danger');

					$this->session->set_flashdata('flash_message', 'ID telah dipakai,Grant User gagal dibuat');
					echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Akses Modul Telah Di tambahakan Sebelumnya"));

				}else{
					$this->Md_siperpus_sysgrant->addGrant($data);
					
					$this->session->set_flashdata('alert', 'alert-focus');

					$this->session->set_flashdata('flash_message', 'Grant User Sukses dibuat');
					echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Grant User Sukses dibuat"));
					//redirect(base_url() . 'admin/klasifikasi_buku', 'refresh');
				}
			}
        }else if ($param1 == 'update') {

			$id1 = $this->input->post('id1');
			$data['idsysmodul'] = $this->input->post('modul');
			$data['idsysgroup'] = $this->input->post('group');
			if($this->input->post('add')==1)$data['allow_add'] = 1;
			else $data['allow_add'] = 0;
			if($this->input->post('edit')==1)$data['allow_edit'] = 1;
			else $data['allow_edit'] = 0;
			if($this->input->post('delete')==1)$data['allow_delete'] = 1;
			else $data['allow_delete'] = 0;
			if($this->input->post('view')==1)$data['allow_view'] = 1;
			else $data['allow_view'] = 0;
			if($this->input->post('print')==1)$data['allow_print'] = 1;
			else $data['allow_print'] = 0;
			if($id1=='' || $data['idsysmodul']=='' || $data['idsysgroup']==''){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-danger');

				$this->session->set_flashdata('flash_message', 'Password Tidak Sama');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Password Tidak Sama"));
			}else{
				
				//$data['pass'] = $pass;
			
				$this->Md_siperpus_sysgrant->updateGrant($id1, $data);

				$this->session->set_flashdata('alert', 'alert-focus');

				$this->session->set_flashdata('flash_message', 'Hak Akses Sukses diedit');
				//redirect(base_url() . 'admin/klasifikasi_buku', 'refresh');
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Hak Akses Sukses diedit"));
			}
			
        }else if ($param1=='hapus' && $param2 !='') {
				$this->Md_siperpus_sysgrant->hapusGrant($param2);
				$this->session->set_flashdata('alert', 'alert-focus');
				$this->session->set_flashdata('flash_message', 'Hak Akses Sukses Dihapus');
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Hak Akses Sukses Dihapus"));
		}else if($param1 =='edit' && $param2 !=''){
			$data = $this->Md_siperpus_sysgrant->getGrantById($param2);
			echo json_encode($data);

		}else if($param1 =='modul'){
			$g=$this->input->post('g');
			$modul=$this->Md_siperpus_sysmodul->getModulNoAkses($g);
			if($g!=''){
			echo json_encode($modul);
			}else{
			$modul=$this->Md_siperpus_sysmodul->getModulAll();
			echo json_encode($modul);
			}
		
		}else if($param1 =='fetch'){
			$total=$this->Md_siperpus_sysgrant->countFiltered();
			$page=$this->input->post('datatable[pagination][page]');
			if($page<1)$page=1;
			$perpage=10;
			$pages=$total/$perpage;
			$field=$this->input->post('datatable[sort][field]');
			if($field=='')$field=$this->input->post('datatable[pagination][field]');
			$sort=$this->input->post('datatable[sort][sort]');
			if($sort=='')$sort=$this->input->post('datatable[pagination][sort]');
			$data = array();
			$no = 0;
			$list=$this->Md_siperpus_sysgrant->getDatatables();
			foreach ($list as $row) {
				$no++;
				$arr = array();
				$arr['number'] = ($perpage*($page-1))+$no;
				$arr['id'] = $row->idsysgrant;
				$modul=$this->Md_siperpus_sysmodul->getModulById($row->idsysmodul);
				if($modul)$arr['nama'] = $modul[0]->name;
				$arr['add'] = $row->allow_add;
				$arr['edit'] = $row->allow_edit;
				$arr['delete'] = $row->allow_delete;
				$arr['view'] = $row->allow_view;
				$arr['print'] = $row->allow_print;
				
				$data[] = $arr;
			}
			$meta=array();
			$meta['page']=$page;
			$meta['pages']=$pages;
			$meta['perpage']=$perpage;
			$meta['total']=$total;
			$meta['sort']=$sort;
			$meta['field']=$field;
			$output = array(
							"meta" => $meta,
							"data" => $data
					);
			//output to json format
			echo json_encode($output);

		}else{
			$this->load->view('index', $page_data);
		}
    }
    /** *Hilang* **/
	
    function hilang($param1 = '', $param2 = '', $param3 = '') {

        if ($this->session->userdata('login_type') != 'admin')

            $this->logout();

		$date = new DateTime();

		$id=$this->session->userdata('user_id');

        $page_data['page_action'] = 'list';
         $page_data['page_title'] = 'Status Buku (Hilang, Rusak, Diarsipkan, Dilelang)';
		$page_data['page_access'] = "admin";
		$page_data['page_name'] = 'hilang';
		$page_data['page_now'] = 'Transaksi';
		$page_data['klasifikasi']=$this->Md_siperpus_klasifikasi->getKlasifikasiAll();
        $page_data['kategori']=$this->Md_siperpus_kategori_buku->getKategoriBukuAll();
        $page_data['inventaris']=$this->Md_siperpus_inventaris->getInventarisAll();
        if ($param1 == 'submit') {
			$inven=$this->input->post('inventaris');
			$id=$this->Md_siperpus_hilangrusak->getLastId();
			$data['tgl_hr'] = $this->input->post('tanggal');
			$data['ket'] = $this->input->post('ket');
			if($this->input->post('anggota'))$data['no_anggota'] = $this->input->post('anggota');
			if($this->input->post('biaya'))$data['biaya_ganti'] = $this->input->post('biaya');
			
			if(!$inven || $data['tgl_hr']=='' || $data['ket']==''){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-danger');

				$this->session->set_flashdata('flash_message', 'Empty Field');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
			}else{
				$insert=0;
				$failed=0;
				foreach($inven as $inv){
					//pengecekan no inventory
					$data['no_inv'] = $inv;
					if($this->Md_siperpus_hilangrusak->addHilang($data))$insert++;
				}
				
				if($insert==0){
					$this->session->set_flashdata('alert', 'alert-danger');

					$this->session->set_flashdata('flash_message', 'Gagal Melakukan Penambahan Buku Hilang');
					echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Gagal Melakukan Penambahan Buku Hilang"));

				}else{
					$this->session->set_flashdata('alert', 'alert-focus');

					$this->session->set_flashdata('flash_message', 'Sukses Melakukan Penambahan Buku Hilang');
					echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Sukses Melakukan Penambahan Buku Hilang"));
					//redirect(base_url() . 'admin/klasifikasi_buku', 'refresh');
				}
			}
        }else if ($param1 == 'update') {

			$id1 = $this->input->post('id1');
			$data['tgl_hr'] = $this->input->post('tanggal');
			$data['no_inv'] = $this->input->post('inventaris');
			$data['ket'] = $this->input->post('ket');
			if($this->input->post('anggota'))$data['no_anggota'] = $this->input->post('anggota');
			if($this->input->post('biaya'))$data['biaya_ganti'] = $this->input->post('biaya');
			if($id1=='' || $data['no_inv']=='' || $data['tgl_hr']=='' || $data['ket']==''){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-danger');

				$this->session->set_flashdata('flash_message', 'Empty Field');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
			}else{
				
				//$data['pass'] = $pass;
			
				$this->Md_siperpus_hilangrusak->updateHilang($id1, $data);

				$this->session->set_flashdata('alert', 'alert-focus');

				$this->session->set_flashdata('flash_message', 'Transaksi Sukses diedit');
				//redirect(base_url() . 'admin/klasifikasi_buku', 'refresh');
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Transaksi Sukses diedit"));
			}
			
        }else if ($param1=='kembali' && $param2 !='') {
				$data['ket'] = 'K';
				$this->Md_siperpus_hilangrusak->updateHilang($param2, $data);
				$this->session->set_flashdata('alert', 'alert-focus');
				$this->session->set_flashdata('flash_message', 'Transaksi Sukses DiUpdate');
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Transaksi Sukses DiUpdate"));
		}else if ($param1=='hapus' && $param2 !='') {
				$this->Md_siperpus_hilangrusak->hapusHilang($param2);
				$this->session->set_flashdata('alert', 'alert-focus');
				$this->session->set_flashdata('flash_message', 'Transaksi Sukses Dihapus');
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Transaksi Sukses Dihapus"));
		}else if($param1 =='edit' && $param2 !=''){
			$data = $this->Md_siperpus_hilangrusak->getHilangById($param2);
			echo json_encode($data);

		}else if($param1 =='fetch'){
			$total=$this->Md_siperpus_hilangrusak->countFiltered();
			$page=$this->input->post('datatable[pagination][page]');
			if($page<1)$page=1;
			$perpage=10;
			$pages=$total/$perpage;
			$field=$this->input->post('datatable[sort][field]');
			if($field=='')$field=$this->input->post('datatable[pagination][field]');
			$sort=$this->input->post('datatable[sort][sort]');
			if($sort=='')$sort=$this->input->post('datatable[pagination][sort]');
			$data = array();
			$no = 0;
			$list=$this->Md_siperpus_hilangrusak->getDatatables();
			foreach ($list as $row) {
				$no++;
				$arr = array();
				$arr['number'] = ($perpage*($page-1))+$no;
				$arr['kd'] = $row->kd_hr;
				$buku=$this->Md_siperpus_buku->getBukuById($row->no_inv);
				if($buku)$arr['buku'] = $buku[0]->judul;
				$arr['tgl'] = $row->tgl_hr;
				$arr['anggota'] = $row->no_anggota;
				$arr['biaya'] = $row->biaya_ganti;
				$arr['keterangan'] = $row->ket;
				
				$data[] = $arr;
			}
			$meta=array();
			$meta['page']=$page;
			$meta['pages']=$pages;
			$meta['perpage']=$perpage;
			$meta['total']=$total;
			$meta['sort']=$sort;
			$meta['field']=$field;
			$output = array(
							"meta" => $meta,
							"data" => $data
					);
			//output to json format
			echo json_encode($output);

		}else{
			$this->load->view('index', $page_data);
		}
    }
	/** *Presensi* **/
	
    function presensi($param1 = '', $param2 = '', $param3 = '') {

        if ($this->session->userdata('login_type') != 'admin')

            $this->logout();

		$date = new DateTime();

		$id=$this->session->userdata('user_id');

        $page_data['page_action'] = 'list';
         $page_data['page_title'] = 'FORM KEHADIRAN DI PERPUSTAKAAN';
		$page_data['page_access'] = "admin";
		$page_data['page_name'] = 'presensi';
		$page_data['page_now'] = 'Transaksi';
        if ($param1 == 'submit') {
			
			$exist=false;
			$nomor=$this->input->post('nomor');
			if($this->Md_vwdosen->getDosenById($nomor))$exist=true;
			if(!$exist)if($this->Md_vwsiswa->getSiswaById($nomor))$exist=true;
			$data['tanggal'] = date("Y-m-d H:i:s");
			
			if(!$exist || $nomor ==''){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-danger');

				$this->session->set_flashdata('flash_message', 'Nomor Tidak ditemukan');
				//echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Nomor Tidak ditemukan"));
				redirect(base_url() . 'admin/presensi/', 'refresh');
			}else{
				$data['nis'] = $nomor;
				//$this->Md_siperpus_presensi->addPresensi($data);
				$this->session->set_flashdata('alert', 'alert-focus');
				$this->session->set_flashdata('flash_message', 'Sukses Menambah Buku Tamu'.$exist);
				redirect(base_url() . 'admin/presensi/', 'refresh');
				//echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Sukses Menambah Buku Tamu"));
			}
        }else if ($param1 == 'submitnon') {
			
			$exist=false;
			$nama=$this->input->post('nama');
			$asal=$this->input->post('asal');
			$data['tanggal'] = date("Y-m-d H:i:s");
			$data['nama'] = $this->input->post('nama');
			$data['asal'] = $this->input->post('asal');
			
			if( $data['nama']=='' || $data['asal']=='' ){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-danger');

				$this->session->set_flashdata('flash_message', 'Empty Field');
				redirect(base_url() . 'admin/presensi/', 'refresh');
				//echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
			}else{
				$this->Md_siperpus_presensi->addPresensiNon($data);
				$this->session->set_flashdata('alert', 'alert-focus');

				$this->session->set_flashdata('flash_message', 'Sukses Menambah Buku Tamu');
				redirect(base_url() . 'admin/presensi/', 'refresh');
				//echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Sukses Menambah Buku Tamu"));
			}
        }else if($param1 =='detail' && $param2 !=''){
			$data = $this->Md_siperpus_presensi->getDetailByTanggal($param2);
			$presensi=array();	
			foreach($data as $row){
			$arr = array();
			$arr['tgl'] = $row->tgl;
			$arr['jam'] = $row->jam;
			$jenis=$row->jenis;
			if($jenis=='nonanggota'){
			$arr['nomor'] = '';
			$arr['nama'] = $row->nomor;
			}else{
				$arr['nomor'] = $row->nomor;
				$mhs=$this->Md_vwsiswa->getSiswaById($row->nomor);
				if($mhs){
					$arr['nama']=$mhs[0]->nama;
				}else{
					$dosen=$this->Md_vwdosen->getDosenById($row->nomor);
					if($dosen)$arr['nama']=$dosen[0]->nama;
					else $arr['nama']='-';
				}
			}
			$presensi[] = $arr;
			}
			$size=count($presensi);
			echo json_encode(array("status" => TRUE,"tanggal" => $param2,"table" => $presensi,"size" => $size));
		}else if($param1 =='fetch'){
			$data = array();
			$no = 0;
			$list=$this->Md_siperpus_presensi->getPresensi7Hari();
			foreach ($list as $row) {
				$no++;
				$arr = array();
				$arr['number'] = $no;
				$arr['tanggal'] = substr($row->tanggal,0,10);
				$arr['jumlah'] =$this->Md_siperpus_presensi->getJumlah(substr($row->tanggal,0,10));
				
				$data[] = $arr;
			}
			$output = array(
							"data" => $data
					);
			//output to json format
			echo json_encode($output);

		}else{
			$this->load->view('index', $page_data);
		}
    }
	/** *Transaksi* **/
	
    function transaksi($param1 = '', $param2 = '', $param3 = '') {

        if ($this->session->userdata('login_type') != 'admin')

            $this->logout();

		$date = new DateTime();

		$id=$this->session->userdata('user_id');

        $page_data['page_action'] = 'list';
        $page_data['page_title'] = 'Transaksi Buku';
		$page_data['page_access'] = "admin";
		$page_data['page_name'] = 'transaksi';
		$page_data['page_now'] = 'Transaksi';
		$page_data['search'] = false;
        if ($param1 == 'submit') {
			$date = date('Y-m-d', strtotime('+5 days'));
			$insert=0;
			$inv=$this->input->post('inventaris');
			$dtinv=$this->Md_siperpus_inventaris->getInventarisById($inv);
			if(strlen($this->input->post('tanggalpinjam'))==10)$data['tgl_pinjam']=$this->input->post('tanggalpinjam');
			else $data['tgl_pinjam']= date("Y-m-d");
			if(strlen($this->input->post('tanggalkembali'))==10)$data['batas']=$this->input->post('tanggalkembali');
			else $data['batas']=$date;
			$id1=$this->input->post('id1');
			$data['no_anggota']=$id1;
			$data['denda']=0;//inv540/2012/3 
			//P031615301003
			$data['kembali']=0;
			$isPinjam=$this->Md_siperpus_transaksi->isPinjam($inv);
			if(count($dtinv)==0){
				$this->session->set_flashdata('alert', 'alert-danger');
					$this->session->set_flashdata('flash_message', 'Buku Tidak Tercatat');
					redirect(base_url() . 'admin/transaksi/search/'.$id1, 'refresh');
			}else if($isPinjam){
				$this->session->set_flashdata('alert', 'alert-danger');
					$this->session->set_flashdata('flash_message', 'Buku Sedang Dipinjam');
					redirect(base_url() . 'admin/transaksi/search/'.$id1, 'refresh');
			}else if($id1=='' || $data['tgl_pinjam']=='' || $data['batas']==''){
				
				$this->session->set_flashdata('alert', 'alert-danger');
					$this->session->set_flashdata('flash_message', 'Empty Field');
					redirect(base_url() . 'admin/transaksi/search/'.$id1, 'refresh');
			}else{
				//pengecekan no inventory
				$data['tid']=$this->Md_siperpus_transaksi->getLastId()+1;
				$data['no_inv'] = $inv;
				$pinjam_ke=$this->Md_siperpus_transaksi->getPinjamKe($id1,$inv)+1;
				$data['pinjam_ke']=$pinjam_ke;
				if($this->Md_siperpus_transaksi->addTransaksi($data))$insert++;
			
				if($insert>0){
					$this->session->set_flashdata('alert', 'alert-focus');
					$this->session->set_flashdata('flash_message', 'Sukses Menambah Peminjaman Buku');
					redirect(base_url() . 'admin/transaksi/search/'.$id1, 'refresh');
				}else{
					$this->session->set_flashdata('alert', 'alert-danger');
					$this->session->set_flashdata('flash_message', 'Gagal Menambah Transaksi');
					redirect(base_url() . 'admin/transaksi/search/'.$id1, 'refresh');
				}
			}
        }else if($param1 =='search' && $param2 !=''){
			$error=false;
			$search=$param2;
			$arr = array();
			$arr['nomor']=$search;//nama,kelas,alamat,telepon
			$arr['nama']='-';
			$arr['kelas']='-';
			$arr['alamat']='-';
			$arr['telepon']='-';
			$mhs=$this->Md_vwsiswa->getSiswaById($search);
			if($mhs){
					$arr['nama']=$mhs[0]->nama;
					$arr['kelas']=$mhs[0]->kelas;
					$arr['alamat']=$mhs[0]->alamat;
					$arr['telepon']=$mhs[0]->telepon;
			}else{
					$dosen=$this->Md_vwdosen->getDosenById($search);
					if($dosen){
						$arr['nama']=$dosen[0]->nama;
						$arr['kelas']=$dosen[0]->kelas;
						$karyawan=$this->Md_vwkaryawan->getKaryawanById($search);
						if($karyawan){
							$arr['alamat']=$karyawan[0]->alamat;
							$arr['telepon']=$karyawan[0]->telepon;
						}
					}else {
						$error=true;
					}
			}
			if($error){
				$this->session->set_flashdata('alert', 'alert-danger');
				$this->session->set_flashdata('flash_message', 'No Anggota Tidak Ditemukan');
				redirect(base_url() . 'admin/transaksi', 'refresh');
			}else{
				$page_data['page_action'] = 'detail';
				$page_data['search'] = $arr;
				$this->load->view('index', $page_data);
			}
		}else if($param1 =='search'){
			$error=false;
			$search=$this->input->post('search');
			$arr = array();
			$arr['nomor']=$search;//nama,kelas,alamat,telepon
			$arr['nama']='-';
			$arr['kelas']='-';
			$arr['alamat']='-';
			$arr['telepon']='-';
			$mhs=$this->Md_vwsiswa->getSiswaById($search);
			if(!$mhs){
				$dosen=$this->Md_vwdosen->getDosenById($search);
				if(!$dosen)$error=true;
			}
			if($error){
				$this->session->set_flashdata('alert', 'alert-danger');
				$this->session->set_flashdata('flash_message', 'No Anggota Tidak Ditemukan');
				redirect(base_url() . 'admin/transaksi', 'refresh');
			}else{
				redirect(base_url() . 'admin/transaksi/search/'.$search, 'refresh');
			}
			
		}else if ($param1=='hilang') {
				//insert ke table hilangrusak
				$idh = $this->input->post('idh');
				$tran=$this->Md_siperpus_transaksi->getTransaksiById($idh);
				if(count($tran)>0){
					$data['tgl_hr'] = date("Y-m-d");
					$data['ket'] = 'H';
					$data['no_anggota'] = $tran[0]->no_anggota;
					$data['biaya_ganti'] =$this->input->post('hilang');
					$data['no_inv'] = $tran[0]->no_inv;
					$this->Md_siperpus_hilangrusak->addHilang($data);
				
				$datatran['denda'] = $this->input->post('hilang');
				$this->Md_siperpus_transaksi->updateTransaksi($idh, $datatran);
				
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Transaksi yang hilang Sukses DiUpdate"));
				}else{
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Transaksi Tidak ditemukan"));
				}
		}else if ($param1=='perpanjang') {
				$idp = $this->input->post('idp');
				if($idp){
				$data['batas'] = $this->input->post('tanggalperpanjang');
				$this->Md_siperpus_transaksi->updateTransaksi($idp, $data);
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Perpajangan Transaksi ke "+$data['batas']+" Sukses DiUpdate"));
				}else{
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
				}
		}else if ($param1=='kembali') {
				$idk = $this->input->post('idk');
				if($idk){
				$data['denda'] = $this->input->post('denda');
				$data['tgl_kembali'] = date("Y-m-d");
				$data['kembali'] = 1;
				$this->Md_siperpus_transaksi->updateTransaksi($idk, $data);
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Transaksi Sukses DiUpdate"));
				}else{
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
				}
		}else if ($param1=='hapus' && $param2 !='') {
				$this->Md_siperpus_transaksi->hapusTransaksi($param2);
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Transaksi Sukses Dihapus"));
		}else if($param1 =='detail' && $param2 !=''){
			$tran = $this->Md_siperpus_transaksi->getTransaksiById($param2);
			$arr = array();
		  if(count($tran)>0){
			$data = $this->Md_siperpus_inventaris->getInventarisById($tran[0]->no_inv);
			 $arr['status']=TRUE;
		   $arr['referensi']='';
		   $arr['klas']=$data[0]->no_klas;
		   $arr['tanggal']=$data[0]->tgl_inv;
		   $arr['isbn']=$data[0]->ISBN;
		   
		    
		   $buku=$this->Md_siperpus_buku->getBukuByISBN($data[0]->ISBN,$data[0]->no_klas);
		   if($buku[0]->bahasa =='I')$arr['bahasa']='Indonesia';
		   else if($buku[0]->bahasa =='A')$arr['bahasa']='Asing';
		   else $arr['bahasa']='';
		   $arr['judul']=$buku[0]->judul;
		   $arr['tajuk']=$buku[0]->tajuksubyek;
		   $arr['penulis']=$buku[0]->penulis;
		   $arr['edisi']=$buku[0]->edisi;
		   $arr['cetakan']=$buku[0]->cetakan;
		   $arr['tahun']=$buku[0]->thn_terbit;
		   $arr['jumlah']=$buku[0]->jml_hal;
		   $arr['ukuran']=$buku[0]->ukuran_fisik;
		   $arr['rak']=$buku[0]->no_rak;
		   $arr['review']=$buku[0]->review;
		   $arr['deskripsi']=$buku[0]->deskripsi;
		  
		  $penerbit=$this->Md_siperpus_penerbit->getPenerbitById($buku[0]->kd_penerbit);
		   $arr['penerbit']=$penerbit[0]->nama_penerbit;
		   $arr['kota']=$penerbit[0]->kota;
		  
		   $stok=$this->Md_siperpus_inventaris->getInventarisByISBN($data[0]->ISBN,$data[0]->no_klas);
		   $arr['stok']=count($stok);
		   
		   $pinjam=$this->Md_siperpus_transaksi->getTransaksiDipinjamByISBN($data[0]->ISBN,$data[0]->no_klas);
		   $arr['pinjam']=count($pinjam);
		   }else{
			$arr['status']=FALSE;
			}
			echo json_encode($arr);

		}else if($param1 =='fetch' && $param2 !=''){
			$total=$this->Md_siperpus_transaksi->countFiltered($param2);
			$page=$this->input->post('datatable[pagination][page]');
			if($page<1)$page=1;
			$perpage=10;
			$pages=$total/$perpage;
			$field=$this->input->post('datatable[sort][field]');
			if($field=='')$field=$this->input->post('datatable[pagination][field]');
			$sort=$this->input->post('datatable[sort][sort]');
			if($sort=='')$sort=$this->input->post('datatable[pagination][sort]');
			$data = array();
			$no = 0;
			$list=$this->Md_siperpus_transaksi->getDatatables($param2);
			foreach ($list as $row) {
				$no++;
				$arr = array();
				$arr['number'] = ($perpage*($page-1))+$no;
				$arr['id'] = $row->tid;
				$arr['noinv'] = $row->no_inv;
				$buku=$this->Md_siperpus_buku->getBukuById($row->no_inv);
				if($buku)$arr['buku'] = $buku[0]->judul;
				$arr['tgl'] = $row->tgl_pinjam;
				$arr['batas'] = $row->batas;
				$arr['terlambat'] = '-';
				if($row->tgl_kembali !='0000-00-00'){
				$date1 = new DateTime($row->batas);
				$date2 = new DateTime($row->tgl_kembali);
					if($date2>$date1){
						$interval = $date1->diff($date2);
						$arr['terlambat'] = $interval->days.' Hari';
					}
				}
				$arr['denda'] = $row->denda;
				$arr['pinjam'] = $row->pinjam_ke;
				
				$data[] = $arr;
			}
			$meta=array();
			$meta['page']=$page;
			$meta['pages']=$pages;
			$meta['perpage']=$perpage;
			$meta['total']=$total;
			$meta['sort']=$sort;
			$meta['field']=$field;
			$output = array(
							"meta" => $meta,
							"data" => $data
					);
			//output to json format
			echo json_encode($output);


		}else{
			$this->load->view('index', $page_data);
		}
    }
	/** *Pengembalian* **/
	
    function traninv($param1 = '', $param2 = '', $param3 = '') {

        if ($this->session->userdata('login_type') != 'admin')

            $this->logout();

		$date = new DateTime();

		$id=$this->session->userdata('user_id');

        $page_data['page_action'] = 'list';
        $page_data['page_title'] = 'Kembalikan Buku Tanpa Kartu Anggota';
		$page_data['page_access'] = "admin";
		$page_data['page_name'] = 'traninv';
		$page_data['page_now'] = 'Transaksi';
		$page_data['search'] = false;
        if($param1 =='search'){
			$error=false;
			$search=$this->input->post('search');
			$inv=$this->Md_siperpus_inventaris->getInventarisById($search);
			if(count($inv)>0){
				$isPinjam=$this->Md_siperpus_transaksi->isPinjam($search);
				if($isPinjam){
					$tran=$this->Md_siperpus_transaksi->getTransaksiTanpaKartu($search);
					$noanggota=$tran[0]->no_anggota;
					$mhs=$this->Md_vwsiswa->getSiswaById($noanggota);
					if(!$mhs){
						$dosen=$this->Md_vwdosen->getDosenById($noanggota);
						if(!$dosen)$error=true;
					}
					if($error){
						$this->session->set_flashdata('alert', 'alert-danger');
						$this->session->set_flashdata('flash_message', 'No. Inventaris '.$search.' ditemukan<br> tetapi peminjam mungkin sudah terhapus keanggotaannya');
						redirect(base_url() . 'admin/traninv', 'refresh');
					}else{
						$this->session->set_flashdata('alert', 'alert-focus');
						$this->session->set_flashdata('flash_message', 'No. Inventaris '.$search.' ditemukan');
						redirect(base_url() . 'admin/transaksi/search/'.$noanggota, 'refresh');
					}
				}else{
					$this->session->set_flashdata('alert', 'alert-danger');
					$this->session->set_flashdata('flash_message', 'No. Inventaris '.$search.' tidak ditemukan.<br> Belum Dipinjam Atau sudah dikembalikan');
					redirect(base_url() . 'admin/traninv', 'refresh');
				}
			}else{
				$this->session->set_flashdata('alert', 'alert-danger');
				$this->session->set_flashdata('flash_message', 'No Inventaris '.$search.' Tidak Ditemukan');
				redirect(base_url() . 'admin/traninv', 'refresh');
			}
		}else{
			$this->load->view('index', $page_data);
		}
    }
    
    /** *Laporan* **/

	public function laporan_anggota($param1='',$param2='')
	{
		if ($this->session->userdata('login_type') != 'admin')
				$this->logout();

		$date = new DateTime();
		$id=$this->session->userdata('user_id');
		$page_data['src']='';
		$page_data['tanggalawal']='';
		$page_data['tanggalakhir']='';
		$page_data['jenis'] = 'mahasiswa';
		if($this->input->post('pilih')=='dosen')
		$page_data['jenis'] = 'dosen';
		if($this->input->post('pilih')=='anggota+luar')
		$page_data['jenis'] = 'anggota+luar';
		$page_data['page_title'] = 'Laporan Data Anggota';
		
		if($this->input->post('src'))$page_data['src'] = $this->input->post('src');
		if($this->input->post('tanggalawal'))$page_data['tanggalawal'] = $this->input->post('tanggalawal');
		if($this->input->post('tanggalakhir'))$page_data['tanggalakhir'] = $this->input->post('tanggalakhir');
		
		if($param1=='export'){
			$jenis='anggota+luar';
			$tanggalawal='';
			$tanggalakhir='';
			$search='';
			
			if($param2=='excel'){
				$jenis=$this->input->post('epilih');
				$tanggalawal=$this->input->post('etanggalawal');
				$tanggalakhir=$this->input->post('etanggalakhir');
				$search=$this->input->post('esearch');
			}elseif($param2=='web'){
				$jenis=$this->input->post('wpilih');
				$tanggalawal=$this->input->post('wtanggalawal');
				$tanggalakhir=$this->input->post('wtanggalakhir');
				$search=$this->input->post('wsearch');
			}
			$page_data['laporan'] = 'laporan_anggota';
			$page_data['export'] =$param2;
			$page_data['page_title'] = 'Laporan Data Anggota '.$jenis;
			$page_data['title'] = 'Laporan Anggota ';
			$page_data['data']=$this->Md_laporan_anggota->getLaporan($jenis,$tanggalawal,$tanggalakhir,$search);
			$this->load->view('admin/excel', $page_data);
		}else if($param1 =='fetch'){
			$jenis=$param2;
			$total=$this->Md_laporan_anggota->countFiltered($jenis);
				$page=$this->input->post('datatable[pagination][page]');
			if($page<1)
				$page=1;

			$perpage=10;
			$pages=$total/$perpage;
			$field=$this->input->post('datatable[sort][field]');

			if($field=='')
				$field=$this->input->post('datatable[pagination][field]');

			$sort=$this->input->post('datatable[sort][sort]');

			if($sort=='')
				$sort=$this->input->post('datatable[pagination][sort]');

			//mulai fetching data
			$data = array();
			$no = 0;
			$list=$this->Md_laporan_anggota->getDatatables($jenis);
			foreach ($list as $row) {
				$no++;
				$arr = array();
				if($jenis=='dosen'){
					$arr['number'] = ($perpage*($page-1))+$no;
					$arr['nip'] = $row->nip;
					$arr['nama'] = $row->nama;
					$arr['jenis'] = $row->jk;
					$arr['tgl'] = $row->tanggal;
					$arr['berlaku'] = $row->berlaku_sampai;
					
				}else if($jenis=='anggota+luar'){
					$arr['number'] = ($perpage*($page-1))+$no;
					$arr['nama'] = $row->nama;
					$arr['jenis'] = $row->jk;
					$arr['instansi'] = $row->instansi_asal_nama;
					$arr['telepon'] = $row->telepon;
				}else{
					$arr['number'] = ($perpage*($page-1))+$no;
					$arr['nis'] = $row->nis;
					$arr['nama'] = $row->nama;
					$arr['kelas'] = $row->kelas;
					$arr['jenis'] = $row->jk;
					if ($row->status_siswa=='A'){
						$status_siswa="Aktif";
					}
					$arr['status_siswa'] = $status_siswa;
					$arr['status_anggota'] = $status_siswa;
					$arr['tgl'] = $row->tanggal;
					$arr['berlaku'] = $row->berlaku_sampai;
				}
				
				$data[] = $arr;
			}

			$meta=array();
			$meta['page']=$page;
			$meta['pages']=$pages;
			$meta['perpage']=$perpage;
			$meta['total']=$total;
			$meta['sort']=$sort;
			$meta['field']=$field;
			$output = array(
							"meta" => $meta,
							"data" => $data
					);
			//output to json format
			echo json_encode($output);
		}else{
			$page_data['page_access'] = "admin";
			$page_data['page_name'] = 'laporan_anggota';
			$page_data['page_now'] = 'dashboard';
			$this->load->view('index', $page_data);
		}
	}
	public function laporan_inventaris($param1='',$param2='')
	{
		if ($this->session->userdata('login_type') != 'admin')
				$this->logout();

		$date = new DateTime();
		$id=$this->session->userdata('user_id');
		$page_data['src']='';
		$page_data['tanggalawal']='';
		$page_data['tanggalakhir']='';
		$page_data['klas'] = '';
		$page_data['ktg'] = '';
		$page_data['page_title'] = 'Daftar Inventaris';
		
		$page_data['klasifikasi'] = $this->Md_siperpus_klasifikasi->getKlasifikasiAll();
		$page_data['kategori'] = $this->Md_siperpus_kategori->getKategoriAll();
		if($this->input->post('src'))$page_data['src'] = $this->input->post('src');
		if($this->input->post('klasifikasi'))$page_data['klas'] = $this->input->post('klasifikasi');
		if($this->input->post('kategori'))$page_data['ktg'] = $this->input->post('kategori');
		if($this->input->post('tanggalawal'))$page_data['tanggalawal'] = $this->input->post('tanggalawal');
		if($this->input->post('tanggalakhir'))$page_data['tanggalakhir'] = $this->input->post('tanggalakhir');
		
		if($param1=='export'){
			$klas='';
			$ktg='';
			$tanggalawal='';
			$tanggalakhir='';
			$search='';
			
			if($param2=='excel'){
				$klas=$this->input->post('eklas');
				$ktg=$this->input->post('ektg');
				$tanggalawal=$this->input->post('etanggalawal');
				$tanggalakhir=$this->input->post('etanggalakhir');
				$search=$this->input->post('esearch');
			}elseif($param2=='web'){
				$klas=$this->input->post('wklas');
				$ktg=$this->input->post('wktg');
				$tanggalawal=$this->input->post('wtanggalawal');
				$tanggalakhir=$this->input->post('wtanggalakhir');
				$search=$this->input->post('wsearch');
			}
			$page_data['nmktg'] = $this->Md_siperpus_kategori->getKategoriById($this->input->post('kategori'));
			$page_data['laporan'] = 'laporan_inventaris';
			$page_data['export'] =$param2;
			$page_data['page_title'] = 'Daftar Inventaris ';
			$page_data['title'] = 'Daftar Inventaris';
			$page_data['data']=$this->Md_laporan_inventaris->getLaporan($klas,$ktg,$tanggalawal,$tanggalakhir,$search);
			$this->load->view('admin/excel', $page_data);
		}else if($param1 =='fetch'){
			$total=$this->Md_laporan_inventaris->countFiltered();
			$page=$this->input->post('datatable[pagination][page]');
			if($page<1)
				$page=1;

			$perpage=10;
			$pages=$total/$perpage;
			$field=$this->input->post('datatable[sort][field]');

			if($field=='')
				$field=$this->input->post('datatable[pagination][field]');

			$sort=$this->input->post('datatable[sort][sort]');

			if($sort=='')
				$sort=$this->input->post('datatable[pagination][sort]');

			//mulai fetching data
			$data = array();
			$no = 0;
			$list=$this->Md_laporan_inventaris->getDatatables();
			foreach ($list as $row) {
				$no++;
				$arr = array();
					$arr['number'] = ($perpage*($page-1))+$no;
					$arr['penulis'] = $row->penulis;
					$arr['judul'] = $row->judul;
					$arr['edisi'] = $row->edisi;
					$arr['penerbit'] = $row->kd_penerbit;
					$arr['tahun'] = $row->thn_terbit;
					$arr['ISBN'] = $row->ISBN;
					$arr['jumlah'] = $row->jml_buku;
					$arr['noklas'] = $row->no_klas;
					$arr['tanggal'] = $row->tanggal;
				$data[] = $arr;
			}

			$meta=array();
			$meta['page']=$page;
			$meta['pages']=$pages;
			$meta['perpage']=$perpage;
			$meta['total']=$total;
			$meta['sort']=$sort;
			$meta['field']=$field;
			$output = array(
							"meta" => $meta,
							"data" => $data
					);
			//output to json format
			echo json_encode($output);
		}else{
			$page_data['page_access'] = "admin";
			$page_data['page_name'] = 'laporan_inventaris';
			$page_data['page_now'] = 'dashboard';
			$this->load->view('index', $page_data);
		}
	}
	public function laporan_kataloginventaris($param1='',$param2='')
	{
		if ($this->session->userdata('login_type') != 'admin')
				$this->logout();

		$date = new DateTime();
		$id=$this->session->userdata('user_id');
		$page_data['src']='';
		$page_data['tanggalawal']='';
		$page_data['tanggalakhir']='';
		$page_data['klas'] = '';
		$page_data['ktg'] = '';
		$page_data['page_title'] = 'Daftar Inventaris';
		
		$page_data['klasifikasi'] = $this->Md_siperpus_klasifikasi->getKlasifikasiAll();
		$page_data['kategori'] = $this->Md_siperpus_kategori->getKategoriAll();
		if($this->input->post('src'))$page_data['src'] = $this->input->post('src');
		if($this->input->post('klasifikasi'))$page_data['klas'] = $this->input->post('klasifikasi');
		if($this->input->post('kategori'))$page_data['ktg'] = $this->input->post('kategori');
		if($param1=='export'){
			$klas='';
			$ktg='';
			$search='';
			
			if($param2=='excel'){
				$klas=$this->input->post('eklas');
				$ktg=$this->input->post('ektg');
				$search=$this->input->post('esearch');
			}elseif($param2=='web'){
				$klas=$this->input->post('wklas');
				$ktg=$this->input->post('wktg');
				$search=$this->input->post('wsearch');
			}
			$page_data['nmktg'] = $this->Md_siperpus_kategori->getKategoriById($this->input->post('kategori'));
			$page_data['laporan'] = 'laporan_inventaris';
			$page_data['export'] =$param2;
			$page_data['page_title'] = 'Daftar Inventaris ';
			$page_data['title'] = 'Daftar Inventaris';
			$page_data['data']=$this->Md_laporan_kataloginventaris->getLaporan($klas,$ktg,$search);
			$this->load->view('admin/excel', $page_data);
		}else if($param1 =='fetch'){
			$total=$this->Md_laporan_kataloginventaris->countFiltered();
			$page=$this->input->post('datatable[pagination][page]');
			if($page<1)
				$page=1;

			$perpage=10;
			$pages=$total/$perpage;
			$field=$this->input->post('datatable[sort][field]');

			if($field=='')
				$field=$this->input->post('datatable[pagination][field]');

			$sort=$this->input->post('datatable[sort][sort]');

			if($sort=='')
				$sort=$this->input->post('datatable[pagination][sort]');

			//mulai fetching data
			$data = array();
			$no = 0;
			$list=$this->Md_laporan_kataloginventaris->getDatatables();
			foreach ($list as $row) {
				$no++;
				$arr = array();
					$arr['number'] = ($perpage*($page-1))+$no;
					$arr['penulis'] = $row->penulis;
					$arr['judul'] = $row->judul;
					$arr['edisi'] = $row->edisi;
					$arr['penerbit'] = $row->kd_penerbit;
					$arr['tahun'] = $row->thn_terbit;
					$arr['ISBN'] = $row->ISBN;
					$arr['jumlah'] = $row->jml_buku;
					$arr['noklas'] = $row->no_klas;
					$arr['tanggal'] = $row->tanggal;
				$data[] = $arr;
			}

			$meta=array();
			$meta['page']=$page;
			$meta['pages']=$pages;
			$meta['perpage']=$perpage;
			$meta['total']=$total;
			$meta['sort']=$sort;
			$meta['field']=$field;
			$output = array(
							"meta" => $meta,
							"data" => $data
					);
			//output to json format
			echo json_encode($output);
		}else{
			$page_data['page_access'] = "admin";
			$page_data['page_name'] = 'laporan_inventaris';
			$page_data['page_now'] = 'dashboard';
			$this->load->view('index', $page_data);
		}
	}
	public function laporan_hilang($param1='',$param2='')
	{
		if ($this->session->userdata('login_type') != 'admin')
				$this->logout();

		$date = new DateTime();
		$id=$this->session->userdata('user_id');
		$page_data['tanggalawal']='';
		$page_data['tanggalakhir']='';
		$page_data['page_title'] = 'Daftar Buku Hilang/Rusak';
		
		if($this->input->post('tanggalawal'))$page_data['tanggalawal'] = $this->input->post('tanggalawal');
		if($this->input->post('tanggalakhir'))$page_data['tanggalakhir'] = $this->input->post('tanggalakhir');
		if($param1=='export'){
			$tanggalawal='';
			$tanggalakhir='';
			$search='';
			
			if($param2=='excel'){
				$tanggalawal=$this->input->post('etanggalawal');
				$tanggalakhir=$this->input->post('etanggalakhir');
				$search=$this->input->post('esearch');
			}elseif($param2=='web'){
				$tanggalawal=$this->input->post('wtanggalawal');
				$tanggalakhir=$this->input->post('wtanggalakhir');
				$search=$this->input->post('wsearch');
			}
			$page_data['laporan'] = 'laporan_hilang';
			$page_data['export'] =$param2;
			$page_data['title'] = 'Daftar Buku Hilang/Rusak';
			$page_data['data']=$this->Md_laporan_hilang->getLaporan($klas,$ktg,$search);
			$this->load->view('admin/excel', $page_data);
		}else if($param1 =='fetch'){
			$total=$this->Md_laporan_hilang->countFiltered();
			$page=$this->input->post('datatable[pagination][page]');
			if($page<1)
				$page=1;

			$perpage=10;
			$pages=$total/$perpage;
			$field=$this->input->post('datatable[sort][field]');

			if($field=='')
				$field=$this->input->post('datatable[pagination][field]');

			$sort=$this->input->post('datatable[sort][sort]');

			if($sort=='')
				$sort=$this->input->post('datatable[pagination][sort]');

			//mulai fetching data
			$data = array();
			$no = 0;
			$list=$this->Md_laporan_hilang->getDatatables();
			foreach ($list as $row) {
				$no++;
				$arr = array();
					$arr['number'] = ($perpage*($page-1))+$no;
					$arr['noinv'] = $row->no_inv;
					$arr['judul'] = $row->judul;
					$arr['tanggal'] = $row->tgl_hr;
					$arr['nomor'] = $row->no_anggota;
					$arr['biaya'] = $row->biaya_ganti;
					$arr['keterangan'] = $row->ket;
				$data[] = $arr;
			}

			$meta=array();
			$meta['page']=$page;
			$meta['pages']=$pages;
			$meta['perpage']=$perpage;
			$meta['total']=$total;
			$meta['sort']=$sort;
			$meta['field']=$field;
			$output = array(
							"meta" => $meta,
							"data" => $data
					);
			//output to json format
			echo json_encode($output);
		}else{
			$page_data['page_access'] = "admin";
			$page_data['page_name'] = 'laporan_hilang';
			$page_data['page_now'] = 'dashboard';
			$this->load->view('index', $page_data);
		}
	}
	public function laporan_denda($param1='',$param2='')
	{
		if ($this->session->userdata('login_type') != 'admin')
				$this->logout();

		$date = new DateTime();
		$id=$this->session->userdata('user_id');
		$page_data['src']='';
		$page_data['tanggalawal']='';
		$page_data['tanggalakhir']='';
		$page_data['jenis'] = 'mahasiswa';
		if($this->input->post('pilih')=='dosen')
		$page_data['jenis'] = 'dosen';
		if($this->input->post('pilih')=='anggota+luar')
		$page_data['jenis'] = 'anggota+luar';
		$page_data['page_title'] = 'Form Periode Denda';
		
		if($this->input->post('src'))$page_data['src'] = $this->input->post('src');
		if($this->input->post('tanggalawal'))$page_data['tanggalawal'] = $this->input->post('tanggalawal');
		if($this->input->post('tanggalakhir'))$page_data['tanggalakhir'] = $this->input->post('tanggalakhir');
		
		if($param1=='export'){
			$jenis='anggota+luar';
			$tanggalawal='';
			$tanggalakhir='';
			$search='';
			
			if($param2=='excel'){
				$jenis=$this->input->post('epilih');
				$tanggalawal=$this->input->post('etanggalawal');
				$tanggalakhir=$this->input->post('etanggalakhir');
				$search=$this->input->post('esearch');
			}elseif($param2=='web'){
				$jenis=$this->input->post('wpilih');
				$tanggalawal=$this->input->post('wtanggalawal');
				$tanggalakhir=$this->input->post('wtanggalakhir');
				$search=$this->input->post('wsearch');
			}
			$page_data['laporan'] = 'laporan_denda';
			$page_data['export'] =$param2;
			$page_data['page_title'] = 'Form Periode Denda '.$jenis;
			$page_data['title'] = 'Form Periode Denda ';
			$page_data['data']=$this->Md_laporan_denda->getLaporan($jenis,$tanggalawal,$tanggalakhir,$search);
			$this->load->view('admin/excel', $page_data);
		}else if($param1 =='fetch'){
			$total=$this->Md_laporan_denda->countFiltered();
				$page=$this->input->post('datatable[pagination][page]');
			if($page<1)
				$page=1;

			$perpage=10;
			$pages=$total/$perpage;
			$field=$this->input->post('datatable[sort][field]');

			if($field=='')
				$field=$this->input->post('datatable[pagination][field]');

			$sort=$this->input->post('datatable[sort][sort]');

			if($sort=='')
				$sort=$this->input->post('datatable[pagination][sort]');

			//mulai fetching data
			$data = array();
			$no = 0;
			$list=$this->Md_laporan_denda->getDatatables();
			foreach ($list as $row) {
				$no++;
				$arr = array();
				if($this->input->post('datatable[query][jenis]')=='dosen'){
					$arr['number'] = ($perpage*($page-1))+$no;
					$arr['nomor'] = $row->no_anggota;
					$arr['nama'] = $row->nama;
					$arr['prodi'] = '';
					$arr['judul'] = $row->judul;
					$arr['tanggal'] = $row->tgl_kembali;
					$arr['denda'] = $row->denda;
					
				}else if($this->input->post('datatable[query][jenis]')=='anggota+luar'){
					$arr['number'] = ($perpage*($page-1))+$no;
					$arr['nomor'] = $row->no_anggota;
					$arr['nama'] = $row->nama;
					$arr['prodi'] = '';
					$arr['judul'] = $row->judul;
					$arr['tanggal'] = $row->tgl_kembali;
					$arr['denda'] = $row->denda;
				}else{
					$arr['number'] = ($perpage*($page-1))+$no;
					$arr['nomor'] = $row->no_anggota;
					$arr['nama'] = $row->nama;
					$arr['prodi'] = $row->kelas;
					$arr['judul'] = $row->judul;
					$arr['tanggal'] = $row->tgl_kembali;
					$arr['denda'] = $row->denda;
				}
				
				$data[] = $arr;
			}

			$meta=array();
			$meta['page']=$page;
			$meta['pages']=$pages;
			$meta['perpage']=$perpage;
			$meta['total']=$total;
			$meta['sort']=$sort;
			$meta['field']=$field;
			$output = array(
							"meta" => $meta,
							"data" => $data
					);
			//output to json format
			echo json_encode($output);
		}else{
			$page_data['page_access'] = "admin";
			$page_data['page_name'] = 'laporan_denda';
			$page_data['page_now'] = 'dashboard';
			$this->load->view('index', $page_data);
		}
	}
	public function laporan_presensi($param1='',$param2='')
	{
		if ($this->session->userdata('login_type') != 'admin')
				$this->logout();

		$date = new DateTime();
		$id=$this->session->userdata('user_id');
		$page_data['src']='';
		$page_data['tanggalawal']='';
		$page_data['tanggalakhir']='';
		$page_data['jenis'] = 'mahasiswa';
		if($this->input->post('pilih')=='dosen')
		$page_data['jenis'] = 'dosen';
		if($this->input->post('pilih')=='anggota+luar')
		$page_data['jenis'] = 'anggota+luar';
		$page_data['page_title'] = 'Daftar Presensi Kunjungan Perpustakaan';
		
		if($this->input->post('src'))$page_data['src'] = $this->input->post('src');
		if($this->input->post('tanggalawal'))$page_data['tanggalawal'] = $this->input->post('tanggalawal');
		if($this->input->post('tanggalakhir'))$page_data['tanggalakhir'] = $this->input->post('tanggalakhir');
		
		if($param1=='export'){
			$jenis='anggota+luar';
			$tanggalawal='';
			$tanggalakhir='';
			$search='';
			
			if($param2=='excel'){
				$jenis=$this->input->post('epilih');
				$tanggalawal=$this->input->post('etanggalawal');
				$tanggalakhir=$this->input->post('etanggalakhir');
				$search=$this->input->post('esearch');
			}elseif($param2=='web'){
				$jenis=$this->input->post('wpilih');
				$tanggalawal=$this->input->post('wtanggalawal');
				$tanggalakhir=$this->input->post('wtanggalakhir');
				$search=$this->input->post('wsearch');
			}
			$page_data['laporan'] = 'laporan_presensi';
			$page_data['export'] =$param2;
			$page_data['page_title'] = 'Daftar Presensi Kunjungan Perpustakaan ';
			$page_data['title'] = 'Daftar '.$jenis;
			$page_data['data']=$this->Md_laporan_presensi->getLaporan($jenis,$tanggalawal,$tanggalakhir,$search);
			$this->load->view('admin/excel', $page_data);
		}else if($param1 =='fetch'){
			$total=$this->Md_laporan_presensi->countFiltered();
				$page=$this->input->post('datatable[pagination][page]');
			if($page<1)
				$page=1;

			$perpage=10;
			$pages=$total/$perpage;
			$field=$this->input->post('datatable[sort][field]');

			if($field=='')
				$field=$this->input->post('datatable[pagination][field]');

			$sort=$this->input->post('datatable[sort][sort]');

			if($sort=='')
				$sort=$this->input->post('datatable[pagination][sort]');

			//mulai fetching data
			$data = array();
			$no = 0;
			$list=$this->Md_laporan_presensi->getDatatables();
			foreach ($list as $row) {
				$no++;
				$arr = array();
					$arr['number'] = ($perpage*($page-1))+$no;
					$arr['nomor'] = $row->nis;
					$arr['nama'] = $row->nama;
					$arr['jam'] = $row->jam;
					$arr['tanggal'] = $row->tanggal;
					
				$data[] = $arr;
			}

			$meta=array();
			$meta['page']=$page;
			$meta['pages']=$pages;
			$meta['perpage']=$perpage;
			$meta['total']=$total;
			$meta['sort']=$sort;
			$meta['field']=$field;
			$output = array(
							"meta" => $meta,
							"data" => $data
					);
			//output to json format
			echo json_encode($output);
		}else{
			$page_data['page_access'] = "admin";
			$page_data['page_name'] = 'laporan_presensi';
			$page_data['page_now'] = 'dashboard';
			$this->load->view('index', $page_data);
		}
	}
	public function laporan_peminjaman($param1='',$param2='')
	{
		if ($this->session->userdata('login_type') != 'admin')
				$this->logout();

		$date = new DateTime();
		$id=$this->session->userdata('user_id');
		$page_data['src']='';
		$page_data['tanggalawal']='';
		$page_data['tanggalakhir']='';
		$page_data['jenis'] = 'mahasiswa';
		if($this->input->post('pilih')=='dosen')
		$page_data['jenis'] = 'dosen';
		if($this->input->post('pilih')=='anggota+luar')
		$page_data['jenis'] = 'anggota+luar';
		$page_data['page_title'] = 'Daftar Peminjaman';
		
		if($this->input->post('src'))$page_data['src'] = $this->input->post('src');
		if($this->input->post('tanggalawal'))$page_data['tanggalawal'] = $this->input->post('tanggalawal');
		if($this->input->post('tanggalakhir'))$page_data['tanggalakhir'] = $this->input->post('tanggalakhir');
		
		if($param1=='export'){
			$jenis='anggota+luar';
			$tanggalawal='';
			$tanggalakhir='';
			$search='';
			
			if($param2=='excel'){
				$jenis=$this->input->post('epilih');
				$tanggalawal=$this->input->post('etanggalawal');
				$tanggalakhir=$this->input->post('etanggalakhir');
				$search=$this->input->post('esearch');
			}elseif($param2=='web'){
				$jenis=$this->input->post('wpilih');
				$tanggalawal=$this->input->post('wtanggalawal');
				$tanggalakhir=$this->input->post('wtanggalakhir');
				$search=$this->input->post('wsearch');
			}
			$page_data['laporan'] = 'laporan_peminjaman';
			$page_data['export'] =$param2;
			$page_data['page_title'] = 'Daftar Peminjaman';
			$page_data['title'] = 'Daftar '.$jenis;
			$page_data['data']=$this->Md_laporan_peminjaman->getLaporan($jenis,$tanggalawal,$tanggalakhir,$search);
			$this->load->view('admin/excel', $page_data);
		}else if($param1 =='fetch'){
			$total=$this->Md_laporan_peminjaman->countFiltered();
				$page=$this->input->post('datatable[pagination][page]');
			if($page<1)
				$page=1;

			$perpage=10;
			$pages=$total/$perpage;
			$field=$this->input->post('datatable[sort][field]');

			if($field=='')
				$field=$this->input->post('datatable[pagination][field]');

			$sort=$this->input->post('datatable[sort][sort]');

			if($sort=='')
				$sort=$this->input->post('datatable[pagination][sort]');

			//mulai fetching data
			$data = array();
			$no = 0;
			$list=$this->Md_laporan_peminjaman->getDatatables();
			foreach ($list as $row) {
				$no++;
				$arr = array();
					if($this->input->post('datatable[query][jenis]')=='dosen'){
					$arr['number'] = ($perpage*($page-1))+$no;
					$arr['nomor'] = $row->no_anggota;
					$arr['nama'] = $row->nama;
					$arr['prodi'] = '';
					$arr['noinv'] = $row->no_inv;
					$arr['judul'] = $row->judul;
					$arr['tanggal'] = $row->tgl_pinjam;
					$arr['batas'] = $row->batas;
					
				}else if($this->input->post('datatable[query][jenis]')=='anggota+luar'){
					$arr['number'] = ($perpage*($page-1))+$no;
					$arr['nomor'] = $row->no_anggota;
					$arr['nama'] = $row->nama;
					$arr['prodi'] = '';
					$arr['noinv'] = $row->no_inv;
					$arr['judul'] = $row->judul;
					$arr['tanggal'] = $row->tgl_pinjam;
					$arr['batas'] = $row->batas;
				}else{
					$arr['number'] = ($perpage*($page-1))+$no;
					$arr['nomor'] = $row->no_anggota;
					$arr['nama'] = $row->nama;
					$arr['prodi'] = $row->kelas;
					$arr['noinv'] = $row->no_inv;
					$arr['judul'] = $row->judul;
					$arr['tanggal'] = $row->tgl_pinjam;
					$arr['batas'] = $row->batas;
				}
					
				$data[] = $arr;
			}

			$meta=array();
			$meta['page']=$page;
			$meta['pages']=$pages;
			$meta['perpage']=$perpage;
			$meta['total']=$total;
			$meta['sort']=$sort;
			$meta['field']=$field;
			$output = array(
							"meta" => $meta,
							"data" => $data
					);
			//output to json format
			echo json_encode($output);
		}else{
			$page_data['page_access'] = "admin";
			$page_data['page_name'] = 'laporan_peminjaman';
			$page_data['page_now'] = 'dashboard';
			$this->load->view('index', $page_data);
		}
	}
	public function laporan_pengembalian($param1='',$param2='')
	{
		if ($this->session->userdata('login_type') != 'admin')
				$this->logout();

		$date = new DateTime();
		$id=$this->session->userdata('user_id');
		$page_data['src']='';
		$page_data['tanggalawal']='';
		$page_data['tanggalakhir']='';
		$page_data['jenis'] = 'mahasiswa';
		if($this->input->post('pilih')=='dosen')
		$page_data['jenis'] = 'dosen';
		if($this->input->post('pilih')=='anggota+luar')
		$page_data['jenis'] = 'anggota+luar';
		$page_data['page_title'] = 'Daftar Pengembalian';
		
		if($this->input->post('src'))$page_data['src'] = $this->input->post('src');
		if($this->input->post('tanggalawal'))$page_data['tanggalawal'] = $this->input->post('tanggalawal');
		if($this->input->post('tanggalakhir'))$page_data['tanggalakhir'] = $this->input->post('tanggalakhir');
		
		if($param1=='export'){
			$jenis='anggota+luar';
			$tanggalawal='';
			$tanggalakhir='';
			$search='';
			
			if($param2=='excel'){
				$jenis=$this->input->post('epilih');
				$tanggalawal=$this->input->post('etanggalawal');
				$tanggalakhir=$this->input->post('etanggalakhir');
				$search=$this->input->post('esearch');
			}elseif($param2=='web'){
				$jenis=$this->input->post('wpilih');
				$tanggalawal=$this->input->post('wtanggalawal');
				$tanggalakhir=$this->input->post('wtanggalakhir');
				$search=$this->input->post('wsearch');
			}
			$page_data['laporan'] = 'laporan_pengembalian';
			$page_data['export'] =$param2;
			$page_data['page_title'] = 'Daftar Pengembalian';
			$page_data['title'] = 'Daftar '.$jenis;
			$page_data['data']=$this->Md_laporan_pengembalian->getLaporan($jenis,$tanggalawal,$tanggalakhir,$search);
			$this->load->view('admin/excel', $page_data);
		}else if($param1 =='fetch'){
			$total=$this->Md_laporan_pengembalian->countFiltered();
				$page=$this->input->post('datatable[pagination][page]');
			if($page<1)
				$page=1;

			$perpage=10;
			$pages=$total/$perpage;
			$field=$this->input->post('datatable[sort][field]');

			if($field=='')
				$field=$this->input->post('datatable[pagination][field]');

			$sort=$this->input->post('datatable[sort][sort]');

			if($sort=='')
				$sort=$this->input->post('datatable[pagination][sort]');

			//mulai fetching data
			$data = array();
			$no = 0;
			$list=$this->Md_laporan_pengembalian->getDatatables();
			foreach ($list as $row) {
				$no++;
				$arr = array();
					if($this->input->post('datatable[query][jenis]')=='dosen'){
					$arr['number'] = ($perpage*($page-1))+$no;
					$arr['nomor'] = $row->no_anggota;
					$arr['nama'] = $row->nama;
					$arr['prodi'] = '';
					$arr['noinv'] = $row->no_inv;
					$arr['judul'] = $row->judul;
					$arr['tanggal'] = $row->tgl_kembali;
					
				}else if($this->input->post('datatable[query][jenis]')=='anggota+luar'){
					$arr['number'] = ($perpage*($page-1))+$no;
					$arr['nomor'] = $row->no_anggota;
					$arr['nama'] = $row->nama;
					$arr['prodi'] = '';
					$arr['noinv'] = $row->no_inv;
					$arr['judul'] = $row->judul;
					$arr['tanggal'] = $row->tgl_kembali;
				}else{
					$arr['number'] = ($perpage*($page-1))+$no;
					$arr['nomor'] = $row->no_anggota;
					$arr['nama'] = $row->nama;
					$arr['prodi'] = $row->kelas;
					$arr['noinv'] = $row->no_inv;
					$arr['judul'] = $row->judul;
					$arr['tanggal'] = $row->tgl_kembali;
				}
					
				$data[] = $arr;
			}

			$meta=array();
			$meta['page']=$page;
			$meta['pages']=$pages;
			$meta['perpage']=$perpage;
			$meta['total']=$total;
			$meta['sort']=$sort;
			$meta['field']=$field;
			$output = array(
							"meta" => $meta,
							"data" => $data
					);
			//output to json format
			echo json_encode($output);
		}else{
			$page_data['page_access'] = "admin";
			$page_data['page_name'] = 'laporan_pengembalian';
			$page_data['page_now'] = 'dashboard';
			$this->load->view('index', $page_data);
		}
	}
	public function laporan_belumkembali($param1='',$param2='')
	{
		if ($this->session->userdata('login_type') != 'admin')
				$this->logout();

		$date = new DateTime();
		$id=$this->session->userdata('user_id');
		$page_data['src']='';
		$page_data['tanggalawal']='';
		$page_data['tanggalakhir']='';
		$page_data['jenis'] = 'mahasiswa';
		if($this->input->post('pilih')=='dosen')
		$page_data['jenis'] = 'dosen';
		if($this->input->post('pilih')=='anggota+luar')
		$page_data['jenis'] = 'anggota+luar';
		$page_data['page_title'] = 'Form Peminjaman Belum Kembali';
		
		if($this->input->post('src'))$page_data['src'] = $this->input->post('src');
		if($this->input->post('tanggalawal'))$page_data['tanggalawal'] = $this->input->post('tanggalawal');
		if($this->input->post('tanggalakhir'))$page_data['tanggalakhir'] = $this->input->post('tanggalakhir');
		
		if($param1=='export'){
			$jenis='anggota+luar';
			$tanggalawal='';
			$tanggalakhir='';
			$search='';
			
			if($param2=='excel'){
				$jenis=$this->input->post('epilih');
				$tanggalawal=$this->input->post('etanggalawal');
				$tanggalakhir=$this->input->post('etanggalakhir');
				$search=$this->input->post('esearch');
			}elseif($param2=='web'){
				$jenis=$this->input->post('wpilih');
				$tanggalawal=$this->input->post('wtanggalawal');
				$tanggalakhir=$this->input->post('wtanggalakhir');
				$search=$this->input->post('wsearch');
			}
			$page_data['laporan'] = 'laporan_belumkembali';
			$page_data['export'] =$param2;
			$page_data['page_title'] = 'Form Peminjaman Belum Kembali';
			$page_data['title'] = 'Daftar '.$jenis;
			$page_data['data']=$this->Md_laporan_belumkembali->getLaporan($jenis,$tanggalawal,$tanggalakhir,$search);
			$this->load->view('admin/excel', $page_data);
		}else if($param1 =='fetch'){
			$total=$this->Md_laporan_belumkembali->countFiltered();
				$page=$this->input->post('datatable[pagination][page]');
			if($page<1)
				$page=1;

			$perpage=10;
			$pages=$total/$perpage;
			$field=$this->input->post('datatable[sort][field]');

			if($field=='')
				$field=$this->input->post('datatable[pagination][field]');

			$sort=$this->input->post('datatable[sort][sort]');

			if($sort=='')
				$sort=$this->input->post('datatable[pagination][sort]');

			//mulai fetching data
			$data = array();
			$no = 0;
			$list=$this->Md_laporan_belumkembali->getDatatables();
			foreach ($list as $row) {
				$no++;
				$arr = array();
					if($this->input->post('datatable[query][jenis]')=='dosen'){
					$arr['number'] = ($perpage*($page-1))+$no;
					$arr['nomor'] = $row->no_anggota;
					$arr['nama'] = $row->nama;
					$arr['prodi'] = '';
					$arr['noinv'] = $row->no_inv;
					$arr['judul'] = $row->judul;
					$arr['tanggal'] = $row->tgl_pinjam;
					$arr['batas'] = $row->batas;
					
				}else if($this->input->post('datatable[query][jenis]')=='anggota+luar'){
					$arr['number'] = ($perpage*($page-1))+$no;
					$arr['nomor'] = $row->no_anggota;
					$arr['nama'] = $row->nama;
					$arr['prodi'] = '';
					$arr['noinv'] = $row->no_inv;
					$arr['judul'] = $row->judul;
					$arr['tanggal'] = $row->tgl_pinjam;
					$arr['batas'] = $row->batas;
				}else{
					$arr['number'] = ($perpage*($page-1))+$no;
					$arr['nomor'] = $row->no_anggota;
					$arr['nama'] = $row->nama;
					$arr['prodi'] = $row->kelas;
					$arr['noinv'] = $row->no_inv;
					$arr['judul'] = $row->judul;
					$arr['tanggal'] = $row->tgl_pinjam;
					$arr['batas'] = $row->batas;
				}
					
				$data[] = $arr;
			}

			$meta=array();
			$meta['page']=$page;
			$meta['pages']=$pages;
			$meta['perpage']=$perpage;
			$meta['total']=$total;
			$meta['sort']=$sort;
			$meta['field']=$field;
			$output = array(
							"meta" => $meta,
							"data" => $data
					);
			//output to json format
			echo json_encode($output);
		}else{
			$page_data['page_access'] = "admin";
			$page_data['page_name'] = 'laporan_belumkembali';
			$page_data['page_now'] = 'dashboard';
			$this->load->view('index', $page_data);
		}
	}
}