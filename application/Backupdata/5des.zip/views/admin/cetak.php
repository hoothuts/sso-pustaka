<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>pecobaan</title>
  </head>
  <body>
    <?php var_dump($data); ?>
  </body>
</html>
