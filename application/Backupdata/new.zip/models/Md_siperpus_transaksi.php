<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Md_siperpus_transaksi extends CI_Model {

	var $table = 'siperpus_transaksi';
	var $column_order = array(array('tgl','siperpus_transaksi.tgl_pinjam'),array('batas','siperpus_transaksi.batas'),array('buku','sb.judul'));
	var $column_search = array('sb.judul'); 
	var $order = array('tgl_pinjam' => 'desc'); // default order 

	function countFiltered($id)
	{
		$this->getDatatablesQuery($id);
		$query = $this->db->get();
		return $query->num_rows();
	}
	public function getValue($b,$text){
		foreach($b as $v)
		{
			if(in_array($text, $v, true))
			{
				return $v[1];
			}
		}
		return false;
	}
	
	private function getDatatablesQuery($id)
	{
		
		$this->db->from($this->table);
		$this->db->where('no_anggota',$id);
		$this->db->where('kembali',0);
			$i=0;
			foreach ($this->column_search as $item) // loop column 
			{
				if($this->input->post('datatable[query][generalSearch]')) // if datatable send POST for search
				{
					if($i===0) // first loop
					{
						$this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
						$this->db->like($item, $this->input->post('datatable[query][generalSearch]'));
					}
					else
					{
						$this->db->or_like($item, $this->input->post('datatable[query][generalSearch]'));
					}

					if(count($this->column_search) - 1 == $i) //last loop
						$this->db->group_end(); //close bracket
				}
				$i++;
			}
		$val=$this->getValue($this->column_order,$this->input->post('datatable[sort][field]'));
		if($val!= false) // here order processing
		{
			$this->db->order_by($val, $this->input->post('datatable[sort][sort]'));
		} 
		else if(isset($this->order))
		{
			$order = $this->order;
			$this->db->order_by(key($order), $order[key($order)]);
		}
	}
	// Fetch data according to per_page limit.
	public function getDatatables($id) {
 
		$this->getDatatablesQuery($id);
		if($this->input->post('datatable[pagination][perpage]') != -1)
		$this->db->limit($this->input->post('datatable[pagination][perpage]'), ($this->input->post('datatable[pagination][perpage]')*(($this->input->post('datatable[pagination][page]')-1))));
		$this->db->join('siperpus_inventaris si', 'si.no_inv = siperpus_transaksi.no_inv');
		$this->db->join('siperpus_buku sb', 'sb.isbn = si.isbn');
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
		foreach ($query->result() as $row) {
		$data[] = $row;
		}

		return $data;
		}
		return false;

	}
	function addTransaksi($data){
         $this->db->insert('siperpus_transaksi', $data);
		 return 1;
    }
	function hapusTransaksi($data)
    {
      $this->db->where('tid',$data);
      $this->db->delete('siperpus_transaksi');
    }
	function updateTransaksi($param,$data){
        $this->db->where('tid', $param);
        $this->db->update('siperpus_transaksi', $data);         
    }
	function getLastId() {
		 $hasil = $this->db->query("SELECT * FROM siperpus_transaksi order by tid desc");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                return $row->tid;
            }
        }else{
			return 0;
		}
	}
	function getPinjamKe($no,$inv) {
		 $hasil = $this->db->query("SELECT pinjam_ke FROM siperpus_transaksi where no_anggota='$no' and no_inv='$inv'");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                return $row->pinjam_ke;
            }
        }else{
			return 0;
		}
	}
	function getTransaksiById($id) {
        $hasil = $this->db->get_where('siperpus_transaksi', array('tid' => $id))->result();
        $data = $hasil;
        return $data;
    }
    function isPinjam($inv) {
		 $hasil = $this->db->query("SELECT * FROM siperpus_transaksi where no_inv='$inv' and kembali=0 ");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                return true;
            }
        }else{
			return false;
		}
	}
	function getTransaksiTanpaKartu($id) {
        $hasil = $this->db->get_where('siperpus_transaksi', array('no_inv' => $id,'kembali' => 0))->result();
        $data = $hasil;
        return $data;
    }
    function getTransaksiDipinjamByISBN($isbn) {
		 $hasil = $this->db->query("SELECT * FROM siperpus_transaksi where kembali=0 and no_inv in (select no_inv from siperpus_inventaris where isbn='$isbn')");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
    }
}