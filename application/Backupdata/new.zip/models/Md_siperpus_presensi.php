<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Md_siperpus_presensi extends CI_Model {

	 var $table = 'siperpus_presensi';
	var $column_order = array(array('tanggal','tanggal')); //set column field database for datatable orderable
	var $column_search = array('tanggal'); //set column field database for datatable searchable just firstname , lastname , address are searchable
	var $order = array('tanggal' => 'desc'); // default order 

	public function countAll() {
        $this->db->from($this->table);
		return $this->db->count_all_results();
    }
	function countFiltered()
	{
		$this->getDatatablesQuery();
		$query = $this->db->get();
		return $query->num_rows();
	}
	public function getValue($b,$text){
		foreach($b as $v)
		{
			if(in_array($text, $v, true))
			{
				return $v[1];
			}
		}
		return false;
	}
	private function getDatatablesQuery()
	{
		
		$this->db->from($this->table);

		$i = 0;
	
		foreach ($this->column_search as $item) // loop column 
		{
			if($this->input->post('datatable[query][generalSearch]')) // if datatable send POST for search
			{
				
				if($i===0) // first loop
				{
					$this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
					$this->db->like($item, $this->input->post('datatable[query][generalSearch]'));
				}
				else
				{
					$this->db->or_like($item, $this->input->post('datatable[query][generalSearch]'));
				}

				if(count($this->column_search) - 1 == $i) //last loop
					$this->db->group_end(); //close bracket
			}
			$i++;
		}
		//filter group

		if($this->input->post('datatable[query][kategori]')){
			$this->db->where('idsysgroup', $this->input->post('datatable[query][group]'));
			}
			
		if($this->input->post('datatable[query][klasifikasi]')){
			$this->db->where('active', $this->input->post('datatable[query][status]'));
		}
			
		//if($i > 0) $this->db->group_end(); //close bracket
		
		$val=$this->getValue($this->column_order,$this->input->post('datatable[sort][field]'));
		if($val!= false) // here order processing
		{
			$this->db->order_by($val, $this->input->post('datatable[sort][sort]'));
		} 
		else if(isset($this->order))
		{
			$order = $this->order;
			$this->db->order_by(key($order), $order[key($order)]);
		}
	}

	function getDatatables()
	{
		$this->getDatatablesQuery();
		if($this->input->post('datatable[pagination][perpage]') != -1)
		$this->db->limit($this->input->post('datatable[pagination][perpage]'), ($this->input->post('datatable[pagination][perpage]')*(($this->input->post('datatable[pagination][page]')-1))));
		$this->db->join('siperpus_presensi_nonanggota', 'siperpus_presensi.tanggal = siperpus_presensi_nonanggota.tanggal');
		$this->db->group_by("DATE_FORMAT(tanggal, '%c %d %Y')"); 
		$query = $this->db->get();
		return $query->result();
	}
   function getPresensi7Hari() {
		 $hasil = $this->db->query("SELECT distinct(tanggal) FROM ( select tanggal from siperpus_presensi UNION ALL SELECT tanggal FROM siperpus_presensi_nonanggota) p group by DATE_FORMAT(tanggal, '%c %d %Y') order by tanggal desc limit 7");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
    }
	function getDetailByTanggal($tgl) {
		 $hasil = $this->db->query("SELECT DATE_FORMAT(tanggal, '%Y-%M-%d') as tgl,DATE_FORMAT(tanggal, '%H:%I:%S') as jam,nomor,jenis FROM ( select tanggal,nis as nomor, 'anggota' as jenis from siperpus_presensi where cast(tanggal as date)='2017-11-05' UNION ALL SELECT tanggal,nama as nomor, 'nonanggota' as jenis FROM siperpus_presensi_nonanggota where cast(tanggal as date)='2017-11-05' ) p");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
    }
	function getJumlah($date) {
         $hasil = $this->db->query("SELECT MAX(Acount) + MAX(Bcount) as jumlah FROM (
		   SELECT count(tanggal)as Acount,0 as Bcount FROM siperpus_presensi     where cast(tanggal as date) = '$date' UNION ALL SELECT 0 as Acount,count(tanggal) as Bcount FROM siperpus_presensi_nonanggota     where cast(tanggal as date) = '$date'
			) p");
        
		if ($hasil->num_rows() > 0) {
             foreach ($hasil->result() as $row) {
                $data[] = $row;
            }
            return $data[0]->jumlah;
        }else{
			return 0;
		}
    }
	function addPresensi($data){
         $this->db->insert('siperpus_presensi', $data);
		 return 1;
    }
	function addPresensiNon($data){
         $this->db->insert('siperpus_presensi_nonanggota', $data);
		 return 1;
    }
}