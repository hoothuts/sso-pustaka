<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Md_siperpus_inventaris extends CI_Model {

   function getInventarisAll() {
		 $hasil = $this->db->query("SELECT * FROM siperpus_inventaris order by no_inv asc limit 10");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                $data[] = $row;
            }
            //$data['baris']=$this->db->query("SELECT MAX(idkategori) FROM siperpus_kategori")
            return $data;
        }
    }
	function getInventarisJudulAll() {
		 $hasil = $this->db->query("SELECT *,(select judul from siperpus_buku where isbn=siperpus_inventaris.isbn) as judul FROM siperpus_inventaris order by no_inv asc limit 10");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                $data[] = $row;
            }
            //$data['baris']=$this->db->query("SELECT MAX(idkategori) FROM siperpus_kategori")
            return $data;
        }
    }
	 function addInventaris($data){
         $this->db->insert('siperpus_inventaris', $data);
    }
   function hapusInventaris($data)
    {
      $this->db->where('no_inv',$data);
      $this->db->delete('siperpus_inventaris');
    }
   function updateInventaris($param,$data){
        $this->db->where('no_inv', $param);
        $this->db->update('siperpus_inventaris', $data);
    }
	 function getInventarisById($id) {
        $hasil = $this->db->get_where('siperpus_inventaris', array('no_inv' => $id))->result();
        $data = $hasil;
        return $data;
    }
    function getInventarisByISBN($id) {
        $hasil = $this->db->get_where('siperpus_inventaris', array('isbn' => $id))->result();
        $data = $hasil;
        return $data;
    }
}
