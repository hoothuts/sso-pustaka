<div class="m-grid__item m-grid__item--fluid m-wrapper">
	<!-- BEGIN: Subheader -->
	<div class="m-subheader ">
		<div class="d-flex align-items-center">
							<div class="mr-auto">
								<h3 class="m-subheader__title m-subheader__title--separator">
									<?php echo $page_title;?>
								</h3>
								<ul class="m-subheader__breadcrumbs m-nav m-nav--inline">
											<li class="m-nav__item m-nav__item--home">
												<a href="<?php echo base_url();?>admin/dashboard" class="m-nav__link m-nav__link--icon">
													<i class="m-nav__link-icon la la-home"></i>
												</a>
											</li>
											<li class="m-nav__separator">
												-
											</li>
											<li class="m-nav__item">
												<a href="" class="m-nav__link">
													<span class="m-nav__link-text">
														Transaksi
													</span>
												</a>
											</li>
											<li class="m-nav__separator">
												-
											</li>
											<li class="m-nav__item">
												<a href="" class="m-nav__link">
													<span class="m-nav__link-text">
														<?php echo $page_title;?>
													</span>
												</a>
											</li>
										</ul>
							</div>
							<div>
								<span class="m-subheader__daterange" id="m_dashboard_daterangepicker">
									<span class="m-subheader__daterange-label">
										<span class="m-subheader__daterange-title"></span>
										<span class="m-subheader__daterange-date m--font-brand"></span>
									</span>
									<a href="#" class="btn btn-sm btn-brand m-btn m-btn--icon m-btn--icon-only m-btn--custom m-btn--pill">
										<i class="la la-angle-down"></i>
									</a>
								</span>
							</div>
						</div>
	</div>
	<!-- END: Subheader -->
	<div class="m-content">
						<div class="m-alert m-alert--icon m-alert--icon-solid m-alert--outline alert <?php echo $this->session->flashdata('alert')?> alert-dismissible fade" role="alert" id="alertbox" style="display:none">
									<div class="m-alert__icon">
										<i class="flaticon-exclamation-1"></i>
										<span></span>
									</div>
									<div class="m-alert__text">
										<?= $this->session->flashdata('flash_message') ?>
									</div>
								</div>
						<div class="m-portlet m-portlet--mobile">
							<div class="m-portlet__head">
								<div class="m-portlet__head-caption">
									<div class="m-portlet__head-title">
										<h3 class="m-portlet__head-text">
											<?php echo $page_title;?>
											
											<small>
												<i class="glyphicon glyphicon-refresh"></i>
												<button style="display:none" class="btn btn-default" id="m_datatable_reload">
												<i class="fa fa-refresh"></i> Reload</button>
													</small>
										</h3>
									</div>
								</div>
							</div>
							<div class="m-portlet__body">
								<!--begin: Search Form -->
								<div class="m-form m-form--label-align-right m--margin-top-20 m--margin-bottom-30">
									<div class="row align-items-center">
										<div class="col-xl-8 order-2 order-xl-1">
											
										</div>
										<div class="col-xl-4 order-1 order-xl-2 m--align-right">
											<a href="#" class="btn btn-primary m-btn m-btn--custom m-btn--icon m-btn--air m-btn--pill" onclick="tambah_bukutamu()">
												<span>
													<i class="flaticon-users"></i>
													<span>
														Buku Tamu
													</span>
												</span>
											</a>
											<div class="m-separator m-separator--dashed d-xl-none"></div>
											<a href="#" class="btn btn-primary m-btn m-btn--custom m-btn--icon m-btn--air m-btn--pill" onclick="tambah_bukutamu_nonanggota()">
												<span>
													<i class="flaticon-add"></i>
													<span>
														Buku Tamu (Bukan Anggota)
													</span>
												</span>
											</a>
											
										</div>
									</div>
								</div>
								<div class="m_datatable" id="ajax_data"></div>
								<!--begin: Datatable -->
								    
								<!--end: Datatable -->
							</div>
							</div>
					</div>
				</div>
			<!-- end:: Body -->
 
<script type="text/javascript">
 
var save_method; //for save method string
var table;
 
 var Dtb=function() {
    var t=function() {
        var t= {
            data: {
                type:"remote", source: {
                    read: {
                        url: "<?php echo base_url();?><?php echo $page_access;?>/<?php echo $page_name;?>/fetch/"
                    }
                }
                ,
                pageSize:20,
                saveState: {
                    cookie: !1, webstorage: !1
                }
                ,
                serverPaging:true,
                serverFiltering:true,
                serverSorting:true
            }
            , layout: {
                theme: "default", class: "", scroll: !1, footer: !1
            }
            , 
			sortable: true,

			filterable: false,
		
			pagination: false,

			searchDelay: 400,

			 columns:[ {
                field: "number", title: "No.", sortable: false, width: 40, selector: !1, textAlign: "center"
            }
            , {
                field:"tanggal", title:"Tanggal", sortable: false, filterable:!1, width:150
            }
            , {
                field: "jumlah", title: "Jumlah", sortable: false
            }
            , {
                field:"action", width:110, title:"detail", sortable: false, overflow:"visible", template:function(t) {
                    return'\t\t\t\t\t\t<div class="dropdown '+(t.getDatatable().getPageSize()-t.getIndex()<=4?"dropup": "")+'">\t\t\t\t\t\t\t<a href="#" class="btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill" data-toggle="dropdown">                                <i class="la la-gear"></i>                            </a>\t\t\t\t\t\t  \t<div class="dropdown-menu dropdown-menu-right">\t\t\t\t\t\t    \t<a class="dropdown-item" href="javascript:void(0)" title="Detail" onclick="detail(\''+t.tanggal+'\')"><i class="la la-search"></i> Detail</a>\t\t\t\t\t\t    \t</div>\t\t\t\t\t\t</div>'
                }
            }
            ],
			 toolbar: {
			layout: ['pagination', 'info'],

			placement: ['bottom'],  //'top', 'bottom'

			items: {
				pagination: {
					type: 'default',

					pages: {
						desktop: {
							layout: 'default',
							pagesNumber: 6
						},
						tablet: {
							layout: 'default',
							pagesNumber: 3
						},
						mobile: {
							layout: 'compact'
						}
					},

					navigation: {
						prev: true,
						next: true,
						first: true,
						last: true
					},

					pageSizeSelect: [10, 20, 30, 50, 100]
				},

				info: true
			}
		},

		translate: {
			records: {
				processing: 'Please wait...',
				noRecords: 'No records found'
			},
			toolbar: {
				pagination: {
					items: {
						default: {
							first: 'First',
							prev: 'Previous',
							next: 'Next',
							last: 'Last',
							more: 'More pages',
							input: 'Page number',
							select: 'Select page size'
						},
						info: 'Displaying {{start}} - {{end}} from {{total}} records'
					}
				}
			}
		}
        }
        ,
        e=$(".m_datatable").mDatatable(t),
        a=e.getDataSourceQuery();
        $('#m_datatable_reload').on('click', function () {
			//e.destroy()
			//e=$(".m_datatable").mDatatable(t)
			e.reload()
		})
        
    };
	return {
        init:function() {
            t()
        }
    }
}

();
jQuery(document).ready(function() {
    Dtb.init()
}

);
function tambah_bukutamu()
{
	save_method = 'add';
    $('#form')[0].reset(); // reset form on modals
    $('.form-group').removeClass('has-error'); // clear error class
    $('.help-block').empty(); // clear error string
    $('#modal_form').modal('show'); // show bootstrap modal
    $('.modal-title').text('FORM KEHADIRAN DI PERPUSTAKAAN'); // Set Title to Bootstrap modal title
}
 function tambah_bukutamu_nonanggota()
{
	save_method = 'addnon';
    $('#form2')[0].reset(); // reset form on modals
    $('.form-group').removeClass('has-error'); // clear error class
    $('.help-block').empty(); // clear error string
    $('#modal_form2').modal('show'); // show bootstrap modal
    $('.modal-title').text('FORM KEHADIRAN DI PERPUSTAKAAN Non Anggota'); // Set Title to Bootstrap modal title
}
function reload_table()
{
	$( "#m_datatable_reload" ).trigger( "click" );
}
 
function save()
{
	
    $('#btnSave').text('saving...'); //change button text
    $('#btnSave').attr('disabled',true); //set button disable 
	
    var url;
	var formname="#form";
    if(save_method == 'add') {
	var formname="#form";
        url = "<?php echo base_url();?><?php echo $page_access;?>/<?php echo $page_name;?>/submit/";
    } else {
	var formname="#form2";
        url = "<?php echo base_url();?><?php echo $page_access;?>/<?php echo $page_name;?>/submitnon/";
    }
 
    // ajax adding data to database
    $.ajax({
        url : url,
        type: "POST",
        data: $(formname).serialize(),
        dataType: "JSON",
        success: function(data)
        {
 
            if(data.status) //if success close modal and reload ajax table
            {
				if(data.status='TRUE'){
					document.getElementById('alertbox').style.display = 'block';
					$('.alert').addClass('show '+data.alert);
					$('.alert').children('.m-alert__text').html(data.msg);
					hidealert();
					//if success reload ajax table
					if(save_method == 'add') {
						$('#modal_form').modal('hide');
					}else{
						$('#modal_form2').modal('hide');
					}
					
					reload_table();
				}
            }
            else
            {
                for (var i = 0; i < data.inputerror.length; i++) 
                {
                    $('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('has-error'); //select parent twice to select div form-group class and add has-error class
                    $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]); //select span help-block class set text error string
                }
            }
			
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 
			
 
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 
		   alert('Error adding / update data'+textStatus+errorThrown);
		}
    });
}

 function hidealert(){
	setTimeout(function(){
	   document.getElementById('alertbox').style.display = 'none';
	}, 3000);
}

function detail(id)
{
    //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo base_url();?><?php echo $page_access;?>/<?php echo $page_name;?>/detail/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
			if(data.status='TRUE'){
				
				var len=data.size;
				var HTML = "<table class='table'><thead class='thead-inverse'><tr>";
				HTML += "<th scope='row'>No.</th>";
				HTML += "<th>Tanggal</th>";
				HTML += "<th>Jam</th>";
				HTML += "<th>NIS/NIP</th>";
				HTML += "<th>NAMA</th>";
				HTML += "</tr></thead><tbody>";
				for(j=0;j<len;j++)
				{
					HTML += "<tr>";
					HTML +="<td scope='row'>"+ (j+1)+"</td>";
					HTML +="<td>"+ data.table[j].tgl+"</td>";
					HTML +="<td>"+ data.table[j].jam+"</td>";
					HTML +="<td>"+ data.table[j].nomor+"</td>";
					HTML +="<td>"+ data.table[j].nama+"</td>";
					HTML += "</tr>";
				}
				HTML += "</tbody></table>";
				document.getElementById("outputDiv").innerHTML = HTML;
				
				$('#modal_detail').modal('show'); // show bootstrap modal when complete loaded
				$('.modal-title').text('Detail Presensi '+data.tanggal); // Set title to Bootstrap modal title
			}
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error');
        }
    });
}
</script>
<div class="modal fade" id="modal_detail" tabindex="-1" role="dialog"aria-hidden="true">
							<div class="modal-dialog modal-md" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<h5 class="modal-title">
											<i class="m-menu__link-icon flaticon-add"></i> Detail
										</h5>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true">
												&times;
											</span>
										</button>
									</div>
									<div class="modal-body">
											  <div id="outputDiv"></div>
										</div>
								</div>
							</div>
						</div>
<!--begin::Modal-->
						<div class="modal fade" id="modal_form" tabindex="-1" role="dialog"  aria-hidden="true">
							<div class="modal-dialog modal-md" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<h5 class="modal-title" >
										</h5>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true">
												&times;
											</span>
										</button>
									</div>
									<div class="modal-body">
									<!--<?php echo base_url();?><?php echo $page_access;?>/<?php echo $page_name;?>/submit/-->
										 <form id="form" action="#" class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed">
										 <input type="hidden" name="id1" id="id1">
											<div class="form-group m-form__group">
												<label for="">
													NIM/NIP*
												</label>
												<input type="text" id="nomor" name="nomor" class="form-control m-input" placeholder="Masukkan NIM/NIP">
											</div>
										</div>
										<div class="modal-footer">
										<input id="btnSave" onclick="save()" type="submit" class="btn btn-primary" value="Simpan">
										</div>
									</form>
								</div>
							</div>
						</div>
						<div class="modal fade" id="modal_form2" tabindex="-1" role="dialog"  aria-hidden="true">
							<div class="modal-dialog modal-md" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<h5 class="modal-title" >
										</h5>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true">
												&times;
											</span>
										</button>
									</div>
									<div class="modal-body">
									<!--<?php echo base_url();?><?php echo $page_access;?>/<?php echo $page_name;?>/submit/-->
										 <form id="form2" action="#" class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed">
										 <input type="hidden" name="id1" id="id1">
											<div class="form-group m-form__group">
												<label for="">
													Nama*
												</label>
												<input type="text" id="nama" name="nama" class="form-control m-input" placeholder="Masukkan nama">
											</div>
											<div class="form-group m-form__group">
												<label for="">
													asal*
												</label>
												<input type="text" id="asal" name="asal" class="form-control m-input" placeholder="Masukkan Asal">
											</div>
										</div>
										<div class="modal-footer">
										<input id="btnSave" onclick="save()" type="submit" class="btn btn-primary" value="Simpan">
										</div>
									</form>
								</div>
							</div>
						</div>
						<!--end::Modal-->