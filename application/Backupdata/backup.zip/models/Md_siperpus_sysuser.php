<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Md_siperpus_sysuser extends CI_Model {

    function checkLogin($uname,$pwd) {
        $hasil = $this->db->get_where('siperpus_sysuser', array('idsysuser' => $uname,'pass' => $pwd,'active' => '1'))->result();
        $data = $hasil;
        return $data;
    }
	function getUserAll() {
		 $hasil = $this->db->query("SELECT * FROM siperpus_sysuser where active='1' order by idsysuser asc");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
    }
}