<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Md_siperpus_klasifikasi extends CI_Model {

   function getKlasifikasiAll() {
		 $hasil = $this->db->query("SELECT * FROM siperpus_klasifikasi order by nama asc");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
    }
	function addKlasifikasi($data){
         $this->db->insert('siperpus_klasifikasi', $data);        
    }
	function hapusKlasifikasi($data)
    {
      $this->db->where('id',$data);
      $this->db->delete('siperpus_klasifikasi');
    }
   function updateKlasifikasi($param,$data){
        $this->db->where('id', $param);
        $this->db->update('siperpus_klasifikasi', $data);         
    }
	 function getKlasifikasiById($id) {
        $hasil = $this->db->get_where('siperpus_klasifikasi', array('id' => $id))->result();
        $data = $hasil;
        return $data;
    }
	
}