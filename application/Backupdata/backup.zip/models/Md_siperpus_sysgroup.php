<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Md_siperpus_sysgroup extends CI_Model {
	function getGroupById($group) {
		 $hasil = $this->db->query("SELECT * FROM siperpus_sysgroup where idsysgroup='$group'");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
    }
}