<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!--begin::Base Scripts -->
		<script src="<?php echo base_url();?>assets/vendors/base/vendors.bundle.js" type="text/javascript"></script>
		<script src="<?php echo base_url();?>assets/demo/demo2/base/scripts.bundle.js" type="text/javascript"></script>
		<!--end::Base Scripts -->
		<!--begin::Page Snippets -->
		<script src="<?php echo base_url();?>assets/app/js/dashboard.js" type="text/javascript"></script>
		
        <script src="<?php echo base_url();?>assets/global/scripts/app.min.js" type="text/javascript"></script>
          	<!-- BEGIN PAGE LEVEL PLUGINS -->
            <script src="<?php echo base_url();?>assets/global/scripts/datatable.js" type="text/javascript"></script>
            <script src="<?php echo base_url();?>assets/global/plugins/datatables/datatables.min.js" type="text/javascript"></script>
            <script src="<?php echo base_url();?>assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js" type="text/javascript"></script>
            <!-- END PAGE LEVEL PLUGINS -->
            <script src="<?php echo base_url();?>assets/pages/scripts/table-datatables-managed.js" type="text/javascript"></script>
		<!--end::Page Snippets -->