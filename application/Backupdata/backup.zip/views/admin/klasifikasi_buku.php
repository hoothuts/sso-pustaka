<!-- begin::Body -->
<div class="m-grid__item m-grid__item--fluid m-grid m-grid--hor-desktop m-grid--desktop m-body">
					<div class="m-grid__item m-grid__item--fluid  m-grid m-grid--ver	m-container m-container--responsive m-container--xxl m-page__container">
				<div class="m-grid__item m-grid__item--fluid m-wrapper">
					<div class="m-content">
						<?php if ($this->session->flashdata('flash_message') != ""):?>
						<div class="m-alert m-alert--icon m-alert--air m-alert--square alert alert-dismissible m--margin-bottom-30" role="alert">
							<div class="m-alert__icon">
								<i class="flaticon-exclamation m--font-brand"></i>
							</div>
							<div class="m-alert__text">
								<?php echo $this->session->flashdata('flash_message'); ?>
							</div>
						</div>
					<?php endif; ?>
						
						<?php if($page_action =='list'){?>
						<div class="m-portlet m-portlet--mobile">
							<div class="m-portlet__head">
								<div class="m-portlet__head-caption">
									<div class="m-portlet__head-title">
										<h3 class="m-portlet__head-text">
											<?php echo $page_title;?>
												<a href="<?php echo base_url();?><?php echo $page_access;?>/<?php echo $page_name;?>/tambah/">
															<button type="button" class="m-btn btn btn-info">
																Tambah <i class="flaticon-add"></i>
															</button>
												</a>
										</h3>
									</div>
								</div>
							</div>
							<div class="m-portlet__body">
								<!--begin: Search Form -->
								<!--begin: Datatable -->
								<?php 
								if($data){
								?>
								    <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_6">
                                        <thead>
                                            <tr>
                                                <th> No </th>
                                                <th> Kode</th>
                                                <th> Klasifikasi </th>
                                                <th> Menu </th>
                                            </tr>
                                        </thead>
                                        <tbody>
										<?php 
										$count=0;
										foreach($data as $row){
										$count++;
										?>
                                            <tr class="odd gradeX">
                                                <td> <?php echo $count;?> </td>
                                                <td> <?php echo $row->id;?> </td>
                                                <td><?php echo $row->nama;?></td>
												<td>
												<div class="btn-group" role="group" aria-label="Menu">
													<a href="<?php echo base_url();?><?php echo $page_access;?>/<?php echo $page_name;?>/edit/<?php echo $row->id;?>">
														<button type="button" class="m-btn btn btn-warning">
															Edit <i class="la la-files-o"></i>
														</button>
													</a>
													<a href="<?php echo base_url();?><?php echo $page_access;?>/<?php echo $page_name;?>/hapus/<?php echo $row->id;?>">
															<button onclick="return confirm('Are you sure you want to delete this data?')" type="button" class="m-btn btn btn-warning">
																Hapus <i class="la la-files-o"></i>
															</button>
														</a>
												</div>
												</td>
                                            </tr>
										<?php }?>
                                        </tbody>
                                    </table>
                                <?php 
								}
								?>
								<!--end: Datatable -->
							</div>
						</div>
						<?php } ?>
						
					<?php if($page_action =='tambah'){?>
							<div class="m-portlet">
									<div class="m-portlet__head">
										<div class="m-portlet__head-caption">
											<div class="m-portlet__head-title">
												<span class="m-portlet__head-icon m--hide">
													<i class="la la-gear"></i>
												</span>
												<h3 class="m-portlet__head-text">
													<?php echo $page_title;?>
												</h3>
											</div>
										</div>
									</div>
									<!--begin::Form-->
									<form method="post" action="<?php echo base_url();?><?php echo $page_access;?>/<?php echo $page_name;?>/submit/" class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed">
										<div class="m-portlet__body">
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													ID:
												</label>
												<div class="col-lg-3">
													<input type="text" id="id" name="id" class="form-control m-input" placeholder="Masukkan ID">
													<span class="m-form__help">
														Masukkan ID Klasifikasi Buku
													</span>
												</div>
												<label class="col-lg-2 col-form-label">
													Klasifikasi Buku:
												</label>
												<div class="col-lg-3">
													<input type="text" id="nama" name="nama" class="form-control m-input" placeholder="Masukkan nama">
													<span class="m-form__help">
														Masukkan Nama Klasifikasi
													</span>
												</div>
											</div>
										</div>
										<div class="m-portlet__foot m-portlet__no-border m-portlet__foot--fit">
											<div class="m-form__actions m-form__actions--solid">
												<div class="row">
													<div class="col-lg-2"></div>
													<div class="col-lg-10">
														<button type="submit" class="btn btn-success">
															Submit
														</button>
														<button type="reset" class="btn btn-secondary">
															Cancel
														</button>
													</div>
												</div>
											</div>
										</div>
									</form>
									<!--end::Form-->
								</div>
						
						<?php } ?>
						<?php if($page_action =='edit'){?>
							<?php if($data){?>
							<div class="m-portlet">
									<div class="m-portlet__head">
										<div class="m-portlet__head-caption">
											<div class="m-portlet__head-title">
												<span class="m-portlet__head-icon m--hide">
													<i class="la la-gear"></i>
												</span>
												<h3 class="m-portlet__head-text">
													<?php echo $page_title;?>
												</h3>
											</div>
										</div>
									</div>
									<!--begin::Form-->
									<form method="post" action="<?php echo base_url();?><?php echo $page_access;?>/<?php echo $page_name;?>/update/<?php echo $data[0]->id;?>" class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed">
										<div class="m-portlet__body">
											<div class="form-group m-form__group row">
												<label class="col-lg-2 col-form-label">
													ID:
												</label>
												<div class="col-lg-3">
													<input type="text" id="id" name="id" class="form-control m-input" value="<?php echo $data[0]->id;?>" placeholder="Masukkan ID">
													<span class="m-form__help">
														Masukkan ID Klasifikasi Buku
													</span>
												</div>
												<label class="col-lg-2 col-form-label">
													Klasifikasi Buku:
												</label>
												<div class="col-lg-3">
													<input type="text" id="nama" name="nama" class="form-control m-input" value="<?php echo $data[0]->nama;?>" placeholder="Masukkan nama">
													<span class="m-form__help">
														Masukkan Nama Klasifikasi
													</span>
												</div>
											</div>
										</div>
										<div class="m-portlet__foot m-portlet__no-border m-portlet__foot--fit">
											<div class="m-form__actions m-form__actions--solid">
												<div class="row">
													<div class="col-lg-2"></div>
													<div class="col-lg-10">
														<button type="submit" class="btn btn-success">
															Submit
														</button>
														<button type="reset" class="btn btn-secondary">
															Cancel
														</button>
													</div>
												</div>
											</div>
										</div>
									</form>
									<!--end::Form-->
								</div>
							<?php } ?>
						<?php } ?>
					</div>
				</div>
			</div>
</div>
			<!-- end:: Body -->