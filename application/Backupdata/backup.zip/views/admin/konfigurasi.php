<!-- begin::Body -->
<div class="m-grid__item m-grid__item--fluid m-grid m-grid--hor-desktop m-grid--desktop m-body">
					<div class="m-grid__item m-grid__item--fluid  m-grid m-grid--ver	m-container m-container--responsive m-container--xxl m-page__container">
				<div class="m-grid__item m-grid__item--fluid m-wrapper">
					<div class="m-content">
						<?php if ($this->session->flashdata('flash_message') != ""):?>
						<div class="m-alert m-alert--icon m-alert--air m-alert--square alert alert-dismissible m--margin-bottom-30" role="alert">
							<div class="m-alert__icon">
								<i class="flaticon-exclamation m--font-brand"></i>
							</div>
							<div class="m-alert__text">
								<?php echo $this->session->flashdata('flash_message'); ?>
							</div>
						</div>
					<?php endif; ?>
						
						<?php if($page_action =='list'){?>
						<div class="m-portlet m-portlet--mobile">
							<div class="m-portlet__head">
								<div class="m-portlet__head-caption">
									<div class="m-portlet__head-title">
										<h3 class="m-portlet__head-text">
											<?php echo $page_title;?>
										</h3>
									</div>
								</div>
							</div>
							<div class="m-portlet__body">
								<!--begin: Search Form -->
								<!--begin: Datatable -->
								<?php 
								if($data){
								?>
								   <div class="m-portlet">
									<div class="m-portlet__head">
										<div class="m-portlet__head-caption">
											<div class="m-portlet__head-title">
												<span class="m-portlet__head-icon m--hide">
													<i class="la la-gear"></i>
												</span>
												<h3 class="m-portlet__head-text">
													Konfigurasi
												</h3>
											</div>
										</div>
									</div>
									<!--begin::Form-->
									<form method="post" action="<?php echo base_url();?><?php echo $page_access;?>/<?php echo $page_name;?>/update/" class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed">
										<input type="hidden" name="setting1kode" value="<?php echo $data[0]->kodesetting;?>">
										<input type="hidden" name="setting2kode" value="<?php echo $data[1]->kodesetting;?>">
										<input type="hidden" name="setting3kode" value="<?php echo $data[2]->kodesetting;?>">
										<input type="hidden" name="setting4kode" value="<?php echo $data[3]->kodesetting;?>">
										<input type="hidden" name="setting5kode" value="<?php echo $data[4]->kodesetting;?>">
										<input type="hidden" name="setting6kode" value="<?php echo $data[5]->kodesetting;?>">
										<input type="hidden" name="setting7kode" value="<?php echo $data[6]->kodesetting;?>">
										<input type="hidden" name="setting8kode" value="<?php echo $data[7]->kodesetting;?>">
										<input type="hidden" name="setting9kode" value="<?php echo $data[8]->kodesetting;?>">
										<input type="hidden" name="setting10kode" value="<?php echo $data[9]->kodesetting;?>">
										<div class="m-portlet__body">
											<div class="form-group m-form__group row">
												<label class="col-lg-5 col-form-label">
													<?php echo $data[0]->nmsetting;?>
												</label>
												<div class="col-lg-5">
													<input type="text" id="setting1" name="setting1" class="form-control m-input" value="<?php echo $data[0]->valsetting;?>">
													<span class="m-form__help">
														
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-5 col-form-label">
													<?php echo $data[1]->nmsetting;?>
												</label>
												<div class="col-lg-5">
													<input type="text" id="setting2" name="setting2" class="form-control m-input" value="<?php echo $data[1]->valsetting;?>">
													<span class="m-form__help">
														
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-5 col-form-label">
													<?php echo $data[2]->nmsetting;?>
												</label>
												<div class="col-lg-5">
													<input type="text" id="setting3" name="setting3" class="form-control m-input" value="<?php echo $data[2]->valsetting;?>">
													<span class="m-form__help">
														
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-5 col-form-label">
													<?php echo $data[3]->nmsetting;?>
												</label>
												<div class="col-lg-5">
													<input type="text" id="setting4" name="setting4" class="form-control m-input" value="<?php echo $data[3]->valsetting;?>">
													<span class="m-form__help">
														
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-5 col-form-label">
													<?php echo $data[4]->nmsetting;?>
												</label>
												<div class="col-lg-5">
													<input type="text" id="setting5" name="setting5" class="form-control m-input" value="<?php echo $data[4]->valsetting;?>">
													<span class="m-form__help">
														
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-5 col-form-label">
													<?php echo $data[5]->nmsetting;?>
												</label>
												<div class="col-lg-5">
													<input type="text" id="setting6" name="setting6" class="form-control m-input" value="<?php echo $data[5]->valsetting;?>">
													<span class="m-form__help">
														
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-5 col-form-label">
													<?php echo $data[6]->nmsetting;?>
												</label>
												<div class="col-lg-5">
													<input type="text" id="setting7" name="setting7" class="form-control m-input" value="<?php echo $data[6]->valsetting;?>">
													<span class="m-form__help">
														
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-5 col-form-label">
													<?php echo $data[7]->nmsetting;?>
												</label>
												<div class="col-lg-5">
													<!-- select-->
													<?php if($data_kategori){?>
													<select name="setting8" id="setting8" class="form-control m-input">
														<?php foreach($data_kategori as $row){?>
														<option value="<?php echo $row->idkategori;?>" <?php if($row->idkategori == $data[7]->valsetting) echo 'selected';?>><?php echo $row->nmkategori;?> [<?php echo $row->idkategori;?>]</option>
														<?php }?>
													</select>
													<?php } ?>
													<span class="m-form__help">
														
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-5 col-form-label">
													<?php echo $data[8]->nmsetting;?>
												</label>
												<div class="col-lg-5">
												<!-- select-->
													<?php if($data_kategori){?>
													<select name="setting9" id="setting9" class="form-control m-input">
														<?php foreach($data_kategori as $row){?>
														<option value="<?php echo $row->idkategori;?>" <?php if($row->idkategori == $data[8]->valsetting) echo 'selected';?>><?php echo $row->nmkategori;?> [<?php echo $row->idkategori;?>]</option>
														<?php }?>
													</select>
													<?php } ?>
													<span class="m-form__help">
														
													</span>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<label class="col-lg-5 col-form-label">
													<?php echo $data[9]->nmsetting;?>
												</label>
												<div class="col-lg-5">
												<!-- select-->
													<select name="setting10" id="setting10" class="form-control m-input">
														<option value="simpleblue.v.2.kampus" <?php if('simpleblue.v.2.kampus' == $data[8]->valsetting) echo 'selected';?>>simpleblue.v.2.kampus</option>
													</select>
													<span class="m-form__help">
														
													</span>
												</div>
											</div>
										</div>
										<div class="m-portlet__foot m-portlet__no-border m-portlet__foot--fit">
											<div class="m-form__actions m-form__actions--solid">
												<div class="row">
													<div class="col-lg-2"></div>
													<div class="col-lg-10">
														<button type="submit" class="btn btn-success">
															Submit
														</button>
														<button type="reset" class="btn btn-secondary">
															Cancel
														</button>
													</div>
												</div>
											</div>
										</div>
									</form>
									<!--end::Form-->
								</div>
                                <?php 
								}
								?>
								<!--end: Datatable -->
							</div>
						</div>
						<?php } ?>
						
					</div>
				</div>
			</div>
</div>
			<!-- end:: Body -->