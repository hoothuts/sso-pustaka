<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
<!DOCTYPE html><!-- 
Template Name: Metronic - Responsive Admin Dashboard Template build with Twitter Bootstrap 4
Version: 5.0.2
Author: KeenThemes
Website: http://www.keenthemes.com/
Contact: support@keenthemes.com
Follow: www.twitter.com/keenthemes
Dribbble: www.dribbble.com/keenthemes
Like: www.facebook.com/keenthemes
Purchase: http://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes
Renew Support: http://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes
License: You must have a valid license purchased only from themeforest(the above link) in order to legally use the theme for your project.
-->
<html lang="en" >
<!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
<?php $this->load->helper('header'); ?>
</head>
	<!-- end::Head -->
	<!-- end::Body -->
	<body class="m-page--wide m-header--fixed m-header--fixed-mobile m-footer--push m-aside--offcanvas-default"  >
		<!-- begin:: Page -->
		<div class="m-grid m-grid--hor m-grid--root m-page">
<!-- begin::Header -->
	 	<?php include $this->session->userdata('login_type') . '/header.php'; ?>
			<!-- end::Header -->
			<!-- begin::Body -->
    <?php include $this->session->userdata('login_type') . '/' . $page_name . '.php'; ?>                
<!-- end::Body -->
<!-- begin::Footer -->
<?php $this->load->helper('footer'); ?>
<!-- end::Footer -->
</div>
<!-- end:: Page -->
<!-- begin::Quick Sidebar -->
<?php $this->load->helper('quicksidebar'); ?>
<!-- end::Quick Sidebar -->
<!-- begin::Scroll Top -->
<div class="m-scroll-top m-scroll-top--skin-top" data-toggle="m-scroll-top" data-scroll-offset="500" data-scroll-speed="300">
	<i class="la la-arrow-up"></i>
</div>
<!-- end::Scroll Top -->
<!-- begin::Quick Nav -->
<?php $this->load->helper('quicknav'); ?>
<!-- end::Quick Nav -->
<!--begin::Scripts -->
<?php $this->load->helper('basescript'); ?>
<!--end::Scripts -->
</body>
	<!-- end::Body -->
</html>