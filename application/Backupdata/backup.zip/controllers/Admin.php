<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends CI_Controller {

	 function __construct() {
    	parent::__construct();
    date_default_timezone_set('Asia/Jakarta');

    $this->load->database();
		$this->load->model('md_siperpus_sysuser');
		$this->load->model('md_siperpus_sysgroup');
		$this->load->model('md_vwsiswa');
		$this->load->model('md_vwdosen');
		$this->load->model('md_vwanggota');
		$this->load->model('md_siperpus_anggota_luar');

		$this->load->model('md_siperpus_klasifikasi');
		$this->load->model('md_siperpus_kategori_buku');
		$this->load->model('md_siperpus_bahasa');
		$this->load->model('md_siperpus_asal_buku');
		$this->load->model('md_siperpus_penerbit');
		$this->load->model('md_siperpus_keperluan_sbppl');
		$this->load->model('md_vwprodi');
		$this->load->model('md_siperpus_matakuliah');
		$this->load->model('md_siperpus_data_buku');
		$this->load->model('md_siperpus_inventaris');


        //from http://www.zedwood.com/article/php-calculate-duration-of-mp3

		//include APPPATH.'controllers/mp3file.php'; //load mp3file class for calculate duration

		/* cash control */

        $this->output->set_header('Last-Modified: ' . gmdate("D, d M Y H:i:s") . ' GMT');

        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');

        $this->output->set_header('Pragma: no-cache');

        $this->output->set_header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");

    }



	public function index()

	{

		if ($this->session->userdata('login') != 'A')

			{

			$this->session->sess_destroy();

            redirect(base_url() . 'home', 'refresh');

			}

        if ($this->session->userdata('login') == 'A')

            redirect(base_url() . 'admin/dashboard', 'refresh');

	}



	public function logout()

	{

	$date = new DateTime();

		$id=$this->session->userdata('user_id');

		if(!empty($id)){
		$user=$this->md_user->getuserById($id);
		$log['user_id']=$id;
		$log['tgl']=$date->format("Y-m-d H:i:s");
		$log['jenis_log']='admin';
		$log['jenis_akses']='LogOut';
		$log['status']=1;
		$log['keterangan']=$user[0]->username.' Melakukan LogOut';
		$log['IP']=$_SERVER['REMOTE_ADDR'];
		$this->md_log->addLogBaru($log);
		}
		$this->session->sess_destroy();

	    redirect(base_url() . 'home', 'refresh');

	}



	function dashboard() {

        if ($this->session->userdata('login') != 'A')
			$this->logout();

        $page_data['page_access'] = "admin";

        $page_data['page_name'] = 'dashboard';

        $page_data['page_now'] = 'dashboard';

        $page_data['page_title'] = 'Manage Dashboard';

		$this->load->view('index', $page_data);

    }
	/** *Data Mahasiswa* **/

	public function data_mahasiswa($param1='',$param2='')
	{
		if ($this->session->userdata('login') != 'A')
				$this->logout();

		$date = new DateTime();
		$id=$this->session->userdata('user_id');

		$page_data['page_action'] = 'list';
		$page_data['page_title'] = 'Data Mahasiswa';
		$page_data['page_access'] = "admin";
		$page_data['page_name'] = 'data_mahasiswa';
		$page_data['page_now'] = 'Data Induk';

		if($param1 =='list'){
			 $data = array();
			 $no = 0;
			 $list=$this->md_vwsiswa->getSiswaAll();
			 foreach ($list as $row) {
				 $no++;
				 $arr = array();
				 $arr[] = $no;
				 $arr[] = $row->nis;
				 $arr[] = $row->nama;
				 $arr[] = $row->kelas;
				 $arr[] = $row->alamat;
				 $arr[] = $row->telepon;
				 $arr[] = "-";
				 if ($row->status_siswa=='A') {
				 	$arr[] = "Aktif";
				}else {
					$arr[] = "-";
				}
				 $data[] = $arr;
			 }
			 $output = array( "draw" => 1,
								 "recordsTotal" => 1,
								 "recordsFiltered" => 1,
								 "data" => $data,
			 );
			 //output to json format
			 echo json_encode($output);
		 }else{
			 $this->load->view('index', $page_data);
		 }
	}

	/** *Data Dosen* **/
	public function data_dosen($param1='',$param2='')
	{
		if ($this->session->userdata('login') != 'A')
				$this->logout();

		$date = new DateTime();
		$id=$this->session->userdata('user_id');

		$page_data['page_action'] = 'list';
		$page_data['page_title'] = 'Data Dosen';
		$page_data['page_access'] = "admin";
		$page_data['page_name'] = 'data_dosen';
		$page_data['page_now'] = 'Data Induk';

		if($param1 =='list'){
			 $data = array();
			 $no = 0;
			 $list=$this->md_vwdosen->getDosenAll();
			 foreach ($list as $row) {
				 $no++;
				 $arr = array();
				 $arr[] = $no;
				 $arr[] = $row->nip;
				 $arr[] = $row->nama;
				 $arr[] = " ";
				 $arr[] = " ";
				 $arr[] = " ";
				 $data[] = $arr;
			 }
			 $output = array( "draw" => 1,
								 "recordsTotal" => 1,
								 "recordsFiltered" => 1,
								 "data" => $data,
			 );
			 //output to json format
			 echo json_encode($output);
		 }else{
			 $this->load->view('index', $page_data);
		 }
	}

	/** *Data Anggota* **/

	public function data_anggota($param1='',$param2='')
	{
		if ($this->session->userdata('login') != 'A')
				$this->logout();

		$date = new DateTime();
		$id=$this->session->userdata('user_id');

		$page_data['page_action'] = 'list';
		$page_data['page_title'] = 'Data Anggota';
		$page_data['page_access'] = "admin";
		$page_data['page_name'] = 'data_anggota';
		$page_data['page_now'] = 'Data Induk';

		if($param1 =='list'){
			 $data = array();
			 $no = 0;
			 $list=$this->md_vwanggota->getAnggotaAll();
			 foreach ($list as $row) {
				 $no++;
				 $arr = array();
				 $arr[] = $no;
				 $arr[] = $row->no_anggota;
				 $arr[] = $row->nama;
				 if ($row->status==1) {
				 	$arr[]="Aktif";
				}else {
					$arr[]="-";
				}
				 $arr[] = $row->berlaku_sampai;
				 $data[] = $arr;
			 }
			 $output = array( "draw" => 1,
								 "recordsTotal" => 1,
								 "recordsFiltered" => 1,
								 "data" => $data,
			 );
			 //output to json format
			 echo json_encode($output);
		 }else{
			 $this->load->view('index', $page_data);
		 }
	}

	/** *Data Anggota Luar* **/
	public function data_anggota_luar($param1='',$param2='')
	{
		if ($this->session->userdata('login') != 'A')
				$this->logout();

		$date = new DateTime();
		$id=$this->session->userdata('user_id');

		$page_data['page_action'] = 'list';
		$page_data['page_title'] = 'Data Anggota Luar';
		$page_data['page_access'] = "admin";
		$page_data['page_name'] = 'data_anggota_luar';
		$page_data['page_now'] = 'Data Induk';

		if($param1 =='list'){
			 $data = array();
			 $no = 0;
			 $list=$this->md_siperpus_anggota_luar->getAnggotaAll();
			 foreach ($list as $row) {
				 $no++;
				 $arr = array();
				 $arr[] = $no;
				 $arr[] = $row->noid;
				 $arr[] = $row->nama;
				 $arr[] = $row->instansi_asal_nama;
				 //$arr[] = "";
				 $arr[] = '<div class="m-dropdown m-dropdown--up m-dropdown--inline  m-dropdown--arrow" data-dropdown-toggle="click"><a href="#" class="m-dropdown__toggle btn btn-success dropdown-toggle"><i class="fa fa-cogs"></i> Action</a><div class="m-dropdown__wrapper"><span class="m-dropdown__arrow m-dropdown__arrow--left"></span><div class="m-dropdown__inner"><div class="m-dropdown__body"><div class="m-dropdown__content"><ul class="m-nav"><li class="m-nav__item"><a  class="m-nav__link" href="javascript:void(0)" title="Edit" onclick="edit_buku('."'".$row->noid."'".')"><button type="button" class="m-btn btn btn-info">Edit <i class="la la-files-o"></i></button></a></li><li class="m-nav__item"><a class="m-nav__link" href="javascript:void(0)" title="Delete" onclick="delete_buku('."'".$row->noid."'".')"><button type="button" class="m-btn btn btn-danger">Hapus <i class="la la-files-o"></i></button></a></li></ul></div></div></div></div></div>';
				 $data[] = $arr;
			 }
			 $output = array( "draw" => 1,
								 "recordsTotal" => 1,
								 "recordsFiltered" => 1,
								 "data" => $data,
			 );
			 //output to json format
			 echo json_encode($output);
		 }else{
			 $this->load->view('index', $page_data);
		 }
	}

		//
    // function data_anggota_luar($param1 = '', $param2 = '', $param3 = '') {
		//
    //     if ($this->session->userdata('login') != 'A')
		//
    //         $this->logout();
		//
		// $date = new DateTime();
		//
		// $id=$this->session->userdata('user_id');
		//
    //     $page_data['page_action'] = $param1;
    //     $page_data['page_access'] = "admin";
    //     $page_data['page_name'] = 'data_anggota_luar';
    //     $page_data['page_now'] = 'Data Induk';
    //     $page_data['page_title'] = 'Data Anggota Luar';
		// $page_data['data']=$this->md_siperpus_anggota_luar->getAnggotaAll();
    //     $this->load->view('index', $page_data);
		//
    // }

		/** *Data Klasifikasi* **/
    function klasifikasi_buku($param1 = '', $param2 = '', $param3 = '')
		{
			if ($this->session->userdata('login') != 'A') $this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');
	    $page_data['page_action'] = 'list';
	    $page_data['page_title'] = 'Data Klasifikasi Buku';
			$page_data['page_access'] = "admin";
			$page_data['page_name'] = 'klasifikasi_buku';
			$page_data['page_now'] = 'Data Referensi';

			if ($param1 == 'submit') {
				$data['id'] = $this->input->post('id');
				$data['nama'] = $this->input->post('nama');
				if($data['id']=='' || $data['nama']==''){
					//Empty Field
					$this->session->set_flashdata('alert', 'alert-danger');
					$this->session->set_flashdata('flash_message', 'Empty Field');
					echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
					//redirect(base_url() . 'admin/klasifikasi_buku/tambah', 'refresh');
				}else{
					$buku=$this->md_siperpus_klasifikasi->getKlasifikasiById($this->input->post('id'));
					if($buku){
						//Id duplicate
						$this->session->set_flashdata('alert', 'alert-danger');
						$this->session->set_flashdata('flash_message', 'ID telah dipakai, klasifikasi buku gagal dibuat');
						echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "ID telah dipakai, Klasifikasi buku gagal dibuat"));
						//redirect(base_url() . 'admin/klasifikasi_buku/tambah', 'refresh');
					}else{
						$this->md_siperpus_klasifikasi->addKlasifikasi($data);
						$this->session->set_flashdata('alert', 'alert-focus');
						$this->session->set_flashdata('flash_message', 'Klasifikasi Buku Sukses dibuat');
						echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Klasifikasi Buku Sukses dibuat"));
						//redirect(base_url() . 'admin/klasifikasi_buku', 'refresh');
						}
					}
	      }else if ($param1 == 'update') {
					$id1=$this->input->post('id1');
					$data['id'] = $this->input->post('id');
					$data['nama'] = $this->input->post('nama');
					if($data['id']=='' || $data['nama']==''){
						//Empty Field
						$this->session->set_flashdata('alert', 'alert-danger');
						$this->session->set_flashdata('flash_message', 'Empty Field');
						echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
						//redirect(base_url() . 'admin/klasifikasi_buku/edit', 'refresh');
					}else{
						$this->md_siperpus_klasifikasi->updateKlasifikasi($id1, $data);
						$this->session->set_flashdata('alert', 'alert-focus');
						$this->session->set_flashdata('flash_message', 'Klasifikasi Buku Sukses diedit');
						//redirect(base_url() . 'admin/klasifikasi_buku', 'refresh');
						echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Klasifikasi Buku Sukses diedit".$data['id']));
					}
	      }else if ($param1=='hapus' && $param2 !='') {
					$this->md_siperpus_klasifikasi->hapusKlasifikasi($param2);
					$this->session->set_flashdata('alert', 'alert-focus');
					$this->session->set_flashdata('flash_message', 'Klasifikasi Buku Sukses Dihapus');
					//redirect(base_url() . 'admin/klasifikasi_buku', 'refresh');
					echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Klasifikasi Buku Sukses Dihapus"));
				}else if($param1 =='edit' && $param2 !=''){
					/*
					$page_data['data']=$this->md_siperpus_klasifikasi->getKlasifikasiById($param2);
					$page_data['page_action'] = $param1;
					$page_data['page_title'] = 'Edit Klasifikasi Buku';
					*/
					$data = $this->md_siperpus_klasifikasi->getKlasifikasiById($param2);
					echo json_encode($data);
				}else if($param1 =='list'){
					$data = array();
					$no = 0;
					$list=$this->md_siperpus_klasifikasi->getKlasifikasiAll();
					foreach ($list as $row) {
						$no++;
						$arr = array();
						$arr[] = $no;
						$arr[] = $row->id;
						$arr[] = $row->nama;
						//add html for action
						$arr[] = '<div class="m-dropdown m-dropdown--up m-dropdown--inline  m-dropdown--arrow" data-dropdown-toggle="click"><a href="#" class="m-dropdown__toggle btn btn-success dropdown-toggle"><i class="fa fa-cogs"></i> Action</a><div class="m-dropdown__wrapper"><span class="m-dropdown__arrow m-dropdown__arrow--left"></span><div class="m-dropdown__inner"><div class="m-dropdown__body"><div class="m-dropdown__content"><ul class="m-nav"><li class="m-nav__item"><a  class="m-nav__link" href="javascript:void(0)" title="Edit" onclick="edit_buku('."'".$row->id."'".')"><button type="button" class="m-btn btn btn-info">Edit <i class="la la-files-o"></i></button></a></li><li class="m-nav__item"><a class="m-nav__link" href="javascript:void(0)" title="Delete" onclick="delete_buku('."'".$row->id."'".')"><button type="button" class="m-btn btn btn-danger">Hapus <i class="la la-files-o"></i></button></a></li></ul></div></div></div></div></div>';
						$data[] = $arr;
					}
					$output = array( "draw" => 1,
										"recordsTotal" => 1,
										"recordsFiltered" => 1,
										"data" => $data,
					);
					//output to json format
					echo json_encode($output);
				}else{
					$this->load->view('index', $page_data);
				}
		}
		/** *Kategori Buku* **/

		public function kategori_buku($param1='',$param2='')
		{
			if ($this->session->userdata('login') != 'A')
					$this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');

      $page_data['page_action'] = 'list';
      $page_data['page_title'] = 'Data Kategori Buku';
			$page_data['page_access'] = "admin";
      $page_data['page_name'] = 'kategori_buku';
      $page_data['page_now'] = 'Data Referensi';

			if ($param1 == 'submit') {
				$data['idkategori'] = $this->input->post('idkategori');
				$data['nmkategori'] = $this->input->post('nmkategori');
				if($data['nmkategori']==''||$data['idkategori']==''){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-warning');
				$this->session->set_flashdata('flash_message', 'Empty Field');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
				//redirect(base_url() . 'admin/kategori_buku/tambah', 'refresh');
				}else{
					$buku=$this->md_siperpus_kategori_buku->getKategoriById($this->input->post('idkategori'));
					if($buku){
						//Id duplicate
						$this->session->set_flashdata('alert', 'alert-warning');
						$this->session->set_flashdata('flash_message', 'Kategori telah ada, kategori buku gagal dibuat');
						echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "ID telah dipakai, Kategori buku gagal dibuat"));
						//redirect(base_url() . 'admin/kategori_buku', 'refresh');
					}else {
						$this->md_siperpus_kategori_buku->addKategoriBuku($data);
						$this->session->set_flashdata('alert', 'alert-success');
						$this->session->set_flashdata('flash_message', 'Kategori Buku Sukses dibuat');
						echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Kategori Buku Sukses dibuat"));
						//redirect(base_url() . 'admin/kategori_buku', 'refresh');
				 }
				}
			}else if ($param1 == 'update') {
				$id1=$this->input->post('id1');
				$data['idkategori'] = $this->input->post('idkategori');
				$data['nmkategori'] = $this->input->post('nmkategori');
				if($data['nmkategori']==''){
					//Empty Field
					$this->session->set_flashdata('alert', 'alert-warning');
					$this->session->set_flashdata('flash_message', 'Empty Field');
					echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));//redirect(base_url() . 'admin/kategori_buku/edit', 'refresh');
				}else{
					$this->md_siperpus_kategori_buku->updateKategoriBuku($id1, $data);
					$this->session->set_flashdata('alert', 'alert-success');
					$this->session->set_flashdata('flash_message', 'Kategori Buku Sukses diedit');
					echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Kategori Buku Sukses diedit"));//redirect(base_url() . 'admin/kategori_buku', 'refresh');
				}
			}elseif ($param1=='hapus') {
				$this->md_siperpus_kategori_buku->hapusKategoriBuku($param2);
				$this->session->set_flashdata('alert', 'alert-success');
				$this->session->set_flashdata('flash_message', 'Kategori Buku Sukses Dihapus');
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Kategori Buku Sukses Dihapus"));//redirect(base_url() . 'admin/kategori_buku', 'refresh');
			}
			 else if($param1 =='edit' && $param2 !=''){
				// $page_data['data']=$this->md_siperpus_kategori_buku->getKategoriById($param2);
				// $page_data['page_action'] = $param1;
				// $page_data['page_title'] = 'Edit Kategori Buku';
				$data = $this->md_siperpus_kategori_buku->getKategoriById($param2);
				echo json_encode($data);
			 }else if($param1 =='list'){
				 $data = array();
				 $no = 0;
				 $list=$this->md_siperpus_kategori_buku->getKategoriBukuAll();
				 foreach ($list as $row) {
					 $no++;
					 $arr = array();
					 $arr[] = $no;
					 $arr[] = $row->idkategori;
					 $arr[] = $row->nmkategori;
					 $arr[] = '<div class="m-dropdown m-dropdown--up m-dropdown--inline  m-dropdown--arrow" data-dropdown-toggle="click"><a href="#" class="m-dropdown__toggle btn btn-success dropdown-toggle"><i class="fa fa-cogs"></i> Action</a><div class="m-dropdown__wrapper"><span class="m-dropdown__arrow m-dropdown__arrow--left"></span><div class="m-dropdown__inner"><div class="m-dropdown__body"><div class="m-dropdown__content"><ul class="m-nav"><li class="m-nav__item"><a  class="m-nav__link" href="javascript:void(0)" title="Edit" onclick="edit_buku('."'".$row->idkategori."'".')"><button type="button" class="m-btn btn btn-info">Edit <i class="la la-files-o"></i></button></a></li><li class="m-nav__item"><a class="m-nav__link" href="javascript:void(0)" title="Delete" onclick="delete_buku('."'".$row->idkategori."'".')"><button type="button" class="m-btn btn btn-danger">Hapus <i class="la la-files-o"></i></button></a></li></ul></div></div></div></div></div>';
					 $data[] = $arr;
				 }
				 $output = array( "draw" => 1,
									 "recordsTotal" => 1,
									 "recordsFiltered" => 1,
									 "data" => $data,
				 );
				 //output to json format
				 echo json_encode($output);
			 }else{
				 $this->load->view('index', $page_data);
			 }
		}

		/** *Bahasa* **/

		public function bahasa($param1='',$param2='')
		{
			if ($this->session->userdata('login') != 'A')
					$this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');

			$page_data['page_action'] = 'list';
			$page_data['page_title'] = 'Data Bahasa';
			$page_data['page_access'] = "admin";
			$page_data['page_name'] = 'bahasa';
			$page_data['page_now'] = 'Data Referensi';

			if ($param1 == 'submit') {
				$data['id'] = $this->input->post('id');
				$data['nama'] = $this->input->post('nama');
				$data['no_urut'] = $this->input->post('no_urut');
				if($data['id']==''||$data['nama']==''|| $data['no_urut']==''){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-warning');
				$this->session->set_flashdata('flash_message', 'Empty Field');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
				//redirect(base_url() . 'admin/kategori_buku/tambah', 'refresh');
				}else{
					$buku=$this->md_siperpus_bahasa->getBahasaById($this->input->post('id'));
					if($buku){
						//Id duplicate
						$this->session->set_flashdata('alert', 'alert-warning');
						$this->session->set_flashdata('flash_message', 'Bahasa telah ada, bahasa gagal dibuat');
						echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "ID telah dipakai, bahasa gagal dibuat"));
						//redirect(base_url() . 'admin/kategori_buku', 'refresh');
					}else {
						$this->md_siperpus_bahasa->addBahasa($data);
						$this->session->set_flashdata('alert', 'alert-success');
						$this->session->set_flashdata('flash_message', 'Bahasa Sukses dibuat');
						echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Bahasa Sukses dibuat"));
						//redirect(base_url() . 'admin/kategori_buku', 'refresh');
				 }
				}
			}else if ($param1 == 'update') {
				$id1=$this->input->post('id1');
				$data['id'] = $this->input->post('id');
				$data['nama'] = $this->input->post('nama');
				$data['no_urut'] = $this->input->post('no_urut');
				if($data['id']==''||$data['nama']==''|| $data['no_urut']==''){
					//Empty Field
					$this->session->set_flashdata('alert', 'alert-warning');
					$this->session->set_flashdata('flash_message', 'Empty Field');
					echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));//redirect(base_url() . 'admin/kategori_buku/edit', 'refresh');
				}else{
					$this->md_siperpus_bahasa->updateBahasa($id1, $data);
					$this->session->set_flashdata('alert', 'alert-success');
					$this->session->set_flashdata('flash_message', 'Bahasa Sukses diedit');
					echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Bahasa Sukses diedit"));//redirect(base_url() . 'admin/kategori_buku', 'refresh');
				}
			}elseif ($param1=='hapus') {
				$this->md_siperpus_bahasa->hapusBahasa($param2);
				$this->session->set_flashdata('alert', 'alert-success');
				$this->session->set_flashdata('flash_message', 'Bahasa Sukses Dihapus');
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Bahasa Sukses Dihapus"));//redirect(base_url() . 'admin/kategori_buku', 'refresh');
			}
			 else if($param1 =='edit' && $param2 !=''){
				// $page_data['data']=$this->md_siperpus_kategori_buku->getKategoriById($param2);
				// $page_data['page_action'] = $param1;
				// $page_data['page_title'] = 'Edit Kategori Buku';
				$data = $this->md_siperpus_bahasa->getBahasaById($param2);
				echo json_encode($data);
			 }else if($param1 =='list'){
				 $data = array();
				 $no = 0;
				 $list=$this->md_siperpus_bahasa->getBahasaAll();
				 foreach ($list as $row) {
					 $no++;
					 $arr = array();
					 $arr[] = $no;
					 $arr[] = $row->id;
					 $arr[] = $row->nama;
					 $arr[] = $row->no_urut;
					 $arr[] = '<div class="m-dropdown m-dropdown--up m-dropdown--inline  m-dropdown--arrow" data-dropdown-toggle="click"><a href="#" class="m-dropdown__toggle btn btn-success dropdown-toggle"><i class="fa fa-cogs"></i> Action</a><div class="m-dropdown__wrapper"><span class="m-dropdown__arrow m-dropdown__arrow--left"></span><div class="m-dropdown__inner"><div class="m-dropdown__body"><div class="m-dropdown__content"><ul class="m-nav"><li class="m-nav__item"><a  class="m-nav__link" href="javascript:void(0)" title="Edit" onclick="edit_buku('."'".$row->id."'".')"><button type="button" class="m-btn btn btn-info">Edit <i class="la la-files-o"></i></button></a></li><li class="m-nav__item"><a class="m-nav__link" href="javascript:void(0)" title="Delete" onclick="delete_buku('."'".$row->id."'".')"><button type="button" class="m-btn btn btn-danger">Hapus <i class="la la-files-o"></i></button></a></li></ul></div></div></div></div></div>';
					 $data[] = $arr;
				 }
				 $output = array( "draw" => 1,
									 "recordsTotal" => 1,
									 "recordsFiltered" => 1,
									 "data" => $data,
				 );
				 //output to json format
				 echo json_encode($output);
			 }else{
				 $this->load->view('index', $page_data);
			 }
		}

		/** *Asal Buku* **/

		public function asal_buku($param1='',$param2='')
		{
			if ($this->session->userdata('login') != 'A')
					$this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');

			$page_data['page_action'] = 'list';
			$page_data['page_title'] = 'Data Asal Buku';
			$page_data['page_access'] = "admin";
			$page_data['page_name'] = 'asal_buku';
			$page_data['page_now'] = 'Data Referensi';

			if ($param1 == 'submit') {
				$data['id'] = $this->input->post('id');
				$data['nama'] = $this->input->post('nama');
				if($data['id']==''||$data['nama']==''){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-warning');
				$this->session->set_flashdata('flash_message', 'Empty Field');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
				//redirect(base_url() . 'admin/kategori_buku/tambah', 'refresh');
				}else{
					$buku=$this->md_siperpus_asal_buku->getAsalBukuById($this->input->post('id'));
					if($buku){
						//Id duplicate
						$this->session->set_flashdata('alert', 'alert-warning');
						$this->session->set_flashdata('flash_message', 'Asal Buku telah ada, Asal Buku gagal dibuat');
						echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "ID telah dipakai, Asal Buku gagal dibuat"));
						//redirect(base_url() . 'admin/kategori_buku', 'refresh');
					}else {
						$this->md_siperpus_asal_buku->addAsalBuku($data);
						$this->session->set_flashdata('alert', 'alert-success');
						$this->session->set_flashdata('flash_message', 'Asal Buku Sukses dibuat');
						echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Asal Buku Sukses dibuat"));
						//redirect(base_url() . 'admin/kategori_buku', 'refresh');
				 }
				}
			}else if ($param1 == 'update') {
				$id1=$this->input->post('id1');
				$data['id'] = $this->input->post('id');
				$data['nama'] = $this->input->post('nama');
				if($data['id']==''||$data['nama']==''){
					//Empty Field
					$this->session->set_flashdata('alert', 'alert-warning');
					$this->session->set_flashdata('flash_message', 'Empty Field');
					echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));//redirect(base_url() . 'admin/kategori_buku/edit', 'refresh');
				}else{
					$this->md_siperpus_asal_buku->updateAsalBuku($id1, $data);
					$this->session->set_flashdata('alert', 'alert-success');
					$this->session->set_flashdata('flash_message', 'Asal Buku Sukses diedit');
					echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Asal Buku Sukses diedit"));//redirect(base_url() . 'admin/kategori_buku', 'refresh');
				}
			}elseif ($param1=='hapus') {
				$this->md_siperpus_asal_buku->hapusAsalBuku($param2);
				$this->session->set_flashdata('alert', 'alert-success');
				$this->session->set_flashdata('flash_message', 'Asal Buku Sukses Dihapus');
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Asal Buku Sukses Dihapus"));//redirect(base_url() . 'admin/kategori_buku', 'refresh');
			}
			 else if($param1 =='edit' && $param2 !=''){
				// $page_data['data']=$this->md_siperpus_kategori_buku->getKategoriById($param2);
				// $page_data['page_action'] = $param1;
				// $page_data['page_title'] = 'Edit Kategori Buku';
				$data = $this->md_siperpus_asal_buku->getAsalBukuById($param2);
				echo json_encode($data);
			 }else if($param1 =='list'){
				 $data = array();
				 $no = 0;
				 $list=$this->md_siperpus_asal_buku->getAsalBukuAll();
				 foreach ($list as $row) {
					 $no++;
					 $arr = array();
					 $arr[] = $no;
					 $arr[] = $row->id;
					 $arr[] = $row->nama;
					 $arr[] = '<div class="m-dropdown m-dropdown--up m-dropdown--inline  m-dropdown--arrow" data-dropdown-toggle="click"><a href="#" class="m-dropdown__toggle btn btn-success dropdown-toggle"><i class="fa fa-cogs"></i> Action</a><div class="m-dropdown__wrapper"><span class="m-dropdown__arrow m-dropdown__arrow--left"></span><div class="m-dropdown__inner"><div class="m-dropdown__body"><div class="m-dropdown__content"><ul class="m-nav"><li class="m-nav__item"><a  class="m-nav__link" href="javascript:void(0)" title="Edit" onclick="edit_buku('."'".$row->id."'".')"><button type="button" class="m-btn btn btn-info">Edit <i class="la la-files-o"></i></button></a></li><li class="m-nav__item"><a class="m-nav__link" href="javascript:void(0)" title="Delete" onclick="delete_buku('."'".$row->id."'".')"><button type="button" class="m-btn btn btn-danger">Hapus <i class="la la-files-o"></i></button></a></li></ul></div></div></div></div></div>';
					 $data[] = $arr;
				 }
				 $output = array( "draw" => 1,
									 "recordsTotal" => 1,
									 "recordsFiltered" => 1,
									 "data" => $data,
				 );
				 //output to json format
				 echo json_encode($output);
			 }else{
				 $this->load->view('index', $page_data);
			 }
		}

		/** *Penerbit* **/

		public function penerbit($param1='',$param2='')
		{
			if ($this->session->userdata('login') != 'A')
					$this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');

			$page_data['page_action'] = 'list';
			$page_data['page_title'] = 'Data Penerbit';
			$page_data['page_access'] = "admin";
			$page_data['page_name'] = 'penerbit';
			$page_data['page_now'] = 'Data Referensi';

			if ($param1 == 'submit') {
				$data['kd_penerbit'] = $this->input->post('kd_penerbit');
				$data['nama_penerbit'] = $this->input->post('nama_penerbit');
				$data['kota'] = $this->input->post('kota');
				if($data['nama_penerbit']==''||$data['kota']==''){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-warning');
				$this->session->set_flashdata('flash_message', 'Empty Field');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
				//redirect(base_url() . 'admin/kategori_buku/tambah', 'refresh');
				}else{
					$this->md_siperpus_penerbit->addPenerbit($data);
					$this->session->set_flashdata('alert', 'alert-success');
					$this->session->set_flashdata('flash_message', 'Penerbit Sukses dibuat');
					echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Penerbit Sukses dibuat"));
					//redirect(base_url() . 'admin/kategori_buku', 'refresh');
				}
			}else if ($param1 == 'update') {
				$id1=$this->input->post('id1');
				$data['kd_penerbit'] = $id1;
				$data['nama_penerbit'] = $this->input->post('nama_penerbit');
				$data['kota'] = $this->input->post('kota');
				if($data['nama_penerbit']==''||$data['kota']==''){
					//Empty Field
					$this->session->set_flashdata('alert', 'alert-warning');
					$this->session->set_flashdata('flash_message', 'Empty Field');
					echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));//redirect(base_url() . 'admin/kategori_buku/edit', 'refresh');
				}else{
					$this->md_siperpus_penerbit->updatePenerbit($id1, $data);
					$this->session->set_flashdata('alert', 'alert-success');
					$this->session->set_flashdata('flash_message', 'Asal Buku Sukses diedit');
					echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Penerbit Sukses diedit"));//redirect(base_url() . 'admin/kategori_buku', 'refresh');
				}
			}elseif ($param1=='hapus') {
				$this->md_siperpus_penerbit->hapusPenerbit($param2);
				$this->session->set_flashdata('alert', 'alert-success');
				$this->session->set_flashdata('flash_message', 'Asal Buku Sukses Dihapus');
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Penerbit Sukses Dihapus"));//redirect(base_url() . 'admin/kategori_buku', 'refresh');
			}
			 else if($param1 =='edit' && $param2 !=''){
				// $page_data['data']=$this->md_siperpus_kategori_buku->getKategoriById($param2);
				// $page_data['page_action'] = $param1;
				// $page_data['page_title'] = 'Edit Kategori Buku';
				$data = $this->md_siperpus_penerbit->getPenerbitById($param2);
				echo json_encode($data);
			 }else if($param1 =='list'){
				 $data = array();
				 $no = 0;
				 $list=$this->md_siperpus_penerbit->getPenerbitAll();
				 foreach ($list as $row) {
					 $no++;
					 $arr = array();
					 $arr[] = $no;
					 $arr[] = $row->kd_penerbit;
					 $arr[] = $row->nama_penerbit;
					 $arr[] = $row->kota;
					 $arr[] = '<div class="m-dropdown m-dropdown--up m-dropdown--inline  m-dropdown--arrow" data-dropdown-toggle="click"><a href="#" class="m-dropdown__toggle btn btn-success dropdown-toggle"><i class="fa fa-cogs"></i> Action</a><div class="m-dropdown__wrapper"><span class="m-dropdown__arrow m-dropdown__arrow--left"></span><div class="m-dropdown__inner"><div class="m-dropdown__body"><div class="m-dropdown__content"><ul class="m-nav"><li class="m-nav__item"><a  class="m-nav__link" href="javascript:void(0)" title="Edit" onclick="edit_buku('."'".$row->kd_penerbit."'".')"><button type="button" class="m-btn btn btn-info">Edit <i class="la la-files-o"></i></button></a></li><li class="m-nav__item"><a class="m-nav__link" href="javascript:void(0)" title="Delete" onclick="delete_buku('."'".$row->kd_penerbit."'".')"><button type="button" class="m-btn btn btn-danger">Hapus <i class="la la-files-o"></i></button></a></li></ul></div></div></div></div></div>';
					 $data[] = $arr;
				 }
				 $output = array( "draw" => 1,
									 "recordsTotal" => 1,
									 "recordsFiltered" => 1,
									 "data" => $data,
				 );
				 //output to json format
				 echo json_encode($output);
			 }else{
				 $this->load->view('index', $page_data);
			 }
		}
		/** *Keperluan SPPBL* **/

		public function keperluan_sbppl($param1='',$param2='')
		{
			if ($this->session->userdata('login') != 'A')
					$this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');

			$page_data['page_action'] = 'list';
			$page_data['page_title'] = 'Keperluan SBPPL';
			$page_data['page_access'] = "admin";
			$page_data['page_name'] = 'keperluan_sbppl';
			$page_data['page_now'] = 'Data Referensi';

			if ($param1 == 'submit') {
				$data['nama'] = $this->input->post('nama');
				$data['no_urut'] = $this->input->post('no_urut');
				if($data['nama']==''|| $data['no_urut']==''){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-warning');
				$this->session->set_flashdata('flash_message', 'Empty Field');
				echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));
				//redirect(base_url() . 'admin/kategori_buku/tambah', 'refresh');
				}else{
					$this->md_siperpus_keperluan_sbppl->addSbppl($data);
					$this->session->set_flashdata('alert', 'alert-success');
					$this->session->set_flashdata('flash_message', 'SBPPL Sukses dibuat');
					echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "SBPPL Sukses dibuat"));
					//redirect(base_url() . 'admin/kategori_buku', 'refresh');
				}
			}else if ($param1 == 'update') {
				$id1=$this->input->post('id1');
				$data['id'] = $id1;
				$data['nama'] = $this->input->post('nama');
				$data['no_urut'] = $this->input->post('no_urut');
				if($data['nama']==''|| $data['no_urut']==''){
					//Empty Field
					$this->session->set_flashdata('alert', 'alert-warning');
					$this->session->set_flashdata('flash_message', 'Empty Field');
					echo json_encode(array("status" => TRUE,"alert" => "alert-danger","msg" => "Empty Field"));//redirect(base_url() . 'admin/kategori_buku/edit', 'refresh');
				}else{
					$this->md_siperpus_keperluan_sbppl->updateSbppl($id1, $data);
					$this->session->set_flashdata('alert', 'alert-success');
					$this->session->set_flashdata('flash_message', 'SBPPL Sukses diedit');
					echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "SBPPL Sukses diedit"));//redirect(base_url() . 'admin/kategori_buku', 'refresh');
				}
			}elseif ($param1=='hapus') {
				$this->md_siperpus_keperluan_sbppl->hapusSbppl($param2);
				$this->session->set_flashdata('alert', 'alert-success');
				$this->session->set_flashdata('flash_message', 'SBPPL Sukses Dihapus');
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "SBPPL Sukses Dihapus"));//redirect(base_url() . 'admin/kategori_buku', 'refresh');
			}
			 else if($param1 =='edit' && $param2 !=''){
				// $page_data['data']=$this->md_siperpus_kategori_buku->getKategoriById($param2);
				// $page_data['page_action'] = $param1;
				// $page_data['page_title'] = 'Edit Kategori Buku';
				$data = $this->md_siperpus_keperluan_sbppl->getSbpplById($param2);
				echo json_encode($data);
			 }else if($param1 =='list'){
				 $data = array();
				 $no = 0;
				 $list=$this->md_siperpus_keperluan_sbppl->getSbpplAll();
				 foreach ($list as $row) {
					 $no++;
					 $arr = array();
					 $arr[] = $no;
					 $arr[] = $row->id;
					 $arr[] = $row->nama;
					 $arr[] = $row->no_urut;
					 $arr[] = '<div class="m-dropdown m-dropdown--up m-dropdown--inline  m-dropdown--arrow" data-dropdown-toggle="click"><a href="#" class="m-dropdown__toggle btn btn-success dropdown-toggle"><i class="fa fa-cogs"></i> Action</a><div class="m-dropdown__wrapper"><span class="m-dropdown__arrow m-dropdown__arrow--left"></span><div class="m-dropdown__inner"><div class="m-dropdown__body"><div class="m-dropdown__content"><ul class="m-nav"><li class="m-nav__item"><a  class="m-nav__link" href="javascript:void(0)" title="Edit" onclick="edit_buku('."'".$row->id."'".')"><button type="button" class="m-btn btn btn-info">Edit <i class="la la-files-o"></i></button></a></li><li class="m-nav__item"><a class="m-nav__link" href="javascript:void(0)" title="Delete" onclick="delete_buku('."'".$row->id."'".')"><button type="button" class="m-btn btn btn-danger">Hapus <i class="la la-files-o"></i></button></a></li></ul></div></div></div></div></div>';
					 $data[] = $arr;
				 }
				 $output = array( "draw" => 1,
									 "recordsTotal" => 1,
									 "recordsFiltered" => 1,
									 "data" => $data,
				 );
				 //output to json format
				 echo json_encode($output);
			 }else{
				 $this->load->view('index', $page_data);
			 }
		}

		/** *Proram Studi* **/

		public function program_studi($param1='',$param2='')
		{
			if ($this->session->userdata('login') != 'A')
					$this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');

			$page_data['page_action'] = 'list';
			$page_data['page_title'] = 'Program Studi';
			$page_data['page_access'] = "admin";
			$page_data['page_name'] = 'program_studi';
			$page_data['page_now'] = 'Data Referensi';

			if($param1 =='list'){
				 $data = array();
				 $no = 0;
				 $list=$this->md_vwprodi->getProdiAll();
				 foreach ($list as $row) {
					 $no++;
					 $arr = array();
					 $arr[] = $no;
					 $arr[] = $row->kodemspst;
					 $arr[] = $row->nmmspst;
					 $data[] = $arr;
				 }
				 $output = array( "draw" => 1,
									 "recordsTotal" => 1,
									 "recordsFiltered" => 1,
									 "data" => $data,
				 );
				 //output to json format
				 echo json_encode($output);
			 }else{
				 $this->load->view('index', $page_data);
			 }
		}
		/** *Mata Kuliah* **/

		public function matakuliah($param1='',$param2='')
		{
			if ($this->session->userdata('login') != 'A')
					$this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');

			$page_data['page_action'] = 'list';
			$page_data['page_title'] = 'Data Mata Kuliah';
			$page_data['page_access'] = "admin";
			$page_data['page_name'] = 'matakuliah';
			$page_data['page_now'] = 'Data Referensi';

			if($param1 =='list'){
				 $data = array();
				 $no = 0;
				 $list=$this->md_siperpus_matakuliah->getMatakuliahAll();
				 foreach ($list as $row) {
					 $no++;
					 $arr = array();
					 $arr[] = $no;
					 $arr[] = $row->kodetbkmk;
					 $arr[] = $row->nmtbkmk;
					 $arr[] = $row->pengajartbkmk;
					 $arr[] = $row->gelarpengajartbkmk;
					 $arr[] = $row->nmprodi;
					 $data[] = $arr;
				 }
				 $output = array( "draw" => 1,
									 "recordsTotal" => 1,
									 "recordsFiltered" => 1,
									 "data" => $data,
				 );
				 //output to json format
				 echo json_encode($output);
			 }else{
				 $this->load->view('index', $page_data);
			 }
		}

		public function data_buku($param1='',$param2='')
		{
			if ($this->session->userdata('login') != 'A')
					$this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');

			$page_data['page_action'] = 'list';
			$page_data['page_title'] = 'Data Data Buku';
			$page_data['page_access'] = "admin";
			$page_data['page_name'] = 'data_buku';
			$page_data['page_now'] = 'Buku & Inventarisasi';

			if ($param1=='hapus') {
				$this->md_siperpus_data_buku->hapusDataBuku($param2);
				$this->session->set_flashdata('alert', 'alert-success');
				$this->session->set_flashdata('flash_message', 'Data Buku Sukses Dihapus');
				echo json_encode(array("status" => TRUE,"alert" => "alert-focus","msg" => "Data Buku Sukses Dihapus"));
			}elseif ($param1=='update') {
				$data = array('no_klas' => $this->input->post('no_klas'),
											'ISBN' => $this->input->post('isbn'),
											'idkategori' => $this->input->post('kategori_buku'),
											'judul' => $this->input->post('judul'),
											'cetakkatalog_judulpenggal' => $this->input->post('cetakkatalog_judulpenggal'),
											'judulasli' => $this->input->post('judulasli'),
											'allow_review' => $this->input->post('allow_review'),
											'deskripsi' => $this->input->post('deskripsi'),
											'penulis' => $this->input->post('penulis'),
											'penyadur' => $this->input->post('penyadur'),
											'penerjemah' => $this->input->post('penerjemah'),
											'penyusun' => $this->input->post('penyusun'),
											'penyunting' => $this->input->post('penyunting'),
											'illustrator' => $this->input->post('illustrator'),
											'editor' => $this->input->post('editor'),
											'edisi' => $this->input->post('edisi'),
											'cetakan' => $this->input->post('cetakan'),
											'kd_penerbit' => $this->input->post('penerbit'),
											'thn_terbit' => $this->input->post('thn_terbit'),
											'jilid' => $this->input->post('jilid'),
											'hlm_romawi' => $this->input->post('hlm_romawi'),
											'jml_hal' => $this->input->post('jml_hal'),
											'ilustrasi' => $this->input->post('ilustrasi'),
											'tabel' => $this->input->post('tabel'),
											'ukuran_fisik' => $this->input->post('ukuran_fisik'),
											'bibliografi' => $this->input->post('bibliografi'),
											'indeks' => $this->input->post('indeks'),
											'bahasa' => $this->input->post('bahasa'),
											'no_rak' => $this->input->post('no_rak'),
											'seri' => $this->input->post('seri'),
											'tajuk' => $this->input->post('tajuk'),
											'tajuksubyek' => $this->input->post('tajuksubyek'),
											'tanggal' => $date->format('Y-m-d H:i:s')
											//'matkul' => $this->input->post('matkul')
			 );
			 if ($data['ilustrasi']=='') {$data['ilustrasi']=0;}
 			 if ($data['tabel']=='') {$data['tabel']=0;}
 			 if ($data['allow_review']=='') {$data['allow_review']=0;}
 			 if($data['no_klas']==''||$data['judul']==''|| $data['penulis']==''){
 				//Empty Field
 				$this->session->set_flashdata('alert', 'alert-warning');
 				$this->session->set_flashdata('flash_message', 'Empty Field');
 				redirect(base_url() . 'admin/data_buku/edit', 'refresh');
 				}else{
 					  $this->md_siperpus_data_buku->updateDataBuku($param2, $data);
 						$this->session->set_flashdata('alert', 'alert-success');
 						$this->session->set_flashdata('flash_message', 'Data Buku Sukses diedit');
 						redirect(base_url() . 'admin/data_buku', 'refresh');
 				}

			}
			elseif ($param1=='edit') {
				 $page_data['data']=$this->md_siperpus_data_buku->getDataBukuByISBN($param2);
				 $page_data['data']['kel_buku']=$this->md_siperpus_kategori_buku->getKategoriBukuAll();
				 $page_data['data']['penerbit']=$this->md_siperpus_penerbit->getPenerbitAll();
				 $page_data['data']['bahasa']=$this->md_siperpus_bahasa->getBahasaAll();
				 $page_data['page_action'] = "edit";
				 $page_data['page_title'] = 'Tambah Data Buku';
				 $this->load->view('index', $page_data);
			}elseif($param1 =='list'){
				 $data = array();
				 $no = 0;
				 $list=$this->md_siperpus_data_buku->getDataBukuAll();
				 foreach ($list as $row) {
					 $no++;
					 $arr = array();
					 $arr[] = $no;
					 $arr[] = $row->no_klas;
					 $arr[] = $row->judul;
					 $arr[] = $row->penulis;
					 $arr[] = $row->penerbit;
					 $arr[] = $row->jml_buku;
					 $arr[] = "-";
					 $arr[] = "-";
					 $arr[] = "-";
					 $arr[] = '<div class="m-dropdown m-dropdown--up m-dropdown--inline  m-dropdown--arrow" data-dropdown-toggle="click"><a href="#" class="m-dropdown__toggle btn btn-success dropdown-toggle"><i class="fa fa-cogs"></i> Action</a><div class="m-dropdown__wrapper"><span class="m-dropdown__arrow m-dropdown__arrow--left"></span><div class="m-dropdown__inner"><div class="m-dropdown__body"><div class="m-dropdown__content"><ul class="m-nav"><li class="m-nav__item"><a class="m-nav__link" href="javascript:void(0)" title="Set Inv" onclick="set_inv('."'".$row->ISBN."'".')"><button type="button" class="m-btn btn btn-danger">Set Inventori<i class="la la-files-o"></i></button></a></li><li class="m-nav__item"><a  class="m-nav__link" href="javascript:void(0)" title="Edit" onclick="edit('."'".$row->ISBN."'".')"><button type="button" class="m-btn btn btn-info">Edit <i class="la la-files-o"></i></button></a></li><li class="m-nav__item"><a class="m-nav__link" href="javascript:void(0)" title="Delete" onclick="delete_buku('."'".$row->ISBN."'".')"><button type="button" class="m-btn btn btn-danger">Hapus <i class="la la-files-o"></i></button></a></li></ul></div></div></div></div></div>';
					 $data[] = $arr;
				 }
				 $output = array( "draw" => 1,
									 "recordsTotal" => 1,
									 "recordsFiltered" => 1,
									 "data" => $data,
				 );
				 //output to json format
				 echo json_encode($output);
			 }else{
				 $this->load->view('index', $page_data);
			 }
		}
		/** *Data Buku* **/

		// function data_buku($param1='',$param2='')
		// {
		// 	if ($this->session->userdata('login') != 'A')
		// 			$this->logout();
		//
		// 	$date = new DateTime();
		// 	$id=$this->session->userdata('user_id');
		//
    //   $page_data['page_action'] = 'list';
    //   $page_data['data']=$this->md_siperpus_data_buku->getDataBukuAll();
    //   $page_data['page_title'] = 'Data Buku';
		//
		// 	if ($param1 == 'update') {
		// 		$data = array('no_klas' => $this->input->post('no_klas'),
		// 									'ISBN' => $this->input->post('isbn'),
		// 									'idkategori' => $this->input->post('kategori_buku'),
		// 									'judul' => $this->input->post('judul'),
		// 									'cetakkatalog_judulpenggal' => $this->input->post('cetakkatalog_judulpenggal'),
		// 									'judulasli' => $this->input->post('judulasli'),
		// 									'allow_review' => $this->input->post('allow_review'),
		// 									'deskripsi' => $this->input->post('deskripsi'),
		// 									'penulis' => $this->input->post('penulis'),
		// 									'penyadur' => $this->input->post('penyadur'),
		// 									'penerjemah' => $this->input->post('penerjemah'),
		// 									'penyusun' => $this->input->post('penyusun'),
		// 									'penyunting' => $this->input->post('penyunting'),
		// 									'illustrator' => $this->input->post('illustrator'),
		// 									'editor' => $this->input->post('editor'),
		// 									'edisi' => $this->input->post('edisi'),
		// 									'cetakan' => $this->input->post('cetakan'),
		// 									'kd_penerbit' => $this->input->post('penerbit'),
		// 									'thn_terbit' => $this->input->post('thn_terbit'),
		// 									'jilid' => $this->input->post('jilid'),
		// 									'hlm_romawi' => $this->input->post('hlm_romawi'),
		// 									'jml_hal' => $this->input->post('jml_hal'),
		// 									'ilustrasi' => $this->input->post('ilustrasi'),
		// 									'tabel' => $this->input->post('tabel'),
		// 									'ukuran_fisik' => $this->input->post('ukuran_fisik'),
		// 									'bibliografi' => $this->input->post('bibliografi'),
		// 									'indeks' => $this->input->post('indeks'),
		// 									'bahasa' => $this->input->post('bahasa'),
		// 									'no_rak' => $this->input->post('no_rak'),
		// 									'seri' => $this->input->post('seri'),
		// 									'tajuk' => $this->input->post('tajuk'),
		// 									'tajuksubyek' => $this->input->post('tajuksubyek'),
		// 									'tanggal' => $date->format('Y-m-d H:i:s')
		// 									//'matkul' => $this->input->post('matkul')
		// 	 );
		// 	 if ($data['ilustrasi']=='') {$data['ilustrasi']=0;}
		// 	 if ($data['tabel']=='') {$data['tabel']=0;}
		// 	 if ($data['allow_review']=='') {$data['allow_review']=0;}
		// 	 if($data['no_klas']==''||$data['judul']==''|| $data['penulis']==''){
		// 		//Empty Field
		// 		$this->session->set_flashdata('alert', 'alert-warning');
		// 		$this->session->set_flashdata('flash_message', 'Empty Field');
		// 		redirect(base_url() . 'admin/data_buku/edit', 'refresh');
		// 		}else{
		// 			  $this->md_siperpus_data_buku->updateDataBuku($param2, $data);
		// 				$this->session->set_flashdata('alert', 'alert-success');
		// 				$this->session->set_flashdata('flash_message', 'Data Buku Sukses diedit');
		// 				redirect(base_url() . 'admin/data_buku', 'refresh');
		// 		}
		// 	}elseif ($param1 == 'submit') {
		// 		$data = array('no_klas' => $this->input->post('no_klas'),
		// 									'ISBN' => $this->input->post('isbn'),
		// 									'idkategori' => $this->input->post('kategori_buku'),
		// 									'judul' => $this->input->post('judul'),
		// 									'cetakkatalog_judulpenggal' => $this->input->post('cetakkatalog_judulpenggal'),
		// 									'judulasli' => $this->input->post('judulasli'),
		// 									'allow_review' => $this->input->post('allow_review'),
		// 									'deskripsi' => $this->input->post('deskripsi'),
		// 									'penulis' => $this->input->post('penulis'),
		// 									'penyadur' => $this->input->post('penyadur'),
		// 									'penerjemah' => $this->input->post('penerjemah'),
		// 									'penyusun' => $this->input->post('penyusun'),
		// 									'penyunting' => $this->input->post('penyunting'),
		// 									'illustrator' => $this->input->post('illustrator'),
		// 									'editor' => $this->input->post('editor'),
		// 									'edisi' => $this->input->post('edisi'),
		// 									'cetakan' => $this->input->post('cetakan'),
		// 									'kd_penerbit' => $this->input->post('penerbit'),
		// 									'thn_terbit' => $this->input->post('thn_terbit'),
		// 									'jilid' => $this->input->post('jilid'),
		// 									'hlm_romawi' => $this->input->post('hlm_romawi'),
		// 									'jml_hal' => $this->input->post('jml_hal'),
		// 									'ilustrasi' => $this->input->post('ilustrasi'),
		// 									'tabel' => $this->input->post('tabel'),
		// 									'ukuran_fisik' => $this->input->post('ukuran_fisik'),
		// 									'bibliografi' => $this->input->post('bibliografi'),
		// 									'indeks' => $this->input->post('indeks'),
		// 									'bahasa' => $this->input->post('bahasa'),
		// 									'no_rak' => $this->input->post('no_rak'),
		// 									'seri' => $this->input->post('seri'),
		// 									'tajuk' => $this->input->post('tajuk'),
		// 									'tajuksubyek' => $this->input->post('tajuksubyek'),
		// 									'tanggal' => $date->format('Y-m-d H:i:s')
		// 									//'matkul' => $this->input->post('matkul')
		// 	 );
		// 	 if ($data['ilustrasi']=='') {$data['ilustrasi']=0;}
		// 	 if ($data['tabel']=='') {$data['tabel']=0;}
		// 	 if ($data['allow_review']=='') {$data['allow_review']=0;}
		// 	 if($data['no_klas']==''||$data['judul']==''|| $data['penulis']==''){
		// 		//Empty Field
		// 		$this->session->set_flashdata('alert', 'alert-warning');
		// 		$this->session->set_flashdata('flash_message', 'Empty Field'.$data['no_klas'].'a'.$data['judul'].'a'.$data['penulis'].'a'.$data['penerbit']);
		// 		redirect(base_url() . 'admin/data_buku/tambah', 'refresh');
		// 		}else{
		// 			  $this->md_siperpus_data_buku->addDataBuku($data);
		// 				$this->session->set_flashdata('alert', 'alert-success');
		// 				$this->session->set_flashdata('flash_message', 'Data Buku Sukses dibuat');
		// 				redirect(base_url() . 'admin/data_buku', 'refresh');
		// 		}
	  //    }elseif($param1 =='tambah'){
		// 		 $page_data['data']['kel_buku']=$this->md_siperpus_kategori_buku->getKategoriBukuAll();
		// 		 $page_data['data']['penerbit']=$this->md_siperpus_penerbit->getPenerbitAll();
		// 		 $page_data['data']['bahasa']=$this->md_siperpus_bahasa->getBahasaAll();
		// 		 $page_data['page_action'] = $param1;
		// 		 $page_data['page_title'] = 'Tambah Data Buku';
		// 	 }
		// 	 elseif($param1 =='edit'){
		// 		 $page_data['data']['kel_buku']=$this->md_siperpus_kategori_buku->getKategoriBukuAll();
		// 		 $page_data['data']['penerbit']=$this->md_siperpus_penerbit->getPenerbitAll();
		// 		 $page_data['data']['bahasa']=$this->md_siperpus_bahasa->getBahasaAll();
		// 		 $page_data['page_action'] = $param1;
		// 		 $page_data['page_title'] = 'Tambah Data Buku';
		// 	 }elseif ($param1=='hapus') {
		// 		 $this->md_siperpus_data_buku->hapusDataBuku($param2);
	 // 			 $this->session->set_flashdata('alert', 'alert-success');
	 // 			 $this->session->set_flashdata('flash_message', 'Data Buku Sukses Dihapus');
	 // 			 redirect(base_url() . 'admin/data_buku', 'refresh');
		// 	 }
		//
		// 	$page_data['page_access'] = "admin";
    //   $page_data['page_name'] = 'data_buku';
    //   $page_data['page_now'] = 'Buku & Inventarisasi';
    //   $this->load->view('index', $page_data);
		// }

		/** *inventaris* **/
		function inventaris($param1='',$param2='')
		{
			if ($this->session->userdata('login') != 'A')
					$this->logout();

			$date = new DateTime();
			$id=$this->session->userdata('user_id');

      $page_data['page_action'] = 'list';
      $page_data['data']=$this->md_siperpus_inventaris->getInventarisAll();
      $page_data['page_title'] = 'inventaris';

			if ($param1 == 'submit') {
				$data['nama'] = $this->input->post('nama');
				$data['no_urut'] = $this->input->post('no_urut');
				if($data['nama']==''||$data['no_urut']==''){
				//Empty Field
				$this->session->set_flashdata('alert', 'alert-warning');
				$this->session->set_flashdata('flash_message', 'Empty Field');
				redirect(base_url() . 'admin/keperluan_sbppl/tambah', 'refresh');
				}else{
					  $this->md_siperpus_keperluan_sbppl->addSbppl($data);
						$this->session->set_flashdata('alert', 'alert-success');
						$this->session->set_flashdata('flash_message', 'Keperluan Sbppl Sukses dibuat');
						redirect(base_url() . 'admin/keperluan_sbppl', 'refresh');
				}
	     }elseif ($param1 == 'update' && $param2 != '') {
				//$data['id'] = $this->input->post('id');
				$data['nama'] = $this->input->post('nama');
				$data['no_urut'] = $this->input->post('no_urut');
				if($data['nama']==''||$data['no_urut']==''){
					//Empty Field
					$this->session->set_flashdata('alert', 'alert-warning');
					$this->session->set_flashdata('flash_message', 'Empty Field');
					redirect(base_url() . 'admin/keperluan_sbppl/edit', 'refresh');
				}else{
					$this->md_siperpus_keperluan_sbppl->updateSbppl($param2, $data);
					$this->session->set_flashdata('alert', 'alert-success');
					$this->session->set_flashdata('flash_message', 'Keperluan Sbppl Sukses diedit');
					redirect(base_url() . 'admin/keperluan_sbppl', 'refresh');
				}
			}elseif($param1 =='edit' && $param2 !=''){
				$page_data['data']=$this->md_siperpus_inventaris->getInventarisById($param2);
				$page_data['page_action'] = 'edit';
				$page_data['page_title'] = 'Edit Inventaris';
			 }

			$page_data['page_access'] = "admin";
      $page_data['page_name'] = 'inventaris';
      $page_data['page_now'] = 'Buku & Inventarisasi';
      $this->load->view('index', $page_data);
		}
}
