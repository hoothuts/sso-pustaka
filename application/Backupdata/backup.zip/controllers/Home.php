<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 function __construct() {
        parent::__construct();        
        $this->load->database();
       $this->load->library('pagination');
		$this->load->model('Md_siperpus_sysuser');
		$this->load->model('Md_siperpus_presensi');
		$this->load->model('Md_siperpus_buku_digital');
		$this->load->model('Md_siperpus_buku');
		$this->load->model('Md_siperpus_penerbit');
		date_default_timezone_set('Asia/Jakarta');     
        /* cash control */
        $this->output->set_header('Last-Modified: ' . gmdate("D, d M Y H:i:s") . ' GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
        $this->output->set_header('Pragma: no-cache');
        $this->output->set_header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
    }
	public function index()
	{
		$page_data['page_content']='dashboard';
		$this->load->view('front',$page_data);
	}
	function bukutamu()
	{
		$page_data['page_content']='bukutamu';
		$this->load->view('front',$page_data);
	}
	function digital_book()
	{
		$page_data['page_content']='dbook';
		$this->load->view('front',$page_data);
	}
	function penelusuran_buku()
	{
		$page_data['page_content']='pbuku';
		$this->load->view('front',$page_data);
	}
	function penelusuran_bukuprodi()
	{
		$page_data['page_content']='pbukuprodi';
		$this->load->view('front',$page_data);
	}
	function kontak()
	{
		$page_data['page_content']='kontak';
		$this->load->view('front',$page_data);
	}
	function loginform(){
		$this->load->view('login');
	}
	function login()
	{
		$config = array(
            array(
                'field' => 'login_type',
                'label' => 'Account Type',
                'rules' => 'required|xss_clean'
            ),
            array(
                'field' => 'username',
                'label' => 'Username',
                'rules' => 'required|xss_clean'
            ),
            array(
                'field' => 'password',
                'label' => 'Password',
                'rules' => 'required|xss_clean|callback__validate_login'
            )
        );
		 $this->form_validation->set_rules($config);
        $this->form_validation->set_message('_validate_login', ' Login failed!');
        $this->form_validation->set_error_delimiters('<div class="alert alert-error">
                    <button type="button" class="close" data-dismiss="alert">×</button>', '</div>');
       
        if ($this->form_validation->run() == FALSE) {
		    $this->load->view('login');
          
        } else {
            if ($this->session->userdata('login') == "A")
                redirect(base_url() . 'admin/dashboard', 'refresh');
            if ($this->session->userdata('login') == "C")
                redirect(base_url() . 'admin/dashboard', 'refresh');
            if ($this->session->userdata('login') == "K")
                redirect(base_url() . 'admin/dashboard', 'refresh');
            if ($this->session->userdata('login') == "P")
                redirect(base_url() . 'admin/dashboard', 'refresh');
            if ($this->session->userdata('login') == "R")
                redirect(base_url() . 'admin/dashboard', 'refresh');
            if ($this->session->userdata('login') == "S")
                redirect(base_url() . 'admin/dashboard', 'refresh');
            if ($this->session->userdata('login') == "V")
                redirect(base_url() . 'admin/dashboard', 'refresh');

        }
	}
	function _validate_login($str) {
        if ($this->input->post('username') == '') {
            $this->session->set_flashdata('flash_message', 'login_failed1');
            return FALSE;
        }
				//$sd= hash('sha1',preg_replace('/[^A-Za-z0-9\/\s,\s.\s-\s+\s?\s_\s)\s(\s@\s:\s#\s!\s*\s&\s>\s<\s=\s;\s"]/', '', $this->input->post('password')));
				$sd= preg_replace('/[^A-Za-z0-9\/\s,\s.\s-\s+\s?\s_\s)\s(\s@\s:\s#\s!\s*\s&\s>\s<\s=\s;\s"]/', '', $this->input->post('password'));
				$data = $this->Md_siperpus_sysuser->checkLogin($this->input->post('username'),$sd);
				//var_dump($data);
				if (count($data) > 0) {
					$row = $data[0];
					if ($row->idsysgroup == 'K') {
						$this->session->set_userdata('login_type', 'admin');
						$this->session->set_userdata('login', 'A');
						$this->session->set_userdata('idsys', $row->idsysuser);
						$this->session->set_userdata('username', $row->name);
						/*
						$date = new DateTime();
						
						$log['user_id']=$row->user_id;
						$log['tgl']=$date->format("Y-m-d H:i:s");
						$log['jenis_log']='admin';
						$log['jenis_akses']='LogIn';
						$log['status']=1;
						$log['keterangan']=$row->username.' Melakukan Login';
						$log['IP']=$_SERVER['REMOTE_ADDR'];
						$this->md_log->addLogBaru($log);
						*/
						redirect(base_url() . 'admin/dashboard', 'refresh');
					}
					return TRUE;
				} else {
					$this->session->set_flashdata('alert', 'alert-danger');
					$this->session->set_flashdata('flash_message', 'Login failed!');
					return FALSE;
				}
    }
	function login2()
	{
		if ($this->input->post('username') == '') {
            $this->session->set_flashdata('flash_message', 'login_failed1');
			redirect(base_url() . 'home', 'refresh');
        }
				//$sd= hash('sha1',preg_replace('/[^A-Za-z0-9\/\s,\s.\s-\s+\s?\s_\s)\s(\s@\s:\s#\s!\s*\s&\s>\s<\s=\s;\s"]/', '', $this->input->post('password')));
				$sd= preg_replace('/[^A-Za-z0-9\/\s,\s.\s-\s+\s?\s_\s)\s(\s@\s:\s#\s!\s*\s&\s>\s<\s=\s;\s"]/', '', $this->input->post('password'));
				$data = $this->Md_siperpus_sysuser->checkLogin($this->input->post('username'),$sd);
				//var_dump($data);
				if (count($data) > 0) {
					$row = $data[0];
					if ($row->idsysgroup == 'K') {
						$this->session->set_userdata('login_type', 'admin');
						$this->session->set_userdata('login', 'A');
						$this->session->set_userdata('idsys', $row->idsysuser);
						$this->session->set_userdata('username', $row->name);
						/*
						$date = new DateTime();
						
						$log['user_id']=$row->user_id;
						$log['tgl']=$date->format("Y-m-d H:i:s");
						$log['jenis_log']='admin';
						$log['jenis_akses']='LogIn';
						$log['status']=1;
						$log['keterangan']=$row->username.' Melakukan Login';
						$log['IP']=$_SERVER['REMOTE_ADDR'];
						$this->md_log->addLogBaru($log);
						*/
					}
					
					 if ($this->session->userdata('login') == "A")
						redirect(base_url() . 'admin/dashboard', 'refresh');
					if ($this->session->userdata('login') == "C")
						redirect(base_url() . 'admin/dashboard', 'refresh');
					if ($this->session->userdata('login') == "K")
						redirect(base_url() . 'admin/dashboard', 'refresh');
					if ($this->session->userdata('login') == "P")
						redirect(base_url() . 'admin/dashboard', 'refresh');
					if ($this->session->userdata('login') == "R")
						redirect(base_url() . 'admin/dashboard', 'refresh');
					if ($this->session->userdata('login') == "S")
						redirect(base_url() . 'admin/dashboard', 'refresh');
					if ($this->session->userdata('login') == "V")
						redirect(base_url() . 'admin/dashboard', 'refresh');
					
				} else {
					$this->session->set_flashdata('alert', 'alert-danger');
					$this->session->set_flashdata('flash_message', 'Login failed!');
					redirect(base_url() . 'home', 'refresh');
				}
	}
}
