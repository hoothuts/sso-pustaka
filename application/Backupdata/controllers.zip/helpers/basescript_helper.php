<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!--begin::Base Scripts -->
		<!-- end::Base Scripts -->
		<!--begin::Page Vendors -->
		<script src="<?php echo base_url();?>assets/vendors/custom/fullcalendar/fullcalendar.bundle.js" type="text/javascript"></script>
		<!-- begin::Page Snippets -->
		<script src="<?php echo base_url();?>assets/app/js/dashboard.js" type="text/javascript"></script>
			<script src="<?php echo base_url();?>assets/demo/default/custom/components/portlets/tools.js" type="text/javascript"></script>
	    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js" type="text/javascript"></script>
        <script src="https://cdn.datatables.net/responsive/2.2.0/js/dataTables.responsive.min.js" type="text/javascript"></script>