<div class="m-grid__item m-grid__item--fluid m-wrapper">
	<!-- BEGIN: Subheader -->
	<div class="m-subheader ">
		<div class="d-flex align-items-center">
			<div class="mr-auto">
				<h3 class="m-subheader__title m-subheader__title--separator">
					<?php echo $page_title;?>
				</h3>
				<ul class="m-subheader__breadcrumbs m-nav m-nav--inline">
					<li class="m-nav__item m-nav__item--home">
						<a href="<?php echo base_url();?>admin/dashboard" class="m-nav__link m-nav__link--icon">
							<i class="m-nav__link-icon la la-home"></i>
						</a>
					</li>
					<li class="m-nav__separator">
						-
					</li>
					<li class="m-nav__item">
						<a href="" class="m-nav__link">
							<span class="m-nav__link-text">
								Data Induk
							</span>
						</a>
					</li>
					<li class="m-nav__separator">
						-
					</li>
					<li class="m-nav__item">
						<a href="" class="m-nav__link">
							<span class="m-nav__link-text">
								<?php echo $page_title;?>
							</span>
						</a>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<!-- END: Subheader -->
	<div class="m-content">
		<div class="m-alert m-alert--icon m-alert--icon-solid m-alert--outline alert <?php echo $this->session->flashdata('alert')?> alert-dismissible fade" role="alert" id="alertbox" style="display:none">
			<div class="m-alert__icon">
				<i class="flaticon-exclamation-1"></i>
				<span></span>
			</div>
			<div class="m-alert__text">
				<?= $this->session->flashdata('flash_message') ?>
			</div>
		</div>
		<div class="m-portlet m-portlet--mobile">
			<div class="m-portlet__head">
				<div class="m-portlet__head-caption">
					<div class="m-portlet__head-title">
						<h3 class="m-portlet__head-text">
							<?php echo $page_title;?>
						</h3>
					</div>
				</div>
			</div>
			<div class="m-portlet__body">
				<!--begin: Search Form -->
				<div class="m-form m-form--label-align-right m--margin-top-20 m--margin-bottom-30">
					<div class="row align-items-center">
						<div class="col-xl-8 order-2 order-xl-1">
							<div class="form-group m-form__group row align-items-center">
								<div class="col-md-4">
									<select class="form-control m-bootstrap-select" id="m_form_nama">
										<option value=""></option>
										<option value="nis">Mahasiswa</option>
										<option value="nip">Dosen</option>
										<option value="noid">Anggota Luar</option>
									</select>
									<div class="d-md-none m--margin-bottom-10"></div>
								</div>
								<div class="col-md-4">
									<div class="m-input-icon m-input-icon--left">
										<input type="text" class="form-control m-input" placeholder="Search..." id="m_form_search">
										<span class="m-input-icon__icon m-input-icon__icon--left">
											<span>
												<i class="la la-search"></i>
											</span>
										</span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!--begin: Selected Rows Group Action Form -->
				<div class="m-form m-form--label-align-right m--margin-top-20 m--margin-bottom-30 collapse" id="m_datatable_group_action_form">
					<div class="row align-items-center">
						<div class="col-xl-12">
							<div class="m-form__group m-form__group--inline">
								<div class="m-form__label m-form__label-no-wrap">
									<label class="m--font-bold m--font-danger-">
										Selected
										<span id="m_datatable_selected_number"></span>
										records:
									</label>
								</div>
								<div class="m-form__control">
									<div class="btn-toolbar">
										<button id="generatecode" type="button" class="btn btn-accent btn-sm">
											Cetak Barcode
										</button>
										&nbsp;&nbsp;&nbsp;
										<button class="btn btn-sm btn-accent" type="button" onclick="kartu()">
											Cetak Kartu
										</button>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!--end: Selected Rows Group Action Form -->
				<div class="m_datatable" id="record_selection">
					<!-- Here is Data Table Begin -->
				</div>
			</div>
		</div>
	</div>
</div>
					<!-- end:: Body -->

<script type="text/javascript">

var save_method; //for save method string
var table;
 var DatatableRemoteAjaxDemo=function() {
    var t=function() {
        var t= $(".m_datatable").mDatatable({
						responsive: {
								details: {
										display: $.fn.dataTable.Responsive.display.modal( {
												header: function () {
														// var data = row.data();
														return 'Details for ';
												}
										} )
								}
						},
            data: {
                type:"remote",
								source: {
                    read: {
                        url: "<?php echo base_url();?><?php echo $page_access;?>/<?php echo $page_name;?>/fetch/"
                    }
                }
                ,
                saveState: {
                    cookie: !1, webstorage: !1
                }
                ,
                serverPaging:true,
                serverFiltering:true,
                serverSorting:true
            }
            , layout: {
                theme: "default", class: "", scroll: !1, footer: !1
            }
            , sortable: true,
						filterable: false,
						pagination: true,
						searchDelay: 400,
			 			columns:[ {
                field:"nis1", class:"tes", title:"#", sortable:!1, width:3, selector: {
                    class: "m-checkbox--solid m-checkbox--brand"
                },
            }
            ,	{
                field: "number", title: "No", sortable: false, width: 40, textAlign: "center"
            }
            , {
                field:"nis", title:"NIS", filterable:!1, width:100
            }
            , {
                field: "nama", title: "Nama"
            }
						, {
								field: "status", title: "Status", width:130
						}
						, {
								field: "berlaku_sampai", title: "Berlaku Sampai"
						}
						, {
                field:"action", title:"Actions", sortable: false, width:110, overflow:"visible", template:function(t) {
                    return'\t\t\t\t\t\t<a href="javascript:void(0)" onclick="view(\''+t.nis+'\')" class="m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill" title="Edit details">\t\t\t\t\t\t\t<i class="la la-search"></i>\t\t\t\t\t\t</a>\t\t\t\t\t'
                }
            }
            ],
			 			toolbar: {
							layout: ['pagination', 'info'],
							placement: ['bottom'],  //'top', 'bottom'
							items: {
								pagination: {
									type: 'default',
									pages: {
										desktop: {
											layout: 'default',
											pagesNumber: 6
										},
										tablet: {
											layout: 'default',
											pagesNumber: 3
										},
										mobile: {
											layout: 'compact'
										}
									},
									navigation: {
										prev: true,
										next: true,
										first: true,
										last: true
									},
									pageSizeSelect: [10, 20, 30, 50, 100]
								},
								info: true
							}
						},
					translate: {
						records: {
							processing: 'Please wait...',
							noRecords: 'No records found'
						},
						toolbar: {
							pagination: {
								items: {
									default: {
										first: 'First',
										prev: 'Previous',
										next: 'Next',
										last: 'Last',
										more: 'More pages',
										input: 'Page number',
										select: 'Select page size'
									},
									info: 'Displaying {{start}} - {{end}} from {{total}} records'
								}
							}
						}
					}
        }
			  ),
        a=t.getDataSourceQuery();
        $("#m_form_search").on("keyup", function(t) {
            var a=t.getDataSourceQuery();
            a.generalSearch=$(this).val().toLowerCase(), t.setDataSourceQuery(a), t.load()
        }).val(a.generalSearch),
        $("#m_form_nama").on("change", function(t) {
            var a=t.getDataSourceQuery();
            a.nama=$(this).val().toLowerCase(), t.setDataSourceQuery(a), t.load()
        }).val(void 0!==a.nama?a.nama:""),
        $("#m_form_nama").selectpicker(),
				$(".m_datatable").on("m-datatable--on-check", function(a, e) {
					 var l=t.setSelectedRecords().getSelectedRecords().length;
					 $("#m_datatable_selected_number").html(l), l>0&&$("#m_datatable_group_action_form").collapse("show")
			 }).on("m-datatable--on-uncheck m-datatable--on-layout-updated", function(a, e) {
					 var l=t.setSelectedRecords().getSelectedRecords().length;
					 $("#m_datatable_selected_number").html(l), 0===l&&$("#m_datatable_group_action_form").collapse("hide")
			 }),
			 $('#generatecode').on('click',function() {
				 	var final = new Array();
					var i= 0;
					$('.m-checkbox--solid input[type="checkbox"]:checked').each(function(){
					    var values = $(this).val();
					    final[i++] = values;
					});
					alert(final);
			 });
    };
    return {
        init:function() {
            t()
        }
    }
}();
jQuery(document).ready(function() {
    DatatableRemoteAjaxDemo.init()
});
function reload_table()
{
	$( "#m_datatable_reload" ).trigger( "click" );
    table.ajax.reload(); //reload datatable ajax
}
function view(id)
{
	var url = "<?php echo base_url();?><?php echo $page_access;?>/<?php echo $page_name;?>/get/" + id;
	$.ajax({
			url : url,
			type: "GET",
			dataType: "JSON",
			success: function(data)
			{
				$('#nis').text(data[0].nis);
				$('#nama').text(data[0].nama);
				if (data[0].jk=='P') {
					data[0].jk="Perempuan";
				}else {
					data[0].jk="Laki-Laki";
				}
				$('#jk').text(data[0].jk);
				$('#ttl').text(data[0].tempatlahir);
				$('#m_Modal').modal('show'); // show bootstrap modal when complete loaded
				$('.modal-title').text('Lihat Data Anggota'); // Set title to Bootstrap modal title
			},
			error: function (jqXHR, textStatus, errorThrown)
			{
					alert('Error get data from ajax');
			}
	});
}


</script>
<!--begin::Modal-->
<div class="modal fade" id="m_Modal" tabindex="-1" role="dialog" aria-labelledby="labelModal" aria-hidden="true">
	<div class="modal-dialog modal-md" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="labelModal"></h5>
			</div>
			<div class="modal-body">
				<div class="m-portlet__body">
					<div class="form-group m-form__group row">
						<div class="col-lg-3">ID </div>:
						<div class="col-lg-5">
							<p id="nis">ID</p>
						</div>
					</div>
					<div class="form-group m-form__group row">
						<div class="col-lg-3">Nama </div>:
						<div class="col-lg-5">
							<b><p id="nama">NAMA</p></b>
						</div>
					</div>
					<div class="form-group m-form__group row">
						<div class="col-lg-3">Jenis Kelamin </div>:
						<div class="col-lg-5">
							<p id="jk">Jenis Kelamin</p>
						</div>
					</div>
					<div class="form-group m-form__group row">
						<div class="col-lg-3">Tempat/Tgl Lahir </div>:
						<div class="col-lg-5">
							<p id="ttl">Tempat/Tgl Lahir</p>
						</div>
					</div>
				</div>
		</div>
	</div>
</div>
</div>
						<!--end::Modal-->
