<div id="m_aside_left" class="m-grid__item	m-aside-left  m-aside-left--skin-dark ">
<div 
		id="m_ver_menu" 
		class="m-aside-menu  m-aside-menu--skin-dark m-aside-menu--submenu-skin-dark " 
		data-menu-vertical="true"
		 data-menu-scrollable="false" data-menu-dropdown-timeout="500"  
		>
						<ul class="m-menu__nav  m-menu__nav--dropdown-submenu-arrow ">
							<li class="m-menu__item   <?php if($page_now=='dashboard') echo ' m-menu__item--active ';?>" aria-haspopup="true" >
								<a  href="<?php echo base_url();?>admin/dashboard" class="m-menu__link ">
									<i class="m-menu__link-icon flaticon-line-graph"></i>
									<span class="m-menu__link-title">
										<span class="m-menu__link-wrap">
											<span class="m-menu__link-text">
												Dashboard
											</span>
											<span class="m-menu__link-badge">
												<span class="m-badge m-badge--danger">
													2
												</span>
											</span>
										</span>
									</span>
								</a>
							</li>
							<li class="m-menu__section">
								<h4 class="m-menu__section-text">
									Master
								</h4>
								<i class="m-menu__section-icon flaticon-more-v3"></i>
							</li>
							<?php if(in_array('data_anggota',$this->session->userdata('perm_view'))||in_array('data_anggota_luar',$this->session->userdata('perm_view'))||in_array('data_dosen',$this->session->userdata('perm_view'))||in_array('data_mahasiswa',$this->session->userdata('perm_view'))):?>
							<li class="m-menu__item  <?php if($page_now=='Data Induk') echo ' m-menu__item--active ';?>m-menu__item--submenu m-menu__item--rel"  data-menu-submenu-toggle="click" aria-haspopup="true">
											<a  href="#" class="m-menu__link m-menu__toggle">
												<i class="m-menu__link-icon flaticon-users"></i>
												<span class="m-menu__link-text">
													Data Induk
												</span>
												<i class="m-menu__ver-arrow la la-angle-right"></i>
											</a>
											<div class="m-menu__submenu m-menu__submenu--classic m-menu__submenu--left">
												<span class="m-menu__arrow m-menu__arrow--adjust"></span>
												<ul class="m-menu__subnav">
												<?php if(in_array('data_mahasiswa',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/data_mahasiswa" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Data mahasiswa
																	</span>
																</span>
															</span>
														</a>
													</li>
													<?php endif; ?>
												<?php if(in_array('data_dosen',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/data_dosen" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Data Dosen
																	</span>
																</span>
															</span>
														</a>
													</li>
												<?php endif; ?>
												<?php if(in_array('data_anggota_luar',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/data_anggota_luar" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Data Anggota Luar
																	</span>
																</span>
															</span>
														</a>
													</li>
												<?php endif; ?>
													<?php if(in_array('data_anggota',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/data_anggota" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Data Anggota
																	</span>
																	<!--
																	new data bubble
																	<span class="m-menu__link-badge">
																		<span class="m-badge m-badge--success">
																			2
																		</span>
																	</span>
																	-->
																</span>
															</span>
														</a>
													</li>
											<?php endif; ?>
												</ul>
											</div>
										</li>
										<?php endif;?>
										<?php if(in_array('klasifikasi_buku',$this->session->userdata('perm_view'))||in_array('kategori_buku',$this->session->userdata('perm_view'))||in_array('bahasa',$this->session->userdata('perm_view'))||in_array('asal_buku',$this->session->userdata('perm_view'))||in_array('penerbit',$this->session->userdata('perm_view'))||in_array('keperluan_sbppl',$this->session->userdata('perm_view'))||in_array('program_studi',$this->session->userdata('perm_view'))||in_array('matakuliah',$this->session->userdata('perm_view'))):?>
										<li class="m-menu__item  <?php if($page_now=='Data Referensi') echo ' m-menu__item--active ';?>m-menu__item--submenu m-menu__item--rel"  data-menu-submenu-toggle="click" aria-haspopup="true">
											<a  href="#" class="m-menu__link m-menu__toggle">
												<i class="m-menu__link-icon flaticon-book"></i>
												<span class="m-menu__link-text">
													Data Referensi
												</span>
												<i class="m-menu__ver-arrow la la-angle-right"></i>
											</a>
											<div class="m-menu__submenu m-menu__submenu--classic m-menu__submenu--left">
												<span class="m-menu__arrow m-menu__arrow--adjust"></span>
												<ul class="m-menu__subnav">
													<?php if(in_array('klasifikasi_buku',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/klasifikasi_buku" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Klasifikasi Buku
																	</span>
																</span>
															</span>
														</a>
													</li>
													<?php endif; ?>
													<?php if(in_array('kategori_buku',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/kategori_buku" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Kategori Buku
																	</span>
																</span>
															</span>
														</a>
													</li>
													<?php endif; ?>
													<?php if(in_array('bahasa',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/bahasa" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Bahasa
																	</span>
																</span>
															</span>
														</a>
													</li>
													<?php endif; ?>
													<?php if(in_array('asal_buku',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/asal_buku" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Asal Buku
																	</span>
																</span>
															</span>
														</a>
													</li>
													<?php endif; ?>
													<?php if(in_array('penerbit',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/penerbit" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Penerbit
																	</span>
																</span>
															</span>
														</a>
													</li>
													<?php endif; ?>
													<?php if(in_array('keperluan_sbppl',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/keperluan_sbppl" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Keperluan SBPPL
																	</span>
																</span>
															</span>
														</a>
													</li>
													<?php endif; ?>
													<?php if(in_array('program_studi',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/program_studi" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Program Studi
																	</span>
																</span>
															</span>
														</a>
													</li>
													<?php endif; ?>
													<?php if(in_array('matakuliah',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/matakuliah" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Matakuliah
																	</span>
																</span>
															</span>
														</a>
													</li>
													<?php endif; ?>
												</ul>
											</div>
										</li>
										<?php endif;?>
										<?php if(in_array('data_buku',$this->session->userdata('perm_view'))||in_array('inventaris',$this->session->userdata('perm_view'))||in_array('bukumk',$this->session->userdata('perm_view'))):?>
										<li class="m-menu__item <?php if($page_now=='Buku Inventaris') echo ' m-menu__item--active ';?>  m-menu__item--submenu m-menu__item--rel"  data-menu-submenu-toggle="click" aria-haspopup="true">
											<a  href="#" class="m-menu__link m-menu__toggle">
												<i class="m-menu__link-icon flaticon-cogwheel-2"></i>
												<span class="m-menu__link-text">
													Buku & Inventarisasi
												</span>
												<i class="m-menu__ver-arrow la la-angle-right"></i>
											</a>
											<div class="m-menu__submenu m-menu__submenu--classic m-menu__submenu--left">
												<span class="m-menu__arrow m-menu__arrow--adjust"></span>
												<ul class="m-menu__subnav">
													<?php if(in_array('data_buku',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/data_buku" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Data Buku
																	</span>
																</span>
															</span>
														</a>
													</li>
													<?php endif; ?>
													<?php if(in_array('inventaris',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="#" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Inventaris
																	</span>
																</span>
															</span>
														</a>
													</li>
													<?php endif; ?>
													<?php if(in_array('bukumk',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="#" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Buku Jurusan
																	</span>
																</span>
															</span>
														</a>
													</li>
													<?php endif; ?>
												</ul>
											</div>
										</li>
										<?php endif; ?>
										<?php if(in_array('hilang',$this->session->userdata('perm_view'))||in_array('transaksi',$this->session->userdata('perm_view'))||in_array('traninv',$this->session->userdata('perm_view'))||in_array('presensi',$this->session->userdata('perm_view'))):?>
										<li class="m-menu__item <?php if($page_now=='Transaksi') echo ' m-menu__item--active ';?> m-menu__item--submenu m-menu__item--rel"  data-menu-submenu-toggle="click" aria-haspopup="true">
											<a  href="#" class="m-menu__link m-menu__toggle">
												<i class="m-menu__link-icon flaticon-users"></i>
												<span class="m-menu__link-text">
													Transaksi
												</span>
												<i class="m-menu__ver-arrow la la-angle-right"></i>
											</a>
												<div class="m-menu__submenu m-menu__submenu--classic m-menu__submenu--left">
												<span class="m-menu__arrow m-menu__arrow--adjust"></span>
												<ul class="m-menu__subnav">
													<?php if(in_array('hilang',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/hilang" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Hilang/Rusak/Etc
																	</span>
																</span>
															</span>
														</a>
													</li>
													<?php endif; ?>
													<?php if(in_array('transaksi',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/transaksi" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Transaksi
																	</span>
																</span>
															</span>
														</a>
													</li>
													<?php endif; ?>
													<?php if(in_array('traninv',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/traninv" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Pengembalian Buku Tanpa Kartu Anggota
																	</span>
																</span>
															</span>
														</a>
													</li>
													<?php endif; ?>
													<?php if(in_array('presensi',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/presensi" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Presensi
																	</span>
																</span>
															</span>
														</a>
													</li>
													<?php endif; ?>
													
												</ul>
											</div>
										
										</li>
										<?php endif;?>
										<?php if(in_array('konfigurasi',$this->session->userdata('perm_view'))||in_array('konfigurasi_transaksi',$this->session->userdata('perm_view'))||in_array('hari_libur',$this->session->userdata('perm_view'))||in_array('hometxt',$this->session->userdata('perm_view'))):?>
										<li class="m-menu__item  <?php if($page_now=='Konfigurasi Transaksi') echo ' m-menu__item--active ';?>m-menu__item--submenu m-menu__item--rel"  data-menu-submenu-toggle="click" aria-haspopup="true">
											<a  href="#" class="m-menu__link m-menu__toggle">
												<i class="m-menu__link-icon flaticon-cogwheel"></i>
												<span class="m-menu__link-text">
													Konfigurasi Transaksi
												</span>
												<i class="m-menu__ver-arrow la la-angle-right"></i>
											</a>
											<div class="m-menu__submenu m-menu__submenu--classic m-menu__submenu--left">
												<span class="m-menu__arrow m-menu__arrow--adjust"></span>
												<ul class="m-menu__subnav">
													<?php if(in_array('konfigurasi',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/konfigurasi" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Konfigurasi
																	</span>
																</span>
															</span>
														</a>
													</li>
													<?php endif; ?>
													<?php if(in_array('konfigurasi_transaksi',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/konfigurasi_transaksi" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Konfigurasi Transaksi
																	</span>
																</span>
															</span>
														</a>
													</li>
													<?php endif; ?>
													<?php if(in_array('hari_libur',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="#" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Hari Libur
																	</span>
																</span>
															</span>
														</a>
													</li>
													<?php endif; ?>
													<?php if(in_array('hometxt',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="#" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Konfigurasi Dashboard
																	</span>
																</span>
															</span>
														</a>
													</li>
													<?php endif; ?>
													
												</ul>
											</div>
										</li>
										<?php endif; ?>
										<?php if(in_array('daftar_user',$this->session->userdata('perm_view'))||in_array('group_user',$this->session->userdata('perm_view'))||in_array('user_grant',$this->session->userdata('perm_view'))||in_array('import_data',$this->session->userdata('perm_view'))):?>
										<li class="m-menu__item <?php if($page_now=='Administrator') echo ' m-menu__item--active ';?> m-menu__item--submenu m-menu__item--rel"  data-menu-submenu-toggle="click" aria-haspopup="true">
											<a  href="#" class="m-menu__link m-menu__toggle">
												<i class="m-menu__link-icon flaticon-users"></i>
												<span class="m-menu__link-text">
													Administrator
												</span>
												<i class="m-menu__ver-arrow la la-angle-right"></i>
											</a>
											<div class="m-menu__submenu m-menu__submenu--classic m-menu__submenu--left">
												<span class="m-menu__arrow m-menu__arrow--adjust"></span>
												<ul class="m-menu__subnav">
													<?php if(in_array('daftar_user',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/daftar_user" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Daftar User
																	</span>
																</span>
															</span>
														</a>
													</li>
													<?php endif; ?>
													<?php if(in_array('group_user',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/group_user" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Group User
																	</span>
																</span>
															</span>
														</a>
													</li>
													<?php endif; ?>
													<?php if(in_array('user_grant',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/user_grant" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Grant User
																	</span>
																</span>
															</span>
														</a>
													</li>
													<?php endif; ?>
													<?php if(in_array('import_data',$this->session->userdata('perm_view'))):?>
													<li class="m-menu__item "  aria-haspopup="true">
														<a  href="<?php echo base_url();?>admin/import_data" class="m-menu__link ">
															<span class="m-menu__link-title">
																<span class="m-menu__link-wrap">
																	<span class="m-menu__link-text">
																		Import Data
																	</span>
																</span>
															</span>
														</a>
													</li>
													<?php endif; ?>
													
												</ul>
											</div>
										</li>
										<?php endif; ?>
						</ul>
					</div>
					</div>
				