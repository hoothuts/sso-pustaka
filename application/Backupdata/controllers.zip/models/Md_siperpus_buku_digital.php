<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Md_siperpus_buku_digital extends CI_Model {

   function getBukuDigital() {
		 $hasil = $this->db->query("SELECT * FROM siperpus_buku_digital order by title asc limit 20");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
    }
}