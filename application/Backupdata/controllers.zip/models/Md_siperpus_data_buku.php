<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Md_siperpus_data_buku extends CI_Model {

//SELECT *,(SELECT nama_penerbit from siperpus_penerbit where kd_penerbit = bk.kd_penerbit)as penerbit FROM siperpus_buku bk where kd_penerbit = 1565 order by judul asc
  var $select= 'a.* , b.nama_penerbit, b.kota';
  var $table1 = 'siperpus_buku';
  var $table = 'siperpus_buku a, siperpus_penerbit b';
  var $where = 'b.kd_penerbit = a.kd_penerbit';
  var $column_order = array(array('no_klas','no_klas'),array('judul','judul'),array('penulis','penulis')); //set column field database for datatable orderable
  var $column_search = array('ISBN','judul','penulis','no_klas'); //set column field database for datatable searchable just firstname , lastname , address are searchable
  var $order = array('judul' => 'asc'); // default order

  public function countAll() {

        $this->db->from($this->table);
        return $this->db->count_all_results();
  }
  public function getValue($b,$text){
		foreach($b as $v)
		{
			if(in_array($text, $v, true))
			{
				return $v[1];
			}
		}
		return false;
	}
  private function getDatatablesQuery(){
    $this->db->select($this->select);
    $this->db->from($this->table);//from vwanggota
    $this->db->where($this->where);
    $i = 0;
    //checking if there's searching :
    foreach ($this->column_search as $item) // loop column
    {
      if($this->input->post('datatable[query][generalSearch]')) // if datatable send POST for search
      {
        if($i===0) // first loop
        {
          $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
          $this->db->like($item, $this->input->post('datatable[query][generalSearch]'));
        }
        else
        {
          $this->db->or_like($item, $this->input->post('datatable[query][generalSearch]'));
        }
        if(count($this->column_search) - 1 == $i) //last loop
          $this->db->group_end(); //close bracket
      }
      $i++;
    }
    if($this->input->post('datatable[query][klas]')){
			$this->db->like('no_klas', $this->input->post('datatable[query][klas]'), 'after');
		}
		if($this->input->post('datatable[query][kel]')){
			$this->db->where('idkategori', $this->input->post('datatable[query][kel]'));
		}
    //filtering order :

    $val=$this->getValue($this->column_order,$this->input->post('datatable[sort][field]'));
		if($val!= false) // here order processing
		{
			$this->db->order_by($val, $this->input->post('datatable[sort][sort]'));
		}
		else if(isset($this->order))
		{
			$order = $this->order;
			$this->db->order_by(key($order), $order[key($order)]);
		}
  }
  function getDatatables(){
    $this->getDatatablesQuery();
    if($this->input->post('datatable[pagination][perpage]') != -1)
      $this->db->limit($this->input->post('datatable[pagination][perpage]'), ($this->input->post('datatable[pagination][perpage]')*(($this->input->post('datatable[pagination][page]')-1))));

    $query = $this->db->get();
    return $query->result();
  }
  function countFiltered(){
    $this->getDatatablesQuery();
    $query = $this->db->get();
    return $query->num_rows();
  }
  function getDataBukuAll() {
		 $hasil = $this->db->query("SELECT *,(SELECT nama_penerbit from siperpus_penerbit where kd_penerbit = bk.kd_penerbit)as penerbit FROM siperpus_buku bk where kd_penerbit = 1565 order by judul asc");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
    }
	function addDataBuku($data){
         $this->db->insert('siperpus_buku', $data);
  }
  function hapusDataBuku($data){
    $this->db->where('ISBN',$data);
    $this->db->delete('siperpus_buku');
  }
  function updateDataBuku($param,$data){
        $this->db->where('ISBN', $param);
        $this->db->update('siperpus_buku', $data);
    }
  function updateJmlBuku($isbn,$no_klas,$row){
    $this->db->set('jml_buku',$row);
    $this->db->where('ISBN', $isbn);
    $this->db->where('no_klas', $no_klas);
    $this->db->update('siperpus_buku');
    }
	function getDataBukuByISBN($ISBN) {
    $this->db->from($this->table1);
    $this->db->where('ISBN', $ISBN);
    $data = $this->db->get();
    return $data->result();
  }
  function getDataBukuByISBNdanNo_klas($ISBN,$no_klas) {
    $this->db->from($this->table1);
    $this->db->where('ISBN', $ISBN);
    $this->db->where('no_klas', $no_klas);
    $data = $this->db->get();
    return $data->result();
  }
  function updateRakBuku($no_klas,$rak) {
    $this->db->set('no_rak',$rak);
    $this->db->where('no_klas', $no_klas);
    $this->db->update('siperpus_buku');
  }
  function addDataCover($file_up)
  {
    $db = $this->db->insert('siperpus_buku_file', $file_up);
    if ($this->db->affected_rows() > 0) {
            return TRUE;
        } else {
            return FALSE;
        }
  }

}
