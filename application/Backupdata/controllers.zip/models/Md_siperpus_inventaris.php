<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Md_siperpus_inventaris extends CI_Model {


//SELECT *,(SELECT judul FROM `siperpus_buku` WHERE ISBN = inv.ISBN) as judul FROM `siperpus_inventaris` inv WHERE 1
  function getNumRowInvByNoKlas($no_klas){
    $this->db->where('no_klas',$no_klas);
    return $this->db->get('siperpus_inventaris')->num_rows();
  }
  function getNoBarcode(){
    $this->db->select_max('no_barcode');
    return $this->db->get('siperpus_inventaris')->row()->no_barcode;
  }
  function getInventarisByBarcode($barcode){
    $hasil = $this->db->get_where('siperpus_inventaris', array('no_barcode' => $barcode))->result();
    $data = $hasil;
    return $data;
  }

  function getInventarisAll() {
    $hasil = $this->db->query("SELECT *,(SELECT judul FROM `siperpus_buku` WHERE ISBN = inv.ISBN) as judul FROM siperpus_inventaris inv WHERE ISBN ='978.979.044.092.0' order by no_inv asc");
    if ($hasil->num_rows() > 0) {
      foreach ($hasil->result() as $row) {
        $data[] = $row;
      }
      return $data;
    }
  }
  function addInventaris($data){
         $this->db->insert('siperpus_inventaris', $data);
    }
  function hapusInventaris($data){
      $this->db->where('no_barcode',$data);//jangan hapus dengan menggunakan isbn, gunakan no_barcode
      $this->db->delete('siperpus_inventaris');
    }
  function updateInventaris($no_barcode,$data){
        $this->db->where('no_barcode', $no_barcode);
        $this->db->update('siperpus_inventaris', $data);
    }
  function getInventarisById($id) {
        $query = "SELECT *,(SELECT judul FROM `siperpus_buku` WHERE ISBN = inv.ISBN) as judul FROM siperpus_inventaris inv WHERE ISBN = '".$id."'";
        $hasil = $this->db->query($query)->result();
        //$hasil = $this->db->get_where('siperpus_inventaris', array('ISBN' => $id))->result();
        $data = $hasil;
        return $data;
    }
  function getInventarisByISBNdanNoKlas($id,$no_klas) {
         $query = "SELECT *,(SELECT judul FROM `siperpus_buku` WHERE ISBN = inv.ISBN) as judul FROM siperpus_inventaris inv WHERE ISBN = '".$id."'" OR "no_klas = '".$no_klas."'";
         $hasil = $this->db->query($query)->result();
         //$hasil = $this->db->get_where('siperpus_inventaris', array('ISBN' => $id))->result();
         $data = $hasil;
         return $data;
     }
  function countByISBN($isbn){
    $where = "ISBN = '".$isbn."'";
    $this->db->from('siperpus_inventaris');//from vwanggota
    $this->db->where($where);
    $query = $this->db->get();
    return $query->num_rows();
  }
  function hapusInventarisAll($isbn){
    $this->db->where('ISBN',$isbn);
    $this->db->delete('siperpus_inventaris');
  }

}
