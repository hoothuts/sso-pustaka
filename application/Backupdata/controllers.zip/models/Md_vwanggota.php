<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Md_vwanggota extends CI_Model {

  var $select= 'a.* , s.nama, s.jk, s.tempatlahir, s.tgllahir';
  var $table1 = 'vwanggota';
  var $table = 'vwanggota a, vwsiswa s';
  var $where = 'a.nis = s.nis';
  var $column_order = array(array('nis','nis'),array('nama','nama'),array('prodi','kelas'),array('status','status_siswa')); //set column field database for datatable orderable
  var $column_search = array('nis'); //set column field database for datatable searchable just firstname , lastname , address are searchable
  var $order = array('nis' => 'asc'); // default order

  public function countAll() {

        $this->db->from($this->table);
        return $this->db->count_all_results();
  }
  public function getValue($b,$text){
		foreach($b as $v)
		{
			if(in_array($text, $v, true))
			{
				return $v[1];
			}
		}
		return false;
	}
  private function getDatatablesQuery()
  {
    $this->db->select($this->select);
    $this->db->from($this->table);//from vwanggota
    $this->db->where($this->where);
    $i = 0;
    //checking if there's searching :

    foreach ($this->column_search as $item) // loop column
    {
      if($this->input->post('datatable[query][generalSearch]')) // if datatable send POST for search
      {
        if($i===0) // first loop
        {
          $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
          $this->db->like($item, $this->input->post('datatable[query][generalSearch]'));
        }
        else
        {
          $this->db->or_like($item, $this->input->post('datatable[query][generalSearch]'));
        }
        if(count($this->column_search) - 1 == $i) //last loop
          $this->db->group_end(); //close bracket
      }
      $i++;
    }
    // $name= $this->db->list_fields("vwanggota");
    // if($this->input->post('datatable[query][nama]')){
		// 	$this->db->where($name[0], $this->input->post('datatable[query][nama]'));
		// 	}
    //filtering order :

    $val=$this->getValue($this->column_order,$this->input->post('datatable[sort][field]'));
		if($val!= false) // here order processing
		{
			$this->db->order_by($val, $this->input->post('datatable[sort][sort]'));
		}
		else if(isset($this->order))
		{
			$order = $this->order;
			$this->db->order_by(key($order), $order[key($order)]);
		}
  }

  function getDatatables()
  {
    $this->getDatatablesQuery();
    if($this->input->post('datatable[pagination][perpage]') != -1)
      $this->db->limit($this->input->post('datatable[pagination][perpage]'), ($this->input->post('datatable[pagination][perpage]')*(($this->input->post('datatable[pagination][page]')-1))));

    $query = $this->db->get();
    return $query->result();
  }

  function countFiltered()
  {
    $this->getDatatablesQuery();
    $query = $this->db->get();
    return $query->num_rows();
  }

  function getAnggotaById($id) {
    $this->db->select($this->select);
    $this->db->from($this->table);//from vwanggota
    $this->db->where($this->where);
        $hasil = $this->db->get_where('vwanggota', array('a.nis' => $id))->result();
        $data = $hasil;
        return $data;
    }

   function getAnggotaAll() {
		 $hasil = $this->db->query("SELECT *,(SELECT nama FROM `vwsiswa` WHERE `nis` = vwang.`nis` AND nama IS NOT NULL) as nama FROM `vwanggota` vwang");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
    }
}
