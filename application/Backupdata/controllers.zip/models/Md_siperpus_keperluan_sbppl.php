<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Md_siperpus_keperluan_sbppl extends CI_Model {

 var $table = 'siperpus_sbppl_keperluan';
 var $column_order = array('id','nama',null); //set column field database for datatable orderable
 var $column_search = array('id','nama'); //set column field database for datatable searchable just firstname , lastname , address are searchable
 var $order = array('nama' => 'asc'); // default order

 public function countAll() {
        $this->db->from($this->table);
   return $this->db->count_all_results();
    }
 private function getDatatablesQuery()
 {

   $this->db->from($this->table);

   $i = 0;

   foreach ($this->column_search as $item) // loop column
   {
     if($this->input->post('datatable[query][generalSearch]')) // if datatable send POST for search
     {

       if($i===0) // first loop
       {
         $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
         $this->db->like($item, $this->input->post('datatable[query][generalSearch]'));
       }
       else
       {
         $this->db->or_like($item, $this->input->post('datatable[query][generalSearch]'));
       }

       if(count($this->column_search) - 1 == $i) //last loop
         $this->db->group_end(); //close bracket
     }
     $i++;
   }
    if($this->input->post('datatable[query][nama]')!='')$this->db->or_like('nama', $this->input->post('datatable[query][nama]'));

   if(in_array($this->input->post('datatable[sort][field]'),$this->column_order)) // here order processing
   {
     $this->db->order_by($this->input->post('datatable[sort][field]'), $this->input->post('datatable[sort][sort]'));
   }
   else if(isset($this->order))
   {
     $order = $this->order;
     $this->db->order_by(key($order), $order[key($order)]);
   }
 }

 function getDatatables()
 {
   $this->getDatatablesQuery();
   if($this->input->post('datatable[pagination][perpage]') != -1)
   $this->db->limit($this->input->post('datatable[pagination][perpage]'), ($this->input->post('datatable[pagination][perpage]')*(($this->input->post('datatable[pagination][page]')-1))));
   $query = $this->db->get();
   return $query->result();
 }

 function countFiltered()
 {
   $this->getDatatablesQuery();
   $query = $this->db->get();
   return $query->num_rows();
 }

   function getSbpplAll() {
		 $hasil = $this->db->query("SELECT * FROM siperpus_sbppl_keperluan order by no_urut asc");
        if ($hasil->num_rows() > 0) {
            foreach ($hasil->result() as $row) {
                $data[] = $row;
            }
            //$data['baris']=$this->db->query("SELECT MAX(idkategori) FROM siperpus_kategori")
            return $data;
        }
    }
	 function addSbppl($data){
         $this->db->insert('siperpus_sbppl_keperluan', $data);
    }
   function hapusSbppl($data)
    {
      $this->db->where('id',$data);
      $this->db->delete('siperpus_sbppl_keperluan');
    }
   function updateSbppl($param,$data){
        $this->db->where('id', $param);
        $this->db->update('siperpus_sbppl_keperluan', $data);
    }
	 function getSbpplByNama($id) {
        $hasil = $this->db->get_where('siperpus_sbppl_keperluan', array('nama' => $id))->result();
        $data = $hasil;
        return $data;
    }

}
